﻿using System;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class Accounts
    {
        private Accounts() { }

        public Accounts(int id, int companyId, int accountType, string code, string name, string description, bool isActive, bool isDelete, DateTime createdAt, string createdBy) : this()
        {
            Id = id;
            CompanyId = companyId;
            AccountType = accountType;
            Code = code ?? throw new ArgumentNullException(nameof(code));
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Description = description ?? throw new ArgumentNullException(nameof(description));
            IsActive = isActive;
            IsDelete = isDelete;
            CreatedAt = DateTime.UtcNow;
            CreatedBy = createdBy;
        }

        public int Id { get; private set; }
        public int CompanyId { get; private set; }
        public int AccountType { get; private set; }
        public string Code { get; private set; }
        public string Name { get; private set; }
        public string Description { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual AccountType AccountTypeNavigation { get; private set; }
        public virtual Company Company { get; private set; }


    }
}
