﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using YK.IMS.Core.Status;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class BusinessType
    {
        private BusinessType()
        {
            BusinessAccount = new HashSet<BusinessAccount>();
        }

        public Core.Enums.BusinessType Id { get; private set; }
        public int CompanyId { get; private set; }
        public string Code { get; private set; }
        public string Name { get; private set; }
        public string Description { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime? CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }
        public virtual ICollection<BusinessAccount> BusinessAccount { get; private set; }
        public virtual Company Company { get; private set; }
        public static IStatusGeneric<BusinessType> CreateBusinessTypeFactory(Core.Enums.BusinessType id, int companyId, string name, string code, string description, string createdBy)
        {
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }

            if (code == null)
            {
                throw new ArgumentNullException(nameof(code));
            }

            if (description == null)
            {
                throw new ArgumentNullException(nameof(description));
            }

            StatusGenericHandler<BusinessType> status = new StatusGenericHandler<BusinessType>();
            BusinessType businessType = new BusinessType()
            {
                Id = id,
                CompanyId = companyId,
                Name = name.Trim(),
                Code = code.Trim(),
                Description = description.Trim(),
                IsActive = true,
                IsDelete = false,
                CreatedBy = createdBy,
                CreatedAt = DateTime.UtcNow,
            };

            status.CombineErrors(businessType.IsValid());
            status.Result = businessType;
            return status;
        }

        public IStatusGeneric IsValid()
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (CompanyId <= 0)
            {
                status.AddError($"Negetive {nameof(CompanyId)} is invalid.", nameof(CompanyId));
            }

            if (string.IsNullOrWhiteSpace(Name))
            {
                status.AddError($"Null or empty {nameof(Name)} is invalid.", nameof(Name));
            }

            if (string.IsNullOrWhiteSpace(Code))
            {
                status.AddError($"Null or empty {nameof(Code)} is invalid.", nameof(Code));
            }

            if (string.IsNullOrWhiteSpace(Description))
            {
                // status.AddError($"Null or empty {nameof(Description)} is invalid.", nameof(Description));
            }

            if (!IsActive)
            {
                status.AddError($"Inactive entry is invalid.", nameof(IsActive));
            }

            if (IsDelete)
            {
                status.AddError($"Delete entry is invalid.", nameof(IsDelete));
            }

            if (CreatedAt == DateTime.MinValue)
            {
                status.AddError($"Null or empty {nameof(CreatedAt)} is invalid.", nameof(CreatedAt));
            }

            if (string.IsNullOrWhiteSpace(CreatedBy))
            {
                status.AddError($"Null or empty {nameof(CreatedBy)} is invalid.", nameof(CreatedBy));
            }

            return status;
        }
    }
}
