﻿using YK.IMS.Core.Status;
using System;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class ProductStock
    {
        private ProductStock(int warehouseId, decimal openingQuantity, decimal receivingQuantity, decimal shipmentQuantity, decimal rejectedQuantity, decimal transferInQuantity, decimal transferOutQuantity, string createdBy)
        {
            WarehouseId = warehouseId;
            OpeningQuantity = openingQuantity;
            ReceivingQuantity = receivingQuantity;
            ShipmentQuantity = shipmentQuantity;
            RejectedQuantity = rejectedQuantity;
            TransferInQuantity = transferInQuantity;
            TransferOutQuantity = transferOutQuantity;
            BalanceQuantity = openingQuantity + ReceivingQuantity + transferInQuantity - shipmentQuantity - rejectedQuantity - transferOutQuantity;
            IsActive = true;
            IsDelete = false;
            CreatedBy = createdBy;
            CreatedAt = DateTime.UtcNow;
        }

        public int Id { get; private set; }
        public int WarehouseId { get; private set; }
        public int ProductId { get; private set; }
        public decimal OpeningQuantity { get; private set; }
        public decimal ReceivingQuantity { get; private set; }
        public decimal ShipmentQuantity { get; private set; }
        public decimal RejectedQuantity { get; private set; }
        public decimal TransferInQuantity { get; private set; }
        public decimal TransferOutQuantity { get; private set; }
        public decimal BalanceQuantity { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }



        public virtual Product Product { get; private set; }
        public virtual Warehouse Warehouse { get; private set; }

        internal static IStatusGeneric<ProductStock> AddOpeningStock(int warehouseId, decimal openingQuantity, string createdBy)
        {
            StatusGenericHandler<ProductStock> status = new StatusGenericHandler<ProductStock>();
            if (openingQuantity <= 0)
            {
                //throw new ArgumentException($"Opening quantity must be greater than zero quantity.");
                status.AddError($"Opening quantity must be greater than zero quantity.", nameof(OpeningQuantity));
            }

            ProductStock productStock = new ProductStock(warehouseId, openingQuantity, 0, 0, 0, 0, 0, createdBy);

            status.Result = productStock;
            return status;
        }
    }
}
