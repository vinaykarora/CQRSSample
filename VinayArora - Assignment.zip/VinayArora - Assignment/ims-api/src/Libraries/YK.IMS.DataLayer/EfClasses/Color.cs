﻿using YK.IMS.Core.Status;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class Color
    {
        public const int NameLength = 100;
        public const int CodeLength = 50;
        public const int DescriptionLength = 500;
        private Color()
        {
            CreditNoteLineItem = new HashSet<CreditNoteLineItem>();
            DebitNoteLineItem = new HashSet<DebitNoteLineItem>();
            DeliveryNoteLineItem = new HashSet<DeliveryNoteLineItem>();
            Product = new HashSet<Product>();
            PurchaseLineItem = new HashSet<PurchaseLineItem>();
            PurchaseOrderLineItem = new HashSet<PurchaseOrderLineItem>();
            SaleLineItem = new HashSet<SaleLineItem>();
            SaleOrderLineItem = new HashSet<SaleOrderLineItem>();
        }


        public int Id { get; private set; }
        public int CompanyId { get; private set; }
        [Required(AllowEmptyStrings = false)]
        [MaxLength(NameLength)]
        public string Name { get; private set; }
        [Required(AllowEmptyStrings = false)]
        [MaxLength(CodeLength)]
        public string Code { get; private set; }
        [MaxLength(DescriptionLength)]
        public string Description { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required] public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual Company Company { get; private set; }
        
        
        public virtual ICollection<CreditNoteLineItem> CreditNoteLineItem { get; private set; }
        public virtual ICollection<DebitNoteLineItem> DebitNoteLineItem { get; private set; }
        public virtual ICollection<DeliveryNoteLineItem> DeliveryNoteLineItem { get; private set; }
        public virtual ICollection<Product> Product { get; private set; }
        public virtual ICollection<PurchaseLineItem> PurchaseLineItem { get; private set; }
        public virtual ICollection<PurchaseOrderLineItem> PurchaseOrderLineItem { get; private set; }
        public virtual ICollection<SaleLineItem> SaleLineItem { get; private set; }
        public virtual ICollection<SaleOrderLineItem> SaleOrderLineItem { get; private set; }

        public static IStatusGeneric<Color> CreateColorFactory(int companyId, string name, string code, string description, string createdBy)
        {
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }

            if (code == null)
            {
                throw new ArgumentNullException(nameof(code));
            }

            if (description == null)
            {
                throw new ArgumentNullException(nameof(description));
            }

            StatusGenericHandler<Color> status = new StatusGenericHandler<Color>();
            Color color = new Color()
            {
                CompanyId = companyId,
                Name = name.Trim(),
                Code = code.Trim(),
                Description = description.Trim(),
                IsActive = true,
                IsDelete = false,
                CreatedBy = createdBy,
                CreatedAt = DateTime.UtcNow,
            };

            status.CombineErrors(color.IsValid());
            status.Result = color;
            return status;
        }

        public IStatusGeneric ChangeCode(string code)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(code))
            {
                status.AddError("Code Is Required", nameof(code));
            }

            Code = code.Trim();
            return status;
        }

        public IStatusGeneric ChangeName(string name)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(name))
            {
                status.AddError("Name Is Required", nameof(name));
            }

            Name = name.Trim();
            return status;
        }

        public IStatusGeneric ChangeDescription(string description)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(description))
            {
                //status.AddError("Description Is Required", nameof(description));
            }

            Description = description.Trim();
            return status;
        }

        public IStatusGeneric ChangeUpdatedBy(string userId)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrWhiteSpace(userId))
            {
                status.AddError($"{nameof(userId)} Is Required", nameof(userId));
            }

            LastUpdatedBy = userId;
            LastUpdatedAt = DateTime.UtcNow;
            return status;
        }

        public void Delete()
        {
            IsDelete = true;
        }

        public IStatusGeneric IsValid()
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (CompanyId <= 0)
            {
                status.AddError($"Negetive {nameof(CompanyId)} is invalid.", nameof(CompanyId));
            }

            if (string.IsNullOrWhiteSpace(Name))
            {
                status.AddError($"Null or empty {nameof(Name)} is invalid.", nameof(Name));
            }

            if (string.IsNullOrWhiteSpace(Code))
            {
                status.AddError($"Null or empty {nameof(Code)} is invalid.", nameof(Code));
            }

            if (string.IsNullOrWhiteSpace(Description))
            {
                // status.AddError($"Null or empty {nameof(Description)} is invalid.", nameof(Description));
            }

            if (!IsActive)
            {
                status.AddError($"Inactive entry is invalid.", nameof(IsActive));
            }

            if (IsDelete)
            {
                status.AddError($"Delete entry is invalid.", nameof(IsDelete));
            }

            if (CreatedAt == DateTime.MinValue)
            {
                status.AddError($"Null or empty {nameof(CreatedAt)} is invalid.", nameof(CreatedAt));
            }

            if (string.IsNullOrWhiteSpace(CreatedBy ))
            {
                status.AddError($"Null or empty {nameof(CreatedBy)} is invalid.", nameof(CreatedBy));
            }

            return status;
        }
    }
}
