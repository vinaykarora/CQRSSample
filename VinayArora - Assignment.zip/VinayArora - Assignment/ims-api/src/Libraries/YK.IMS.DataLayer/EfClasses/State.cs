﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class State
    {
        public State(string name, string code, string description, int countryId,  string createdBy) : this()
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Code = code ?? throw new ArgumentNullException(nameof(code));
            Description = description ?? throw new ArgumentNullException(nameof(description));
            CountryId = countryId;
            IsActive = true;
            IsDelete = false;
            CreatedBy = createdBy ?? throw new ArgumentNullException(nameof(createdBy));
            CreatedAt = DateTime.UtcNow;
        }

        private State()
        {
            Branch = new HashSet<Branch>();
            BusinessAccountAddress = new HashSet<BusinessAccountAddress>();
            City = new HashSet<City>();
            Warehouse = new HashSet<Warehouse>();
        }

        public int Id { get; private set; }
        public string Name { get; private set; }
        public string Code { get; private set; }
        public string Description { get; private set; }
        public int CountryId { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public virtual Country Country { get; private set; }
        public virtual ICollection<Branch> Branch { get; private set; }
        public virtual ICollection<BusinessAccountAddress> BusinessAccountAddress { get; private set; }
        public virtual ICollection<City> City { get; private set; }
        public virtual ICollection<Warehouse> Warehouse { get; private set; }
    }
}
