﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class CompanyType
    {
        public CompanyType(string name, string code, string description,  string createdBy) : this()
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Code = code ?? throw new ArgumentNullException(nameof(code));
            Description = description ?? throw new ArgumentNullException(nameof(description));
            IsActive = true;
            IsDelete = false;
            CreatedAt = DateTime.UtcNow;
            CreatedBy = createdBy;
        }

        private CompanyType()
        {
            Company = new HashSet<Company>();
        }

        public int Id { get; private set; }
        public string Name { get; private set; }
        public string Code { get; private set; }
        public string Description { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }



        public virtual ICollection<Company> Company { get; private set; }
    }
}
