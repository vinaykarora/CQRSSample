﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class SaleOrderLineItem : IValidatableObject
    {
        private SaleOrderLineItem()
        {

        }

        internal SaleOrderLineItem(short numProducts, Product chosenProduct, byte lineNum) : this()
        {
            UnitQuantity = numProducts;
            Product = chosenProduct ?? throw new ArgumentNullException(nameof(chosenProduct));
            UnitPrice = chosenProduct.DefaultSalePrice;
            //LineNum = lineNum;
        }

        public int Id { get; private set; }
        public int BranchId { get; private set; }
        public int SaleOrderId { get; private set; }
        public int ProductId { get; private set; }
        public string Description { get; private set; }
        public decimal UnitQuantity { get; private set; }
        public decimal DeliveredUnitQuantity { get; private set; }
        public decimal UnitPrice { get; private set; }
        public int UnitId { get; private set; }
        public int SizeId { get; private set; }
        public int MakeId { get; private set; }
        public int ColorId { get; private set; }
        public int StyleId { get; private set; }
        public int ModelId { get; private set; }
        public decimal TotalUnitPrice { get; private set; }
        public decimal DiscountPercentage { get; private set; }
        public decimal DiscountPrice { get; private set; }
        public decimal TotalTaxablePrice { get; private set; }
        public decimal TaxPercentage { get; private set; }
        public decimal Cgstpercentage { get; private set; }
        public decimal TotalCgstprice { get; private set; }
        public decimal Sgstpercentage { get; private set; }
        public decimal TotalSgstprice { get; private set; }
        public decimal Igstpercentage { get; private set; }
        public decimal TotalIgstprice { get; private set; }
        public decimal TotalPrice { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required] public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual Branch Branch { get; private set; }
        public virtual Color Color { get; private set; }
        
        
        public virtual Make Make { get; private set; }
        public virtual Model Model { get; private set; }
        public virtual Product Product { get; private set; }
        public virtual SaleOrder SaleOrder { get; private set; }
        public virtual Size Size { get; private set; }
        public virtual Style Style { get; private set; }
        public virtual Unit Unit { get; private set; }

        /// <summary>
        /// Extra validation rules: These are checked by using the SaveChangesWithValidation method when saving to the database
        /// </summary>
        /// <param name="validationContext"></param>
        /// <returns></returns>
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (UnitPrice < 0)
            {
                yield return new ValidationResult($"Sorry, the product '{Product.Name}' is not for sale.");
            }

            if (UnitQuantity > 100)
            {
                yield return new ValidationResult("If you want to order a 100 or more products please phone us on 01234-5678-90", new[] { nameof(UnitQuantity) });
            }
        }
    }
}
