﻿using YK.IMS.Core.Status;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.Requests.Customers;
using Microsoft.EntityFrameworkCore;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class BusinessAccount
    {
        private BusinessAccount()
        {
            CreditNote = new HashSet<CreditNote>();
            DebitNote = new HashSet<DebitNote>();
            DeliveryNote = new HashSet<DeliveryNote>();
            GeneralLedger = new HashSet<GeneralLedger>();
            ProductBusinessAccountMap = new HashSet<ProductBusinessAccountMap>();
            Purchase = new HashSet<Purchase>();
            PurchaseOrder = new HashSet<PurchaseOrder>();
            Sale = new HashSet<Sale>();
            SaleOrder = new HashSet<SaleOrder>();
        }

        public int Id { get; private set; }
        public int CompanyId { get; private set; }
        public string Name { get; private set; }
        public string Code { get; private set; }
        public string Description { get; private set; }
        public Core.Enums.BusinessType BusinessType { get; private set; }
        public string TaxNumber { get; private set; }
        public int? AssignedTo { get; private set; }
        public int? DefaultStockLocation { get; private set; }
        public decimal DefaultDiscountPercentage { get; private set; }
        public int? DefaultPaymentTerm { get; private set; }
        public int? DefaultPaymentMethod { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual BusinessType BusinessTypeNavigation { get; private set; }
        public virtual Company Company { get; private set; }

        private HashSet<BusinessAccountAddress> _businessAccountAddresses = null;
        public IEnumerable<BusinessAccountAddress> BusinessAccountAddresses => _businessAccountAddresses?.ToList();

        public virtual ICollection<CreditNote> CreditNote { get; private set; }
        public virtual ICollection<DebitNote> DebitNote { get; private set; }
        public virtual ICollection<DeliveryNote> DeliveryNote { get; private set; }
        public virtual ICollection<GeneralLedger> GeneralLedger { get; private set; }
        public virtual ICollection<ProductBusinessAccountMap> ProductBusinessAccountMap { get; private set; }
        public virtual ICollection<Purchase> Purchase { get; private set; }
        public virtual ICollection<PurchaseOrder> PurchaseOrder { get; private set; }
        public virtual ICollection<Sale> Sale { get; private set; }
        public virtual ICollection<SaleOrder> SaleOrder { get; private set; }

        public static IStatusGeneric<BusinessAccount> CreateBusinessAccountFactory(CreateCustomerRequest request, string createdBy)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request), $"You must provide {nameof(CreateCustomerRequest)}.");
            }

            StatusGenericHandler<BusinessAccount> status = new StatusGenericHandler<BusinessAccount>();

            if (string.IsNullOrWhiteSpace(request.Name)) { status.AddError($"{nameof(request.Name)} Is Required", nameof(request.Name)); }
            if (string.IsNullOrWhiteSpace(request.Code)) { status.AddError($"{nameof(request.Code)} Is Required", nameof(request.Code)); }
            if (string.IsNullOrWhiteSpace(request.Description)) { status.AddError($"{nameof(request.Description)} Is Required", nameof(request.Description)); }
            if (string.IsNullOrWhiteSpace(request.TaxNumber)) { status.AddError($"{nameof(request.TaxNumber)} Is Required", nameof(request.TaxNumber)); }
            if (string.IsNullOrWhiteSpace(createdBy)) { status.AddError($"{nameof(createdBy)} Is Required", nameof(createdBy)); }
            //if (!request.AssignedTo.HasValue || request.AssignedTo.Value <= 0) { status.AddError($"{nameof(request.AssignedTo)} Is Required", nameof(request.AssignedTo)); }
            //if (!request.DefaultStockLocation.HasValue || request.DefaultStockLocation.Value <= 0) { status.AddError($"{nameof(request.DefaultStockLocation)} Is Required", nameof(request.DefaultStockLocation)); }
            //if (!request.DefaultPaymentTerm.HasValue || request.DefaultPaymentTerm.Value <= 0) { status.AddError($"{nameof(request.DefaultPaymentTerm)} Is Required", nameof(request.DefaultPaymentTerm)); }
            //if (!request.DefaultPaymentMethod.HasValue || request.DefaultPaymentMethod.Value <= 0) { status.AddError($"{nameof(request.DefaultPaymentMethod)} Is Required", nameof(request.DefaultPaymentMethod)); }

            if (status.HasErrors)
                return status;

            BusinessAccount businessAccount = new BusinessAccount()
            {
                CompanyId = request.CompanyId,
                Name = request.Name.Trim(),
                Code = request.Code.Trim(),
                Description = request.Description.Trim(),
                BusinessType = request.BusinessType,
                TaxNumber = request.TaxNumber.Trim(),
                AssignedTo = request.AssignedTo,
                DefaultStockLocation = request.DefaultStockLocation,
                DefaultDiscountPercentage = request.DefaultDiscountPercentage,
                DefaultPaymentTerm = request.DefaultPaymentTerm,
                DefaultPaymentMethod = request.DefaultPaymentMethod,
                IsActive = true,
                IsDelete = false,
                CreatedAt = DateTime.UtcNow,
                CreatedBy = createdBy
            };

            var addressStatus = BusinessAccountAddress.CreateBusinessAccountAddressFactory(request.Address);

            if (!addressStatus.HasErrors)
            {
                if (businessAccount._businessAccountAddresses == null)
                {
                    businessAccount._businessAccountAddresses = new HashSet<BusinessAccountAddress>();
                }
                businessAccount._businessAccountAddresses.Add(addressStatus.Result);
            }

            status.CombineErrors(addressStatus);
            status.Result = businessAccount;
            return status;
        }

        public IStatusGeneric ChangeCode(string code)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(code))
            {
                status.AddError("Code Is Required", nameof(code));
            }

            Code = code.Trim();
            return status;
        }

        public IStatusGeneric ChangeTaxNumber(string taxNumber)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(taxNumber))
            {
                status.AddError($"{nameof(taxNumber)} Is Required", nameof(taxNumber));
            }

            TaxNumber = taxNumber.Trim();
            return status;
        }

        public IStatusGeneric ChangeName(string name)
        {
            StatusGenericHandler status = new StatusGenericHandler();

            if (string.IsNullOrEmpty(name))
            {
                status.AddError("Name Is Required", nameof(Name));
            }
            Name = name.Trim();
            return status;
        }

        public IStatusGeneric ChangeDescription(string description)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(description))
            {
                //status.AddError("Description Is Required", nameof(description));

            }
            Description = description.Trim();
            return status;
        }

        public IStatusGeneric ChangeUpdatedBy(string userId)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrWhiteSpace(userId))
            {
                status.AddError($"{nameof(userId)} Is Required", nameof(userId));
            }

            LastUpdatedBy = userId;
            LastUpdatedAt = DateTime.UtcNow;
            return status;
        }

        public IStatusGeneric AddAddress(BusinessAccountAddress businessAccountAddress, IMSContext context)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (_businessAccountAddresses != null)
            {
                _businessAccountAddresses.Add(businessAccountAddress);
            }
            else if (context == null)
            {
                throw new ArgumentNullException(nameof(context), $"You must provide a context if the {nameof(BusinessAccountAddresses)} collection isn't valid.");
            }
            else if (context.Entry(this).IsKeySet)
            {
                context.Add(businessAccountAddress);
            }
            else
            {
                throw new InvalidOperationException("Could not add a new address.");
            }

            return status;
        }

        public IStatusGeneric UpdateAddress(BusinessAccountAddress businessAccountAddress, DbContext context)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (context == null)
            {
                throw new ArgumentNullException(nameof(context), $"You must provide a context if the {nameof(BusinessAccountAddresses)} collection isn't valid.");
            }
            else if (context.Entry(this).IsKeySet)
            {
                context.Update(businessAccountAddress);
            }
            else
            {
                throw new InvalidOperationException("Could not update a new address.");
            }

            return status;
        }

        public void RemoveAddress()
        {

        }

        public void Delete()
        {
            IsDelete = true;
        }
    }
}
