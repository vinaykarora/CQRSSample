﻿using YK.IMS.Core.Status;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class Product
    {
        public const int NameLength = 100;
        public const int CodeLength = 50;
        public const int DescriptionLength = 500;
        public const int BarcodeLength = 50;
        private Product()
        {
            CreditNoteLineItem = new HashSet<CreditNoteLineItem>();
            DebitNoteLineItem = new HashSet<DebitNoteLineItem>();
            DeliveryNoteLineItem = new HashSet<DeliveryNoteLineItem>();
            ProductBusinessAccountMap = new HashSet<ProductBusinessAccountMap>();
            ProductStocks = new HashSet<ProductStock>();
            ProductUnitQuantityMap = new HashSet<ProductUnitQuantityMap>();
            PurchaseLineItem = new HashSet<PurchaseLineItem>();
            PurchaseOrderLineItem = new HashSet<PurchaseOrderLineItem>();
            SaleLineItem = new HashSet<SaleLineItem>();
            SaleOrderLineItem = new HashSet<SaleOrderLineItem>();
        }

        public int Id { get; private set; }
        public int CompanyId { get; private set; }
        [Required(AllowEmptyStrings = false)]
        [MaxLength(NameLength)]
        public string Name { get; private set; }
        [Required(AllowEmptyStrings = false)]
        [MaxLength(CodeLength)]
        public string Code { get; private set; }
        [MaxLength(DescriptionLength)]
        public string Description { get; private set; }
        [MaxLength(BarcodeLength)]
        public string Barcode { get; private set; }
        public int MaterialTypeId { get; private set; }
        public int ProductGroupId { get; private set; }
        public int UnitId { get; private set; }
        public int RetailUnitId { get; private set; }
        public int SizeId { get; private set; }
        public int MakeId { get; private set; }
        public int ColorId { get; private set; }
        public int StyleId { get; private set; }
        public int ChapterHeadingId { get; private set; }
        public int PackSizeId { get; private set; }
        public int ModelId { get; private set; }
        public decimal DefaultSalePrice { get; private set; }
        public decimal RetailSalePrice { get; private set; }
        public decimal DefaultPurchasePrice { get; private set; }
        public decimal DefaultDiscountPercentage { get; private set; }
        public decimal DefaultDiscountPrice { get; private set; }
        public decimal TaxPercentage { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }
        public string RackNumber { get; private set; }

        public virtual ChapterHeading ChapterHeading { get; private set; }
        public virtual Color Color { get; private set; }
        public virtual Company Company { get; private set; }


        public virtual Make Make { get; private set; }
        public virtual MaterialType MaterialType { get; private set; }
        public virtual Model Model { get; private set; }
        public virtual PackSize PackSize { get; private set; }
        public virtual ProductGroup ProductGroup { get; private set; }
        public virtual Unit RetailUnit { get; private set; }
        public virtual Size Size { get; private set; }
        public virtual Style Style { get; private set; }
        public virtual Unit Unit { get; private set; }
        public virtual ICollection<CreditNoteLineItem> CreditNoteLineItem { get; private set; }
        public virtual ICollection<DebitNoteLineItem> DebitNoteLineItem { get; private set; }
        public virtual ICollection<DeliveryNoteLineItem> DeliveryNoteLineItem { get; private set; }
        public virtual ICollection<ProductBusinessAccountMap> ProductBusinessAccountMap { get; private set; }
        public virtual ICollection<ProductStock> ProductStocks { get; private set; }
        public virtual ICollection<ProductUnitQuantityMap> ProductUnitQuantityMap { get; private set; }
        public virtual ICollection<PurchaseLineItem> PurchaseLineItem { get; private set; }
        public virtual ICollection<PurchaseOrderLineItem> PurchaseOrderLineItem { get; private set; }
        public virtual ICollection<SaleLineItem> SaleLineItem { get; private set; }
        public virtual ICollection<SaleOrderLineItem> SaleOrderLineItem { get; private set; }

        public void UpdatePublishedOn(DateTime newDate)
        {
            //PublishedOn = newDate;
        }

        public void AddItemToStock(decimal openingQuantity, string createdBy, DbContext context = null)
        {
            IStatusGeneric<ProductStock> status = ProductStock.AddOpeningStock(1, openingQuantity, createdBy);
            if (!status.HasErrors && ProductStocks != null)
            {
                ProductStocks.Add(status.Result);
            }
            else if (context == null)
            {
                throw new ArgumentNullException(nameof(context), "You must provide a context if the ProductStocks collection isn't valid.");
            }
            else if (!status.HasErrors && context.Entry(this).IsKeySet)
            {
                context.Add(status.Result);
            }
            else
            {
                throw new InvalidOperationException("Could not add a new product stock.");
            }
        }

        public void AddReview(int numStars, string comment, string voterName, DbContext context = null)
        {
            //if (_reviews != null)
            //{
            //    _reviews.Add(new Review(numStars, comment, voterName));
            //}
            //else if (context == null)
            //{
            //    throw new ArgumentNullException(nameof(context),
            //        "You must provide a context if the Reviews collection isn't valid.");
            //}
            //else if (context.Entry(this).IsKeySet)
            //{
            //    context.Add(new Review(numStars, comment, voterName, BookId));
            //}
            //else
            //{
            //    throw new InvalidOperationException("Could not add a new review.");
            //}
        }



        public void RemoveReview(object review)
        {
            //if (_reviews == null)
            //{
            //    throw new NullReferenceException("You must use .Include(p => p.Reviews) before calling this method.");
            //}

            //_reviews.Remove(review);
        }

        public IStatusGeneric AddPromotion(decimal newPrice, string promotionalText)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrWhiteSpace(promotionalText))
            {
                return status.AddError("You must provide some text to go with the promotion.", nameof(promotionalText));
            }

            DefaultSalePrice = newPrice;
            //PromotionalText = promotionalText;
            return status;
        }

        public void RemovePromotion()
        {
            //ActualPrice = OrgPrice;
            //PromotionalText = null;
        }

        public static IStatusGeneric<Product> CreateProductFactory(int companyId, string name, string code, string description, string barcode, int materialTypeId, int productGroupId, int unitId, int retailUnitId, int sizeId, int makeId, int colorId, int styleId, int chapterHeadingId, int packSizeId, int modelId, decimal defaultSalePrice, decimal retailSalePrice, decimal defaultPurchasePrice, decimal defaultDiscountPercentage, decimal defaultDiscountPrice, decimal taxPercentage, bool isActive, bool isDelete, string createdBy, string rackNumber)
        {
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }

            if (code == null)
            {
                throw new ArgumentNullException(nameof(code));
            }

            if (description == null)
            {
                throw new ArgumentNullException(nameof(description));
            }

            StatusGenericHandler<Product> status = new StatusGenericHandler<Product>();
            Product product = new Product()
            {
                CompanyId = companyId,
                Name = name.Trim(),
                Code = code.Trim(),
                Description = description.Trim(),
                Barcode = barcode.Trim(),
                MaterialTypeId = materialTypeId,
                ProductGroupId = productGroupId,
                UnitId = unitId,
                RetailUnitId = retailUnitId,
                SizeId = sizeId,
                MakeId = makeId,
                ColorId = colorId,
                StyleId = styleId,
                ChapterHeadingId = chapterHeadingId,
                PackSizeId = packSizeId,
                ModelId = modelId,
                DefaultSalePrice = defaultSalePrice,
                RetailSalePrice = retailSalePrice,
                DefaultPurchasePrice = defaultPurchasePrice,
                DefaultDiscountPercentage = defaultDiscountPercentage,
                DefaultDiscountPrice = defaultDiscountPrice,
                TaxPercentage = taxPercentage,
                IsActive = isActive,
                IsDelete = isDelete,
                CreatedBy = createdBy,
                CreatedAt = DateTime.UtcNow,
                RackNumber = rackNumber
            };

            status.CombineErrors(product.IsValid());
            status.Result = product;
            return status;
        }

        public IStatusGeneric<Product> UpdateProduct(int companyId,
            string name,
            string code,
            string description,
            string barcode,
            int materialTypeId,
            int productGroupId,
            int unitId,
            int retailUnitId,
            int sizeId,
            int makeId,
            int colorId,
            int styleId,
            int chapterHeadingId,
            int packSizeId,
            int modelId,
            decimal defaultSalePrice,
            decimal retailSalePrice,
            decimal defaultPurchasePrice,
            decimal defaultDiscountPercentage,
            decimal defaultDiscountPrice,
            decimal taxPercentage,
            bool isActive,
            bool isDelete,
            string createdBy,
            string rackNumber)
        {
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }

            if (code == null)
            {
                throw new ArgumentNullException(nameof(code));
            }

            if (description == null)
            {
                throw new ArgumentNullException(nameof(description));
            }

            StatusGenericHandler<Product> status = new StatusGenericHandler<Product>();

            CompanyId = companyId;
            Name = name.Trim();
            Code = code.Trim();
            Description = description.Trim();
            Barcode = barcode.Trim();
            MaterialTypeId = materialTypeId;
            ProductGroupId = productGroupId;
            UnitId = unitId;
            RetailUnitId = retailUnitId;
            SizeId = sizeId;
            MakeId = makeId;
            ColorId = colorId;
            StyleId = styleId;
            ChapterHeadingId = chapterHeadingId;
            PackSizeId = packSizeId;
            ModelId = modelId;
            DefaultSalePrice = defaultSalePrice;
            RetailSalePrice = retailSalePrice;
            DefaultPurchasePrice = defaultPurchasePrice;
            DefaultDiscountPercentage = defaultDiscountPercentage;
            DefaultDiscountPrice = defaultDiscountPrice;
            TaxPercentage = taxPercentage;
            IsActive = isActive;
            IsDelete = isDelete;
            LastUpdatedBy = createdBy;
            LastUpdatedAt = DateTime.UtcNow;
            RackNumber = rackNumber;

            status.CombineErrors(IsValid());
            status.Result = this;
            return status;
        }

        public IStatusGeneric ChangeCode(string code)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(code))
            {
                status.AddError("Code Is Required", nameof(code));
            }

            Code = code.Trim();
            return status;
        }

        public IStatusGeneric ChangeName(string name)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(name))
            {
                status.AddError("Name Is Required", nameof(name));
            }

            Name = name.Trim();
            return status;
        }

        public IStatusGeneric ChangeDescription(string description)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(description))
            {
                //status.AddError("Description Is Required", nameof(description));
            }

            Description = description.Trim();
            return status;
        }

        public IStatusGeneric ChangeUpdatedBy(string userId)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrWhiteSpace(userId))
            {
                status.AddError($"{nameof(userId)} Is Required", nameof(userId));
            }

            LastUpdatedBy = userId;
            LastUpdatedAt = DateTime.UtcNow;
            return status;
        }

        public void Delete()
        {
            IsDelete = true;
        }

        public IStatusGeneric IsValid()
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (CompanyId <= 0)
            {
                status.AddError($"Negetive {nameof(CompanyId)} is invalid.", nameof(CompanyId));
            }

            if (string.IsNullOrWhiteSpace(Name))
            {
                status.AddError($"Null or empty {nameof(Name)} is invalid.", nameof(Name));
            }

            if (string.IsNullOrWhiteSpace(Code))
            {
                status.AddError($"Null or empty {nameof(Code)} is invalid.", nameof(Code));
            }

            if (string.IsNullOrWhiteSpace(Description))
            {
                // status.AddError($"Null or empty {nameof(Description)} is invalid.", nameof(Description));
            }

            if (!IsActive)
            {
                status.AddError($"Inactive entry is invalid.", nameof(IsActive));
            }

            if (IsDelete)
            {
                status.AddError($"Delete entry is invalid.", nameof(IsDelete));
            }

            if (CreatedAt == DateTime.MinValue)
            {
                status.AddError($"Null or empty {nameof(CreatedAt)} is invalid.", nameof(CreatedAt));
            }

            if (string.IsNullOrWhiteSpace(CreatedBy))
            {
                status.AddError($"Null or empty {nameof(CreatedBy)} is invalid.", nameof(CreatedBy));
            }

            return status;
        }
    }
}
