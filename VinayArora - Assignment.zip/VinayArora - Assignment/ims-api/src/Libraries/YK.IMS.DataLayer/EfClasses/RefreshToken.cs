﻿using System;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class RefreshToken
    {
        private RefreshToken()
        {

        }

        internal RefreshToken(string token, DateTime expires, string applicationUserId, string remoteIpAddress)
        {
            Token = token;
            Expires = expires;
            ApplicationUserId = applicationUserId;
            RemoteIpAddress = remoteIpAddress;
            CreatedAt = DateTime.UtcNow;
        }

        public int Id { get; set; }
        public string Token { get; private set; }
        public DateTime Expires { get; private set; }
        public string ApplicationUserId { get; private set; }
        public bool Active => DateTime.UtcNow <= Expires;
        public string RemoteIpAddress { get; private set; }
        public DateTime CreatedAt { get; private set; }
        public virtual ApplicationUser ApplicationUser { get; private set; }
    }
}
