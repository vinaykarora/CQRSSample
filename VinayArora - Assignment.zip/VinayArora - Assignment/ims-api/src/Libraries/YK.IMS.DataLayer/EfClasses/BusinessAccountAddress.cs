﻿using YK.IMS.Core.Status;
using System;
using System.ComponentModel.DataAnnotations;
using YK.IMS.Core.Enums;
using YK.IMS.DataLayer.Requests.Customers;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class BusinessAccountAddress
    {
        internal BusinessAccountAddress()
        {

        }

        public int Id { get; private set; }
        public int CompanyId { get; private set; }
        public AddressType AddressType { get; private set; }
        public int BusinessAccountId { get; private set; }
        public int CountryId { get; private set; }
        public int StateId { get; private set; }
        public int CityId { get; private set; }
        public string Address1 { get; private set; }
        public string Address2 { get; private set; }
        public string Address3 { get; private set; }
        public string Pincode { get; private set; }
        public string Phone { get; private set; }
        public string Mobile { get; private set; }
        public string Email { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual BusinessAccount BusinessAccount { get; private set; }
        public virtual City City { get; private set; }
        public virtual Company Company { get; private set; }
        public virtual Country Country { get; private set; }
        public virtual State State { get; private set; }

        public static IStatusGeneric<BusinessAccountAddress> CreateBusinessAccountAddressFactory(AddAddressRequest request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request), $"You must provide {nameof(AddAddressRequest)}.");
            }

            StatusGenericHandler<BusinessAccountAddress> status = new StatusGenericHandler<BusinessAccountAddress>();

            if (request.CompanyId <= 0) { status.AddError($"{nameof(request.CompanyId)} Is Required", nameof(request.CompanyId)); }
            if (request.CountryId <= 0) { status.AddError($"{nameof(request.CountryId)} Is Required", nameof(request.CountryId)); }
            if (request.StateId <= 0) { status.AddError($"{nameof(request.StateId)} Is Required", nameof(request.StateId)); }
            if (request.CityId <= 0) { status.AddError($"{nameof(request.CityId)} Is Required", nameof(request.CityId)); }

            if (string.IsNullOrWhiteSpace(request.Address1)) { status.AddError($"{nameof(request.Address1)} Is Required", nameof(request.Address1)); }
            if (string.IsNullOrWhiteSpace(request.Address2)) { status.AddError($"{nameof(request.Address2)} Is Required", nameof(request.Address2)); }
            if (string.IsNullOrWhiteSpace(request.Address3)) { status.AddError($"{nameof(request.Address3)} Is Required", nameof(request.Address3)); }
            if (string.IsNullOrWhiteSpace(request.Pincode)) { status.AddError($"{nameof(request.Pincode)} Is Required", nameof(request.Pincode)); }
            if (string.IsNullOrWhiteSpace(request.CreatedBy)) { status.AddError($"{nameof(request.CreatedBy)} Is Required", nameof(request.CreatedBy)); }
            if (string.IsNullOrWhiteSpace(request.Phone)) { status.AddError($"{nameof(request.Phone)} Is Required", nameof(request.Phone)); }
            if (string.IsNullOrWhiteSpace(request.Mobile)) { status.AddError($"{nameof(request.Mobile)} Is Required", nameof(request.Mobile)); }
            if (string.IsNullOrWhiteSpace(request.Email)) { status.AddError($"{nameof(request.Email)} Is Required", nameof(request.Email)); }

            if (status.HasErrors)
                return status;

            BusinessAccountAddress businessAccountAddress = new BusinessAccountAddress()
            {
                AddressType = request.AddressType,
                CompanyId = request.CompanyId,
                CountryId = request.CountryId,
                StateId = request.StateId,
                CityId = request.CityId,
                Address1 = request.Address1.Trim(),
                Address2 = request.Address2.Trim(),
                Address3 = request.Address3.Trim(),
                Pincode = request.Pincode.Trim(),
                Phone = request.Phone.Trim(),
                Mobile = request.Mobile.Trim(),
                Email = request.Email.Trim(),
                IsActive = true,
                IsDelete = false,
                CreatedAt = DateTime.UtcNow,
                CreatedBy = request.CreatedBy,
            };

            status.Result = businessAccountAddress;
            return status;
        }

        public IStatusGeneric<BusinessAccountAddress> Update(AddAddressRequest request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request), $"You must provide {nameof(AddAddressRequest)}.");
            }

            StatusGenericHandler<BusinessAccountAddress> status = new StatusGenericHandler<BusinessAccountAddress>();

            if (request.CompanyId <= 0) { status.AddError($"{nameof(request.CompanyId)} Is Required", nameof(request.CompanyId)); }
            if (request.CountryId <= 0) { status.AddError($"{nameof(request.CountryId)} Is Required", nameof(request.CountryId)); }
            if (request.StateId <= 0) { status.AddError($"{nameof(request.StateId)} Is Required", nameof(request.StateId)); }
            if (request.CityId <= 0) { status.AddError($"{nameof(request.CityId)} Is Required", nameof(request.CityId)); }

            if (string.IsNullOrWhiteSpace(request.Address1)) { status.AddError($"{nameof(request.Address1)} Is Required", nameof(request.Address1)); }
            if (string.IsNullOrWhiteSpace(request.Address2)) { status.AddError($"{nameof(request.Address2)} Is Required", nameof(request.Address2)); }
            if (string.IsNullOrWhiteSpace(request.Address3)) { status.AddError($"{nameof(request.Address3)} Is Required", nameof(request.Address3)); }
            if (string.IsNullOrWhiteSpace(request.Pincode)) { status.AddError($"{nameof(request.Pincode)} Is Required", nameof(request.Pincode)); }
            if (string.IsNullOrWhiteSpace(request.CreatedBy)) { status.AddError($"{nameof(request.CreatedBy)} Is Required", nameof(request.CreatedBy)); }
            if (string.IsNullOrWhiteSpace(request.Phone)) { status.AddError($"{nameof(request.Phone)} Is Required", nameof(request.Phone)); }
            if (string.IsNullOrWhiteSpace(request.Mobile)) { status.AddError($"{nameof(request.Mobile)} Is Required", nameof(request.Mobile)); }

            if (status.HasErrors)
                return status;


            AddressType = request.AddressType;
            CompanyId = request.CompanyId;
            CountryId = request.CountryId;
            StateId = request.StateId;
            CityId = request.CityId;
            Address1 = request.Address1.Trim();
            Address2 = request.Address2.Trim();
            Address3 = request.Address3.Trim();
            Pincode = request.Pincode.Trim();
            Phone = request.Phone.Trim();
            Mobile = request.Mobile.Trim();
            IsActive = true;
            IsDelete = false;
            LastUpdatedAt = DateTime.UtcNow;
            LastUpdatedBy = request.CreatedBy;

            status.Result = this;
            return status;
        }
    }
}
