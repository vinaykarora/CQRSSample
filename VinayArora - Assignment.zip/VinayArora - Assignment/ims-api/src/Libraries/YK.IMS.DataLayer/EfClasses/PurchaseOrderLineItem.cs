﻿using System;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class PurchaseOrderLineItem
    {
        private PurchaseOrderLineItem()
        {

        }
        internal PurchaseOrderLineItem(int branchId, int purchaseOrderId, int productId, string description, decimal unitQuantity, decimal receivedUnitQuantity, decimal unitPrice, int unitId, int sizeId, int makeId, int colorId, int styleId, int modelId, decimal totalUnitPrice, decimal discountPercentage, decimal discountPrice, decimal totalTaxablePrice, decimal taxPercentage, decimal cgstpercentage, decimal totalCgstprice, decimal sgstpercentage, decimal totalSgstprice, decimal igstpercentage, decimal totalIgstprice, decimal totalPrice, bool isActive, bool isDelete, string createdBy) : this()
        {
            BranchId = branchId;
            PurchaseOrderId = purchaseOrderId;
            ProductId = productId;
            Description = description ?? throw new ArgumentNullException(nameof(description));
            UnitQuantity = unitQuantity;
            ReceivedUnitQuantity = receivedUnitQuantity;
            UnitPrice = unitPrice;
            UnitId = unitId;
            SizeId = sizeId;
            MakeId = makeId;
            ColorId = colorId;
            StyleId = styleId;
            ModelId = modelId;
            TotalUnitPrice = totalUnitPrice;
            DiscountPercentage = discountPercentage;
            DiscountPrice = discountPrice;
            TotalTaxablePrice = totalTaxablePrice;
            TaxPercentage = taxPercentage;
            Cgstpercentage = cgstpercentage;
            TotalCgstprice = totalCgstprice;
            Sgstpercentage = sgstpercentage;
            TotalSgstprice = totalSgstprice;
            Igstpercentage = igstpercentage;
            TotalIgstprice = totalIgstprice;
            TotalPrice = totalPrice;
            IsActive = isActive;
            IsDelete = isDelete;
            CreatedBy = createdBy;
            CreatedAt = DateTime.UtcNow;
        }

        public int Id { get; private set; }
        public int BranchId { get; private set; }
        public int PurchaseOrderId { get; private set; }
        public int ProductId { get; private set; }
        public string Description { get; private set; }
        public decimal UnitQuantity { get; private set; }
        public decimal ReceivedUnitQuantity { get; private set; }
        public decimal UnitPrice { get; private set; }
        public int UnitId { get; private set; }
        public int SizeId { get; private set; }
        public int MakeId { get; private set; }
        public int ColorId { get; private set; }
        public int StyleId { get; private set; }
        public int ModelId { get; private set; }
        public decimal TotalUnitPrice { get; private set; }
        public decimal DiscountPercentage { get; private set; }
        public decimal DiscountPrice { get; private set; }
        public decimal TotalTaxablePrice { get; private set; }
        public decimal TaxPercentage { get; private set; }
        public decimal Cgstpercentage { get; private set; }
        public decimal TotalCgstprice { get; private set; }
        public decimal Sgstpercentage { get; private set; }
        public decimal TotalSgstprice { get; private set; }
        public decimal Igstpercentage { get; private set; }
        public decimal TotalIgstprice { get; private set; }
        public decimal TotalPrice { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual Branch Branch { get; private set; }
        public virtual Color Color { get; private set; }


        public virtual Make Make { get; private set; }
        public virtual Model Model { get; private set; }
        public virtual Product Product { get; private set; }
        public virtual PurchaseOrder PurchaseOrder { get; private set; }
        public virtual Size Size { get; private set; }
        public virtual Style Style { get; private set; }
        public virtual Unit Unit { get; private set; }
    }
}
