﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using YK.IMS.DataLayer.EfCode;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class ApplicationUser : IdentityUser
    {
        public ApplicationUser(int? companyId, string name, string code, string description, string createdBy)
        {
            CompanyId = companyId ?? throw new ArgumentNullException(nameof(companyId));
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Code = code ?? throw new ArgumentNullException(nameof(code));
            Description = description ?? throw new ArgumentNullException(nameof(description));
            IsActive = true;
            CreatedBy = createdBy;
            CreatedAt = DateTime.UtcNow;
            IsDelete = false;
        }

        private ApplicationUser()
        {

        }

        public int? CompanyId { get; private set; }
        public string Name { get; private set; }
        public string Code { get; private set; }
        public string Description { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        private HashSet<RefreshToken> _refreshTokens = null;
        public IEnumerable<RefreshToken> RefreshTokens => _refreshTokens?.ToList();


        public bool HasValidRefreshToken(string refreshToken)
        {
            return _refreshTokens.Any(rt => rt.Token == refreshToken && rt.Active);
        }

        public void AddRefreshToken(string token, string remoteIpAddress, ApplicationDbContext applicationDbContext, double daysToExpire = 5)
        {
            if (_refreshTokens != null)
            {
                _refreshTokens.Add(new RefreshToken(token, DateTime.UtcNow.AddDays(daysToExpire), Id, remoteIpAddress));
            }
            else if (applicationDbContext == null)
            {
                throw new ArgumentNullException(nameof(applicationDbContext), "You must provide a context if the RefreshToken collection isn't valid.");
            }
            else if (applicationDbContext.Entry(this).IsKeySet)
            {
                applicationDbContext.Add(new RefreshToken(token, DateTime.UtcNow.AddDays(daysToExpire), Id, remoteIpAddress));
            }
            else
            {
                throw new InvalidOperationException("Could not add a new refresh token.");
            }
        }

        public void RemoveRefreshToken(string refreshToken)
        {
            var token = _refreshTokens.First(t => t.Token == refreshToken);
            RemoveRefreshToken(token);
        }

        public void RemoveRefreshToken(RefreshToken refreshToken)
        {
            if (_refreshTokens == null)
                throw new NullReferenceException("You must use .Include(p => p.RefreshToken) before calling this method.");

            _refreshTokens.Remove(refreshToken);
        }
    }
}
