﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class Purchase
    {
        public Purchase(int branchId, int businessAccountId, int? deliveryNoteId, DateTime receiveDate, string invoiceNumber, string description, decimal totalUnitQuantity, decimal totalUnitPrice, decimal discountPercentage, decimal totalDiscountPrice, int totalsAre, decimal totalTaxablePrice, decimal taxPercentage, decimal cgstpercentage, decimal totalCgstprice, decimal sgstpercentage, decimal totalSgstprice, decimal igstpercentage, decimal totalIgstprice, decimal totalPrice, bool isActive, bool isDelete, string createdBy) : this()
        {
            BranchId = branchId;
            BusinessAccountId = businessAccountId;
            DeliveryNoteId = deliveryNoteId ?? throw new ArgumentNullException(nameof(deliveryNoteId));
            ReceiveDate = receiveDate;
            InvoiceNumber = invoiceNumber ?? throw new ArgumentNullException(nameof(invoiceNumber));
            Description = description ?? throw new ArgumentNullException(nameof(description));
            TotalUnitQuantity = totalUnitQuantity;
            TotalUnitPrice = totalUnitPrice;
            DiscountPercentage = discountPercentage;
            TotalDiscountPrice = totalDiscountPrice;
            TotalsAre = totalsAre;
            TotalTaxablePrice = totalTaxablePrice;
            TaxPercentage = taxPercentage;
            Cgstpercentage = cgstpercentage;
            TotalCgstprice = totalCgstprice;
            Sgstpercentage = sgstpercentage;
            TotalSgstprice = totalSgstprice;
            Igstpercentage = igstpercentage;
            TotalIgstprice = totalIgstprice;
            TotalPrice = totalPrice;
            IsActive = isActive;
            IsDelete = isDelete;
            CreatedBy = createdBy;
            CreatedAt = DateTime.UtcNow;
        }

        private Purchase()
        {
            DebitNote = new HashSet<DebitNote>();
            PurchaseLineItem = new HashSet<PurchaseLineItem>();
        }

        public int Id { get; private set; }
        public int BranchId { get; private set; }
        public int BusinessAccountId { get; private set; }
        public int? DeliveryNoteId { get; private set; }
        public DateTime ReceiveDate { get; private set; }
        public string InvoiceNumber { get; private set; }
        public string Description { get; private set; }
        public decimal TotalUnitQuantity { get; private set; }
        public decimal TotalUnitPrice { get; private set; }
        public decimal DiscountPercentage { get; private set; }
        public decimal TotalDiscountPrice { get; private set; }
        public int TotalsAre { get; private set; }
        public decimal TotalTaxablePrice { get; private set; }
        public decimal TaxPercentage { get; private set; }
        public decimal Cgstpercentage { get; private set; }
        public decimal TotalCgstprice { get; private set; }
        public decimal Sgstpercentage { get; private set; }
        public decimal TotalSgstprice { get; private set; }
        public decimal Igstpercentage { get; private set; }
        public decimal TotalIgstprice { get; private set; }
        public decimal TotalPrice { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual Branch Branch { get; private set; }
        public virtual BusinessAccount BusinessAccount { get; private set; }

        public virtual DeliveryNote DeliveryNote { get; private set; }

        public virtual ICollection<DebitNote> DebitNote { get; private set; }
        public virtual ICollection<PurchaseLineItem> PurchaseLineItem { get; private set; }
    }
}
