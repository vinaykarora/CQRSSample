﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class Company
    {
        public Company(string name, string description, int? parentCompanyId, int companyTypeId, DateTime startingDate, DateTime endingDate, string taxNumber, string createdBy) : this()
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Description = description ?? throw new ArgumentNullException(nameof(description));
            ParentCompanyId = parentCompanyId;
            CompanyTypeId = companyTypeId;
            StartingDate = startingDate;
            EndingDate = endingDate;
            TaxNumber = taxNumber ?? throw new ArgumentNullException(nameof(taxNumber));
            CreatedAt = DateTime.UtcNow;
            CreatedBy = createdBy;
        }

        private Company()
        {
            Accounts = new HashSet<Accounts>();
            Branch = new HashSet<Branch>();
            BusinessAccount = new HashSet<BusinessAccount>();
            BusinessAccountAddress = new HashSet<BusinessAccountAddress>();
            BusinessType = new HashSet<BusinessType>();
            ChapterHeading = new HashSet<ChapterHeading>();
            Color = new HashSet<Color>();
            GeneralLedger = new HashSet<GeneralLedger>();
            InverseParentCompany = new HashSet<Company>();
            Make = new HashSet<Make>();
            MaterialType = new HashSet<MaterialType>();
            Model = new HashSet<Model>();
            PackSize = new HashSet<PackSize>();
            PaymentMethod = new HashSet<PaymentMethod>();
            PaymentTerm = new HashSet<PaymentTerm>();
            Product = new HashSet<Product>();
            ProductBusinessAccountMap = new HashSet<ProductBusinessAccountMap>();
            ProductGroup = new HashSet<ProductGroup>();
            ProductUnitQuantityMap = new HashSet<ProductUnitQuantityMap>();
            Size = new HashSet<Size>();
            Style = new HashSet<Style>();
            Unit = new HashSet<Unit>();
        }

        public int Id { get; private set; }
        public string Name { get; private set; }
        public string Description { get; private set; }
        public int? ParentCompanyId { get; private set; }
        public int CompanyTypeId { get; private set; }
        public DateTime StartingDate { get; private set; }
        public DateTime EndingDate { get; private set; }
        public string TaxNumber { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual CompanyType CompanyType { get; private set; }


        public virtual Company ParentCompany { get; private set; }
        public virtual ICollection<Accounts> Accounts { get; private set; }
        public virtual ICollection<Branch> Branch { get; private set; }
        public virtual ICollection<BusinessAccount> BusinessAccount { get; private set; }
        public virtual ICollection<BusinessAccountAddress> BusinessAccountAddress { get; private set; }
        public virtual ICollection<BusinessType> BusinessType { get; private set; }
        public virtual ICollection<ChapterHeading> ChapterHeading { get; private set; }
        public virtual ICollection<Color> Color { get; private set; }
        public virtual ICollection<GeneralLedger> GeneralLedger { get; private set; }
        public virtual ICollection<Company> InverseParentCompany { get; private set; }
        public virtual ICollection<Make> Make { get; private set; }
        public virtual ICollection<MaterialType> MaterialType { get; private set; }
        public virtual ICollection<Model> Model { get; private set; }
        public virtual ICollection<PackSize> PackSize { get; private set; }
        public virtual ICollection<PaymentMethod> PaymentMethod { get; private set; }
        public virtual ICollection<PaymentTerm> PaymentTerm { get; private set; }
        public virtual ICollection<Product> Product { get; private set; }
        public virtual ICollection<ProductBusinessAccountMap> ProductBusinessAccountMap { get; private set; }
        public virtual ICollection<ProductGroup> ProductGroup { get; private set; }
        public virtual ICollection<ProductUnitQuantityMap> ProductUnitQuantityMap { get; private set; }
        public virtual ICollection<Size> Size { get; private set; }
        public virtual ICollection<Style> Style { get; private set; }
        public virtual ICollection<Unit> Unit { get; private set; }
    }
}
