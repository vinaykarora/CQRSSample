﻿using YK.IMS.Core.Status;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using YK.IMS.DataLayer.Dtos;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class SaleOrder
    {
        private SaleOrder()
        {
            Sale = new HashSet<Sale>();
            SaleOrderLineItem = new HashSet<SaleOrderLineItem>();
        }

        public int Id { get; private set; }
        public int BranchId { get; private set; }
        public string SaleOrderNumber { get; private set; }
        public DateTime IssueDate { get; private set; }
        public DateTime StockDue { get; private set; }
        public DateTime PaymentDue { get; private set; }
        public int BusinessAccountId { get; private set; }
        public int Status { get; private set; }
        public string Description { get; private set; }
        public string DeliveryAddress { get; private set; }
        public decimal TotalUnitQuantity { get; private set; }
        public decimal TotalDeliveredUnitQuantity { get; private set; }
        public decimal TotalUnitPrice { get; private set; }
        public decimal DiscountPercentage { get; private set; }
        public decimal TotalDiscountPrice { get; private set; }
        public int TotalsAre { get; private set; }
        public decimal TotalTaxablePrice { get; private set; }
        public decimal TaxPercentage { get; private set; }
        public decimal Cgstpercentage { get; private set; }
        public decimal TotalCgstprice { get; private set; }
        public decimal Sgstpercentage { get; private set; }
        public decimal TotalSgstprice { get; private set; }
        public decimal Igstpercentage { get; private set; }
        public decimal TotalIgstprice { get; private set; }
        public decimal TotalPrice { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual Branch Branch { get; private set; }
        public virtual BusinessAccount BusinessAccount { get; private set; }
        public virtual ICollection<Sale> Sale { get; private set; }
        public virtual ICollection<SaleOrderLineItem> SaleOrderLineItem { get; private set; }
        public static IStatusGeneric<SaleOrder> CreateSaleOrderFactory(int businessAccountId, DateTime expectedDeliveryDate,
           IEnumerable<OrderProductsDto> productOrders)
        {
            StatusGenericHandler<SaleOrder> status = new StatusGenericHandler<SaleOrder>();
            byte lineNum = 1;
            SaleOrder SaleOrder = new SaleOrder
            {
                BusinessAccountId = businessAccountId,
                StockDue = expectedDeliveryDate,
                CreatedAt = DateTime.UtcNow,
                SaleOrderLineItem = new HashSet<SaleOrderLineItem>(productOrders.Select(x => new SaleOrderLineItem(x.NumProducts, x.ChosenProduct, lineNum++)))
            };

            if (!SaleOrder.SaleOrderLineItem.Any())
            {
                status.AddError("No items in your basket.");
            }

            status.Result = SaleOrder;
            return status;
        }



        public IStatusGeneric ChangeDeliveryDate(int businessAccountId, DateTime newDeliveryDate)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (BusinessAccountId != businessAccountId)
            {
                status.AddError("I'm sorry, but that order does not belong to you");
                //Log a security issue
                return status;
            }

            //if (HasBeenDelivered)
            //{
            //    status.AddError("I'm sorry, but that order has been delivered.");
            //    return status;
            //}

            if (newDeliveryDate < DateTime.Today.AddDays(1))
            {
                status.AddError("I'm sorry, we cannot get the order to you that quickly. Please choose a new date.", "NewDeliveryDate");
                return status;
            }

            if (newDeliveryDate.DayOfWeek == DayOfWeek.Sunday)
            {
                status.AddError("I'm sorry, we don't deliver on Sunday. Please choose a new date.", "NewDeliveryDate");
                return status;
            }

            //All Ok
            StockDue = newDeliveryDate;
            return status;
        }
    }
}
