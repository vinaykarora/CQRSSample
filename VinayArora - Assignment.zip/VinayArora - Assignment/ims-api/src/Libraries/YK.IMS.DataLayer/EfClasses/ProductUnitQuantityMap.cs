﻿
using System;
using System.ComponentModel.DataAnnotations;
using YK.IMS.Core.Status;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class ProductUnitQuantityMap
    {
        private ProductUnitQuantityMap()
        {

        }
        public ProductUnitQuantityMap(int companyId, string name, string description, int productId, int unitId, decimal minUnitQuantity, decimal maxUnitQuantity, decimal defaultUnitPrice, decimal defaultDiscountPercentage, decimal defaultDiscountPrice, bool isActive, bool isDelete, string createdBy) : this()
        {
            CompanyId = companyId;
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Description = description ?? throw new ArgumentNullException(nameof(description));
            ProductId = productId;
            UnitId = unitId;
            MinUnitQuantity = minUnitQuantity;
            MaxUnitQuantity = maxUnitQuantity;
            DefaultUnitPrice = defaultUnitPrice;
            DefaultDiscountPercentage = defaultDiscountPercentage;
            DefaultDiscountPrice = defaultDiscountPrice;
            IsActive = isActive;
            IsDelete = isDelete;
            CreatedBy = createdBy;
            CreatedAt = DateTime.UtcNow;
        }

        public int Id { get; private set; }
        public int CompanyId { get; private set; }
        public string Name { get; private set; }
        public string Description { get; private set; }
        public int ProductId { get; private set; }
        public int UnitId { get; private set; }
        public decimal MinUnitQuantity { get; private set; }
        public decimal MaxUnitQuantity { get; private set; }
        public decimal DefaultUnitPrice { get; private set; }
        public decimal DefaultDiscountPercentage { get; private set; }
        public decimal DefaultDiscountPrice { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual Company Company { get; private set; }


        public virtual Product Product { get; private set; }
        public virtual Unit Unit { get; private set; }
        public IStatusGeneric ChangeName(string name)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(Name))
            {
                status.AddError("Name Is Required", nameof(Name));
            }
            Name = name.Trim();
            return status;
        }

        public IStatusGeneric ChangeDescription(string description)
        {
            StatusGenericHandler status = new StatusGenericHandler();
            if (string.IsNullOrEmpty(description))
            {
                //status.AddError("Description Is Required", nameof(description));
            }
            Description = description.Trim();
            return status;
        }
    }
}
