﻿using System;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class GeneralLedger
    {
        private GeneralLedger()
        {

        }

        public GeneralLedger(int companyId, int businessAccountId, int transactionType, string referenceNo, string narration, decimal creditAmount, decimal debitAmount, decimal balanceAmount, bool isActive, bool isDelete, string createdBy) : this()
        {
            CompanyId = companyId;
            BusinessAccountId = businessAccountId;
            TransactionType = transactionType;
            ReferenceNo = referenceNo ?? throw new ArgumentNullException(nameof(referenceNo));
            Narration = narration ?? throw new ArgumentNullException(nameof(narration));
            CreditAmount = creditAmount;
            DebitAmount = debitAmount;
            BalanceAmount = balanceAmount;
            IsActive = isActive;
            IsDelete = isDelete;
            CreatedBy = createdBy;
            CreatedAt = DateTime.UtcNow;
        }

        public int Id { get; private set; }
        public int CompanyId { get; private set; }
        public int BusinessAccountId { get; private set; }
        public int TransactionType { get; private set; }
        public string ReferenceNo { get; private set; }
        public string Narration { get; private set; }
        public decimal CreditAmount { get; private set; }
        public decimal DebitAmount { get; private set; }
        public decimal BalanceAmount { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual BusinessAccount BusinessAccount { get; private set; }
        public virtual Company Company { get; private set; }


        public virtual TransactionType TransactionTypeNavigation { get; private set; }
    }
}
