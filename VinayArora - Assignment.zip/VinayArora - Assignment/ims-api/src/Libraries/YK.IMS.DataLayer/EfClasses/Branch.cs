﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class Branch
    {
        public Branch(string name, string description, int companyId, int countryId, int stateId, int cityId, string address1, string address2,
            string address3, string pincode, string phone, string mobile, string fax, string email, bool isDefaultBranch, string createdBy) : this()
        {
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Description = description ?? throw new ArgumentNullException(nameof(description));
            CompanyId = companyId;
            CountryId = countryId;
            StateId = stateId;
            CityId = cityId;
            Address1 = address1 ?? throw new ArgumentNullException(nameof(address1));
            Address2 = address2 ?? throw new ArgumentNullException(nameof(address2));
            Address3 = address3 ?? throw new ArgumentNullException(nameof(address3));
            Pincode = pincode ?? throw new ArgumentNullException(nameof(pincode));
            Phone = phone ?? throw new ArgumentNullException(nameof(phone));
            Mobile = mobile ?? throw new ArgumentNullException(nameof(mobile));
            Fax = fax ?? throw new ArgumentNullException(nameof(fax));
            Email = email ?? throw new ArgumentNullException(nameof(email));
            IsDefaultBranch = isDefaultBranch;
            IsActive = true;
            IsDelete = false;
            CreatedAt = DateTime.UtcNow;
            CreatedBy = createdBy;
        }

        private Branch()
        {
            CreditNote = new HashSet<CreditNote>();
            CreditNoteLineItem = new HashSet<CreditNoteLineItem>();
            DebitNote = new HashSet<DebitNote>();
            DebitNoteLineItem = new HashSet<DebitNoteLineItem>();
            DeliveryNote = new HashSet<DeliveryNote>();
            DeliveryNoteLineItem = new HashSet<DeliveryNoteLineItem>();
            Purchase = new HashSet<Purchase>();
            PurchaseLineItem = new HashSet<PurchaseLineItem>();
            PurchaseOrder = new HashSet<PurchaseOrder>();
            PurchaseOrderLineItem = new HashSet<PurchaseOrderLineItem>();
            Sale = new HashSet<Sale>();
            SaleLineItem = new HashSet<SaleLineItem>();
            SaleOrder = new HashSet<SaleOrder>();
            SaleOrderLineItem = new HashSet<SaleOrderLineItem>();
            Warehouse = new HashSet<Warehouse>();
        }

        public int Id { get; private set; }
        public string Name { get; private set; }
        public string Description { get; private set; }
        public int CompanyId { get; private set; }
        public int CountryId { get; private set; }
        public int StateId { get; private set; }
        public int CityId { get; private set; }
        public string Address1 { get; private set; }
        public string Address2 { get; private set; }
        public string Address3 { get; private set; }
        public string Pincode { get; private set; }
        public string Phone { get; private set; }
        public string Mobile { get; private set; }
        public string Fax { get; private set; }
        public string Email { get; private set; }
        public bool IsDefaultBranch { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }

        public virtual City City { get; private set; }
        public virtual Company Company { get; private set; }
        public virtual Country Country { get; private set; }


        public virtual State State { get; private set; }
        public virtual ICollection<CreditNote> CreditNote { get; private set; }
        public virtual ICollection<CreditNoteLineItem> CreditNoteLineItem { get; private set; }
        public virtual ICollection<DebitNote> DebitNote { get; private set; }
        public virtual ICollection<DebitNoteLineItem> DebitNoteLineItem { get; private set; }
        public virtual ICollection<DeliveryNote> DeliveryNote { get; private set; }
        public virtual ICollection<DeliveryNoteLineItem> DeliveryNoteLineItem { get; private set; }
        public virtual ICollection<Purchase> Purchase { get; private set; }
        public virtual ICollection<PurchaseLineItem> PurchaseLineItem { get; private set; }
        public virtual ICollection<PurchaseOrder> PurchaseOrder { get; private set; }
        public virtual ICollection<PurchaseOrderLineItem> PurchaseOrderLineItem { get; private set; }
        public virtual ICollection<Sale> Sale { get; private set; }
        public virtual ICollection<SaleLineItem> SaleLineItem { get; private set; }
        public virtual ICollection<SaleOrder> SaleOrder { get; private set; }
        public virtual ICollection<SaleOrderLineItem> SaleOrderLineItem { get; private set; }
        public virtual ICollection<Warehouse> Warehouse { get; private set; }
    }
}
