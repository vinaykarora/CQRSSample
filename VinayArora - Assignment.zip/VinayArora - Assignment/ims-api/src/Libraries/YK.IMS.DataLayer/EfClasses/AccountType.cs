﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace YK.IMS.DataLayer.EfClasses
{
    public partial class AccountType
    {
        private AccountType()
        {
            Accounts = new HashSet<Accounts>();
        }

        public AccountType(int id, string code, byte[] name, string description, bool isActive, bool isDelete, string createdBy) : this()
        {
            Id = id;
            Code = code ?? throw new ArgumentNullException(nameof(code));
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Description = description ?? throw new ArgumentNullException(nameof(description));
            IsActive = isActive;
            IsDelete = isDelete;
            CreatedAt = DateTime.UtcNow;
            CreatedBy = createdBy;
        }

        public int Id { get; private set; }
        public string Code { get; private set; }
        public byte[] Name { get; private set; }
        public string Description { get; private set; }
        public bool IsActive { get; private set; }
        public bool IsDelete { get; private set; }
        public DateTime CreatedAt { get; private set; }
        [Required]
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }



        public virtual ICollection<Accounts> Accounts { get; private set; }
    }
}
