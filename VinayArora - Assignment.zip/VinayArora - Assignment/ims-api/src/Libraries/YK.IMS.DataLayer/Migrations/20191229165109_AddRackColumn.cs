﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace YK.IMS.DataLayer.Migrations
{
    public partial class AddRackColumn : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "RackNumber",
                table: "Product",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RackNumber",
                table: "Product");
        }
    }
}
