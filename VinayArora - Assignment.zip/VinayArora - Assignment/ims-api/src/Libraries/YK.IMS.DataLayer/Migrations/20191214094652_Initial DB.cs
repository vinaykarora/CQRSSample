﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace YK.IMS.DataLayer.Migrations
{
    public partial class InitialDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AccountType",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Name = table.Column<byte[]>(maxLength: 50, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AccountType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CompanyType",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CompanyType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Country",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Country", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "InvoiceStatusType",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InvoiceStatusType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TransactionType",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TransactionType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Company",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    ParentCompanyId = table.Column<int>(nullable: true),
                    CompanyTypeId = table.Column<int>(nullable: false),
                    StartingDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    EndingDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    TaxNumber = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Company", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Company_CompanyTypeId_PK_CompanyType",
                        column: x => x.CompanyTypeId,
                        principalTable: "CompanyType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Company_ParentCompanyId_PK_Company",
                        column: x => x.ParentCompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "State",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    CountryId = table.Column<int>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true),
                    CreatedBy = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_State", x => x.Id);
                    table.ForeignKey(
                        name: "FK_State_CountryId_PK_Country",
                        column: x => x.CountryId,
                        principalTable: "Country",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Accounts",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    AccountType = table.Column<int>(nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Accounts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Accounts_AccountType_PK_AccountType",
                        column: x => x.AccountType,
                        principalTable: "AccountType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Accounts_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BusinessType",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false),
                    CompanyId = table.Column<int>(nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Name = table.Column<string>(maxLength: 50, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BusinessType", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BusinessType_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ChapterHeading",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ChapterHeading", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ChapterHeading_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Color",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Color", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Color_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Make",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Make", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Make_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MaterialType",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MaterialType", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MaterialType_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Model",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Model", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Model_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PackSize",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PackSize", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PackSize_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PaymentMethod",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PaymentMethod", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PaymentMethod_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PaymentTerm",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PaymentTerm", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PaymentTerm_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProductGroup",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductGroup", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProductGroup_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Size",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Size", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Size_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Style",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Style", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Style_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Unit",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Unit", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Unit_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "City",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    StateId = table.Column<int>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_City", x => x.Id);
                    table.ForeignKey(
                        name: "FK_City_StateId_PK_State",
                        column: x => x.StateId,
                        principalTable: "State",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BusinessAccount",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    BusinessType = table.Column<int>(nullable: false),
                    TaxNumber = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    AssignedTo = table.Column<int>(nullable: true),
                    DefaultStockLocation = table.Column<int>(nullable: true),
                    DefaultDiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DefaultPaymentTerm = table.Column<int>(nullable: true),
                    DefaultPaymentMethod = table.Column<int>(nullable: true),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BusinessAccount", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BusinessAccount_BusinessType_PK_BusinessType",
                        column: x => x.BusinessType,
                        principalTable: "BusinessType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BusinessAccount_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Product",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Code = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    Barcode = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    MaterialTypeId = table.Column<int>(nullable: false),
                    ProductGroupId = table.Column<int>(nullable: false),
                    UnitId = table.Column<int>(nullable: false),
                    RetailUnitId = table.Column<int>(nullable: false),
                    SizeId = table.Column<int>(nullable: false),
                    MakeId = table.Column<int>(nullable: false),
                    ColorId = table.Column<int>(nullable: false),
                    StyleId = table.Column<int>(nullable: false),
                    ChapterHeadingId = table.Column<int>(nullable: false),
                    PackSizeId = table.Column<int>(nullable: false),
                    ModelId = table.Column<int>(nullable: false),
                    DefaultSalePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    RetailSalePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DefaultPurchasePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DefaultDiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DefaultDiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Product", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Product_ChapterHeadingId_PK_ChapterHeading",
                        column: x => x.ChapterHeadingId,
                        principalTable: "ChapterHeading",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_ColorId_PK_Color",
                        column: x => x.ColorId,
                        principalTable: "Color",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_MakeId_PK_Make",
                        column: x => x.MakeId,
                        principalTable: "Make",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_MaterialTypeId_PK_MaterialType",
                        column: x => x.MaterialTypeId,
                        principalTable: "MaterialType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_ModelId_PK_Model",
                        column: x => x.ModelId,
                        principalTable: "Model",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_PackSizeId_PK_PackSize",
                        column: x => x.PackSizeId,
                        principalTable: "PackSize",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_ProductGroupId_PK_ProductGroup",
                        column: x => x.ProductGroupId,
                        principalTable: "ProductGroup",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_RetailUnitId_PK_Unit",
                        column: x => x.RetailUnitId,
                        principalTable: "Unit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_SizeId_PK_Size",
                        column: x => x.SizeId,
                        principalTable: "Size",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_StyleId_PK_Style",
                        column: x => x.StyleId,
                        principalTable: "Style",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Product_UnitId_PK_Unit",
                        column: x => x.UnitId,
                        principalTable: "Unit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Branch",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    CompanyId = table.Column<int>(nullable: false),
                    CountryId = table.Column<int>(nullable: false),
                    StateId = table.Column<int>(nullable: false),
                    CityId = table.Column<int>(nullable: false),
                    Address1 = table.Column<string>(unicode: false, maxLength: 100, nullable: false),
                    Address2 = table.Column<string>(unicode: false, maxLength: 100, nullable: false),
                    Address3 = table.Column<string>(unicode: false, maxLength: 100, nullable: false),
                    Pincode = table.Column<string>(unicode: false, maxLength: 10, nullable: false),
                    Phone = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Mobile = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Fax = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    Email = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    IsDefaultBranch = table.Column<bool>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Branch", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Branch_CityId_PK_City",
                        column: x => x.CityId,
                        principalTable: "City",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Branch_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Branch_CountryId_PK_Country",
                        column: x => x.CountryId,
                        principalTable: "Country",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Branch_StateId_PK_State",
                        column: x => x.StateId,
                        principalTable: "State",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BusinessAccountAddress",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    AddressType = table.Column<int>(nullable: false),
                    BusinessAccountId = table.Column<int>(nullable: false),
                    CountryId = table.Column<int>(nullable: false),
                    StateId = table.Column<int>(nullable: false),
                    CityId = table.Column<int>(nullable: false),
                    Address1 = table.Column<string>(unicode: false, maxLength: 100, nullable: false),
                    Address2 = table.Column<string>(unicode: false, maxLength: 100, nullable: false),
                    Address3 = table.Column<string>(unicode: false, maxLength: 100, nullable: false),
                    Pincode = table.Column<string>(unicode: false, maxLength: 10, nullable: false),
                    Phone = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Mobile = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Email = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BusinessAccountAddress", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BusinessAccountAddress_BusinessAccountId_PK_BusinessAccount",
                        column: x => x.BusinessAccountId,
                        principalTable: "BusinessAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BusinessAccountAddress_CityId_PK_City",
                        column: x => x.CityId,
                        principalTable: "City",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BusinessAccountAddress_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BusinessAccountAddress_CountryId_PK_Country",
                        column: x => x.CountryId,
                        principalTable: "Country",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BusinessAccountAddress_StateId_PK_State",
                        column: x => x.StateId,
                        principalTable: "State",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "GeneralLedger",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    BusinessAccountId = table.Column<int>(nullable: false),
                    TransactionType = table.Column<int>(nullable: false),
                    ReferenceNo = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Narration = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    CreditAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DebitAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    BalanceAmount = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GeneralLedger", x => x.Id);
                    table.ForeignKey(
                        name: "FK_GeneralLedger_BusinessAccountId_PK_BusinessAccount",
                        column: x => x.BusinessAccountId,
                        principalTable: "BusinessAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_GeneralLedger_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_GeneralLedger_TransactionTypeId_PK_TransactionType",
                        column: x => x.TransactionType,
                        principalTable: "TransactionType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProductBusinessAccountMap",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    BusinessAccountId = table.Column<int>(nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    DefaultSalePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DefaultDiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DefaultDiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductBusinessAccountMap", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProductBusinessAccountMap_BusinessAccountId_PK_BusinessAccount",
                        column: x => x.BusinessAccountId,
                        principalTable: "BusinessAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductBusinessAccountMap_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductBusinessAccountMap_ProductId_PK_Product",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProductUnitQuantityMap",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CompanyId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    UnitId = table.Column<int>(nullable: false),
                    MinUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    MaxUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DefaultUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DefaultDiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DefaultDiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductUnitQuantityMap", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProductUnitQuantityMap_CompanyId_PK_Company",
                        column: x => x.CompanyId,
                        principalTable: "Company",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductUnitQuantityMap_ProductId_PK_Product",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductUnitQuantityMap_UnitId_PK_Unit",
                        column: x => x.UnitId,
                        principalTable: "Unit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PurchaseOrder",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    PurchaseOrderNumber = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    IssueDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    StockDue = table.Column<DateTime>(type: "datetime", nullable: false),
                    PaymentDue = table.Column<DateTime>(type: "datetime", nullable: false),
                    BusinessAccountId = table.Column<int>(nullable: false),
                    Status = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    DeliveryAddress = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    TotalUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalReceivedUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalDiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalsAre = table.Column<int>(nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PurchaseOrder", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PurchaseOrder_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrder_BusinessAccountId_PK_BusinessAccount",
                        column: x => x.BusinessAccountId,
                        principalTable: "BusinessAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SaleOrder",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    SaleOrderNumber = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    IssueDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    StockDue = table.Column<DateTime>(type: "datetime", nullable: false),
                    PaymentDue = table.Column<DateTime>(type: "datetime", nullable: false),
                    BusinessAccountId = table.Column<int>(nullable: false),
                    Status = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    DeliveryAddress = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    TotalUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalDeliveredUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalDiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalsAre = table.Column<int>(nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SaleOrder", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SaleOrder_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleOrder_BusinessAccountId_PK_BusinessAccount",
                        column: x => x.BusinessAccountId,
                        principalTable: "BusinessAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Warehouse",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    BranchId = table.Column<int>(nullable: false),
                    CountryId = table.Column<int>(nullable: false),
                    StateId = table.Column<int>(nullable: false),
                    CityId = table.Column<int>(nullable: false),
                    Address1 = table.Column<string>(unicode: false, maxLength: 100, nullable: false),
                    Address2 = table.Column<string>(unicode: false, maxLength: 100, nullable: false),
                    Address3 = table.Column<string>(unicode: false, maxLength: 100, nullable: false),
                    Pincode = table.Column<string>(unicode: false, maxLength: 10, nullable: false),
                    Phone = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Mobile = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    Fax = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    Email = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Warehouse", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Warehouse_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Warehouse_CityId_PK_City",
                        column: x => x.CityId,
                        principalTable: "City",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Warehouse_CountryId_PK_Country",
                        column: x => x.CountryId,
                        principalTable: "Country",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Warehouse_StateId_PK_State",
                        column: x => x.StateId,
                        principalTable: "State",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DeliveryNote",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    DeliveryNoteNumber = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    PurchaseOrderId = table.Column<int>(nullable: false),
                    DeliveryDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    BusinessAccountId = table.Column<int>(nullable: false),
                    Status = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    TotalUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalDiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalsAre = table.Column<int>(nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeliveryNote", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DeliveryNote_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryNote_BusinessAccountId_PK_BusinessAccount",
                        column: x => x.BusinessAccountId,
                        principalTable: "BusinessAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryNote_PurchaseOrderId_PK_PurchaseOrder",
                        column: x => x.PurchaseOrderId,
                        principalTable: "PurchaseOrder",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PurchaseOrderLineItem",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    PurchaseOrderId = table.Column<int>(nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    UnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    ReceivedUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitId = table.Column<int>(nullable: false),
                    SizeId = table.Column<int>(nullable: false),
                    MakeId = table.Column<int>(nullable: false),
                    ColorId = table.Column<int>(nullable: false),
                    StyleId = table.Column<int>(nullable: false),
                    ModelId = table.Column<int>(nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PurchaseOrderLineItem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PurchaseOrderLineItem_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrderLineItem_ColorId_PK_Color",
                        column: x => x.ColorId,
                        principalTable: "Color",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrderLineItem_MakeId_PK_Make",
                        column: x => x.MakeId,
                        principalTable: "Make",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrderLineItem_ModelId_PK_Model",
                        column: x => x.ModelId,
                        principalTable: "Model",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrderLineItem_ProductId_PK_Product",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrderLineItem_PurchaseOrderId_PK_PurchaseOrder",
                        column: x => x.PurchaseOrderId,
                        principalTable: "PurchaseOrder",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrderLineItem_SizeId_PK_Size",
                        column: x => x.SizeId,
                        principalTable: "Size",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrderLineItem_StyleId_PK_Style",
                        column: x => x.StyleId,
                        principalTable: "Style",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseOrderLineItem_UnitId_PK_Unit",
                        column: x => x.UnitId,
                        principalTable: "Unit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Sale",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    InvoiceNumber = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    IssueDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    DeliveryDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    BusinessAccountId = table.Column<int>(nullable: false),
                    SaleOrderId = table.Column<int>(nullable: true),
                    Status = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    DeliveryAddress = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    TotalUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalDiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalsAre = table.Column<int>(nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sale", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Sale_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Sale_BusinessAccountId_PK_BusinessAccount",
                        column: x => x.BusinessAccountId,
                        principalTable: "BusinessAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Sale_SaleOrderId_PK_SaleOrder",
                        column: x => x.SaleOrderId,
                        principalTable: "SaleOrder",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SaleOrderLineItem",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    SaleOrderId = table.Column<int>(nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    UnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DeliveredUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitId = table.Column<int>(nullable: false),
                    SizeId = table.Column<int>(nullable: false),
                    MakeId = table.Column<int>(nullable: false),
                    ColorId = table.Column<int>(nullable: false),
                    StyleId = table.Column<int>(nullable: false),
                    ModelId = table.Column<int>(nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SaleOrderLineItem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SaleOrderLineItem_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleOrderLineItem_ColorId_PK_Color",
                        column: x => x.ColorId,
                        principalTable: "Color",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleOrderLineItem_MakeId_PK_Make",
                        column: x => x.MakeId,
                        principalTable: "Make",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleOrderLineItem_ModelId_PK_Model",
                        column: x => x.ModelId,
                        principalTable: "Model",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleOrderLineItem_ProductId_PK_Product",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleOrderLineItem_SaleOrderId_PK_Sale",
                        column: x => x.SaleOrderId,
                        principalTable: "SaleOrder",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleOrderLineItem_SizeId_PK_Size",
                        column: x => x.SizeId,
                        principalTable: "Size",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleOrderLineItem_StyleId_PK_Style",
                        column: x => x.StyleId,
                        principalTable: "Style",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleOrderLineItem_UnitId_PK_Unit",
                        column: x => x.UnitId,
                        principalTable: "Unit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProductStock",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    WarehouseId = table.Column<int>(nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    OpeningQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    ReceivingQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    ShipmentQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    RejectedQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TransferInQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TransferOutQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    BalanceQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductStock", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProductStock_ProductId_PK_Product",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ProductStock_WarehouseId_PK_Warehouse",
                        column: x => x.WarehouseId,
                        principalTable: "Warehouse",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DeliveryNoteLineItem",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    DeliveryNoteId = table.Column<int>(nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    UnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitId = table.Column<int>(nullable: false),
                    SizeId = table.Column<int>(nullable: false),
                    MakeId = table.Column<int>(nullable: false),
                    ColorId = table.Column<int>(nullable: false),
                    StyleId = table.Column<int>(nullable: false),
                    ModelId = table.Column<int>(nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeliveryNoteLineItem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DeliveryNoteLineItem_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryNoteLineItem_ColorId_PK_Color",
                        column: x => x.ColorId,
                        principalTable: "Color",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryNoteLineItem_DeliveryNoteId_PK_DeliveryNote",
                        column: x => x.DeliveryNoteId,
                        principalTable: "DeliveryNote",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryNoteLineItem_MakeId_PK_Make",
                        column: x => x.MakeId,
                        principalTable: "Make",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryNoteLineItem_ModelId_PK_Model",
                        column: x => x.ModelId,
                        principalTable: "Model",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryNoteLineItem_ProductId_PK_Product",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryNoteLineItem_SizeId_PK_Size",
                        column: x => x.SizeId,
                        principalTable: "Size",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryNoteLineItem_StyleId_PK_Style",
                        column: x => x.StyleId,
                        principalTable: "Style",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DeliveryNoteLineItem_UnitId_PK_Unit",
                        column: x => x.UnitId,
                        principalTable: "Unit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Purchase",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    BusinessAccountId = table.Column<int>(nullable: false),
                    DeliveryNoteId = table.Column<int>(nullable: true),
                    ReceiveDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    InvoiceNumber = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    TotalUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalDiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalsAre = table.Column<int>(nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Purchase", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Purchase_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Purchase_BusinessAccountId_PK_BusinessAccount",
                        column: x => x.BusinessAccountId,
                        principalTable: "BusinessAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Purchase_DeliveryNoteId_PK_DeliveryNote",
                        column: x => x.DeliveryNoteId,
                        principalTable: "DeliveryNote",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CreditNote",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    InvoiceNumber = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    IssueDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SaleId = table.Column<int>(nullable: false),
                    Status = table.Column<int>(nullable: false),
                    BusinessAccountId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    TotalUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalDiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalsAre = table.Column<int>(nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CreditNote", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CreditNote_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CreditNote_BusinessAccountId_PK_BusinessAccount",
                        column: x => x.BusinessAccountId,
                        principalTable: "BusinessAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CreditNote_SaleId_PK_Sale",
                        column: x => x.SaleId,
                        principalTable: "Sale",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SaleLineItem",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    SaleId = table.Column<int>(nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    UnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitId = table.Column<int>(nullable: false),
                    SizeId = table.Column<int>(nullable: false),
                    MakeId = table.Column<int>(nullable: false),
                    ColorId = table.Column<int>(nullable: false),
                    StyleId = table.Column<int>(nullable: false),
                    ModelId = table.Column<int>(nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SaleLineItem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SaleLineItem_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleLineItem_ColorId_PK_Color",
                        column: x => x.ColorId,
                        principalTable: "Color",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleLineItem_MakeId_PK_Make",
                        column: x => x.MakeId,
                        principalTable: "Make",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleLineItem_ModelId_PK_Model",
                        column: x => x.ModelId,
                        principalTable: "Model",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleLineItem_ProductId_PK_Product",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleLineItem_SaleId_PK_Sale",
                        column: x => x.SaleId,
                        principalTable: "Sale",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleLineItem_SizeId_PK_Size",
                        column: x => x.SizeId,
                        principalTable: "Size",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleLineItem_StyleId_PK_Style",
                        column: x => x.StyleId,
                        principalTable: "Style",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SaleLineItem_UnitId_PK_Unit",
                        column: x => x.UnitId,
                        principalTable: "Unit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DebitNote",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    InvoiceNumber = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    IssueDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    PurchaseId = table.Column<int>(nullable: false),
                    Status = table.Column<int>(nullable: false),
                    BusinessAccountId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    TotalUnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalDiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalsAre = table.Column<int>(nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DebitNote", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DebitNote_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DebitNote_BusinessAccountId_PK_BusinessAccount",
                        column: x => x.BusinessAccountId,
                        principalTable: "BusinessAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DebitNote_PurchaseId_PK_Purchase",
                        column: x => x.PurchaseId,
                        principalTable: "Purchase",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PurchaseLineItem",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: true),
                    PurchaseId = table.Column<int>(nullable: false),
                    DeliveryNoteLineItemId = table.Column<int>(nullable: true),
                    ProductId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    UnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitId = table.Column<int>(nullable: false),
                    SizeId = table.Column<int>(nullable: false),
                    MakeId = table.Column<int>(nullable: false),
                    ColorId = table.Column<int>(nullable: false),
                    StyleId = table.Column<int>(nullable: false),
                    ModelId = table.Column<int>(nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PurchaseLineItem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PurchaseLineItem_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseLineItem_ColorId_PK_Color",
                        column: x => x.ColorId,
                        principalTable: "Color",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseLineItem_DeliveryNoteLineItemId_PK_DeliveryNoteLineItem",
                        column: x => x.DeliveryNoteLineItemId,
                        principalTable: "DeliveryNoteLineItem",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseLineItem_MakeId_PK_Make",
                        column: x => x.MakeId,
                        principalTable: "Make",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseLineItem_ModelId_PK_Model",
                        column: x => x.ModelId,
                        principalTable: "Model",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseLineItem_ProductId_PK_Product",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseLineItem_PurchaseId_PK_Purchase",
                        column: x => x.PurchaseId,
                        principalTable: "Purchase",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseLineItem_SizeId_PK_Size",
                        column: x => x.SizeId,
                        principalTable: "Size",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseLineItem_StyleId_PK_Style",
                        column: x => x.StyleId,
                        principalTable: "Style",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PurchaseLineItem_UnitId_PK_Unit",
                        column: x => x.UnitId,
                        principalTable: "Unit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CreditNoteLineItem",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    CreditNoteId = table.Column<int>(nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    UnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitId = table.Column<int>(nullable: false),
                    SizeId = table.Column<int>(nullable: false),
                    MakeId = table.Column<int>(nullable: false),
                    ColorId = table.Column<int>(nullable: false),
                    StyleId = table.Column<int>(nullable: false),
                    ModelId = table.Column<int>(nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CreditNoteLineItem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CreditNoteLineItem_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CreditNoteLineItem_ColorId_PK_Color",
                        column: x => x.ColorId,
                        principalTable: "Color",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CreditNoteLineItem_CreditNoteId_PK_CreditNote",
                        column: x => x.CreditNoteId,
                        principalTable: "CreditNote",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CreditNoteLineItem_MakeId_PK_Make",
                        column: x => x.MakeId,
                        principalTable: "Make",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CreditNoteLineItem_ModelId_PK_Model",
                        column: x => x.ModelId,
                        principalTable: "Model",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CreditNoteLineItem_ProductId_PK_Product",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CreditNoteLineItem_SizeId_PK_Size",
                        column: x => x.SizeId,
                        principalTable: "Size",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CreditNoteLineItem_StyleId_PK_Style",
                        column: x => x.StyleId,
                        principalTable: "Style",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_CreditNoteLineItem_UnitId_PK_Unit",
                        column: x => x.UnitId,
                        principalTable: "Unit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DebitNoteLineItem",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BranchId = table.Column<int>(nullable: false),
                    DebitNoteId = table.Column<int>(nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 500, nullable: false),
                    UnitQuantity = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    UnitId = table.Column<int>(nullable: false),
                    SizeId = table.Column<int>(nullable: false),
                    MakeId = table.Column<int>(nullable: false),
                    ColorId = table.Column<int>(nullable: false),
                    StyleId = table.Column<int>(nullable: false),
                    ModelId = table.Column<int>(nullable: false),
                    TotalUnitPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    DiscountPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalTaxablePrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TaxPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    CGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalCGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    SGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalSGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IGSTPercentage = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalIGSTPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    TotalPrice = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDelete = table.Column<bool>(nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatedBy = table.Column<string>(nullable: false),
                    LastUpdatedAt = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastUpdatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DebitNoteLineItem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DebitNoteLineItem_BranchId_PK_Branch",
                        column: x => x.BranchId,
                        principalTable: "Branch",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DebitNoteLineItem_ColorId_PK_Color",
                        column: x => x.ColorId,
                        principalTable: "Color",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DebitNoteLineItem_DebitNoteId_PK_DebitNote",
                        column: x => x.DebitNoteId,
                        principalTable: "DebitNote",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DebitNoteLineItem_MakeId_PK_Make",
                        column: x => x.MakeId,
                        principalTable: "Make",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DebitNoteLineItem_ModelId_PK_Model",
                        column: x => x.ModelId,
                        principalTable: "Model",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DebitNoteLineItem_ProductId_PK_Product",
                        column: x => x.ProductId,
                        principalTable: "Product",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DebitNoteLineItem_SizeId_PK_Size",
                        column: x => x.SizeId,
                        principalTable: "Size",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DebitNoteLineItem_StyleId_PK_Style",
                        column: x => x.StyleId,
                        principalTable: "Style",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DebitNoteLineItem_UnitId_PK_Unit",
                        column: x => x.UnitId,
                        principalTable: "Unit",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Accounts_AccountType",
                table: "Accounts",
                column: "AccountType");

            migrationBuilder.CreateIndex(
                name: "IX_Accounts_CompanyId",
                table: "Accounts",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Branch_CityId",
                table: "Branch",
                column: "CityId");

            migrationBuilder.CreateIndex(
                name: "IX_Branch_CompanyId",
                table: "Branch",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Branch_CountryId",
                table: "Branch",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_Branch_StateId",
                table: "Branch",
                column: "StateId");

            migrationBuilder.CreateIndex(
                name: "IX_BusinessAccount_BusinessType",
                table: "BusinessAccount",
                column: "BusinessType");

            migrationBuilder.CreateIndex(
                name: "IX_BusinessAccount_CompanyId",
                table: "BusinessAccount",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_BusinessAccountAddress_BusinessAccountId",
                table: "BusinessAccountAddress",
                column: "BusinessAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_BusinessAccountAddress_CityId",
                table: "BusinessAccountAddress",
                column: "CityId");

            migrationBuilder.CreateIndex(
                name: "IX_BusinessAccountAddress_CompanyId",
                table: "BusinessAccountAddress",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_BusinessAccountAddress_CountryId",
                table: "BusinessAccountAddress",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_BusinessAccountAddress_StateId",
                table: "BusinessAccountAddress",
                column: "StateId");

            migrationBuilder.CreateIndex(
                name: "IX_BusinessType_CompanyId",
                table: "BusinessType",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_ChapterHeading_CompanyId",
                table: "ChapterHeading",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_City_StateId",
                table: "City",
                column: "StateId");

            migrationBuilder.CreateIndex(
                name: "IX_Color_CompanyId",
                table: "Color",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Company_CompanyTypeId",
                table: "Company",
                column: "CompanyTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Company_ParentCompanyId",
                table: "Company",
                column: "ParentCompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNote_BranchId",
                table: "CreditNote",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNote_BusinessAccountId",
                table: "CreditNote",
                column: "BusinessAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNote_SaleId",
                table: "CreditNote",
                column: "SaleId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNoteLineItem_BranchId",
                table: "CreditNoteLineItem",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNoteLineItem_ColorId",
                table: "CreditNoteLineItem",
                column: "ColorId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNoteLineItem_CreditNoteId",
                table: "CreditNoteLineItem",
                column: "CreditNoteId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNoteLineItem_MakeId",
                table: "CreditNoteLineItem",
                column: "MakeId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNoteLineItem_ModelId",
                table: "CreditNoteLineItem",
                column: "ModelId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNoteLineItem_ProductId",
                table: "CreditNoteLineItem",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNoteLineItem_SizeId",
                table: "CreditNoteLineItem",
                column: "SizeId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNoteLineItem_StyleId",
                table: "CreditNoteLineItem",
                column: "StyleId");

            migrationBuilder.CreateIndex(
                name: "IX_CreditNoteLineItem_UnitId",
                table: "CreditNoteLineItem",
                column: "UnitId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNote_BranchId",
                table: "DebitNote",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNote_BusinessAccountId",
                table: "DebitNote",
                column: "BusinessAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNote_PurchaseId",
                table: "DebitNote",
                column: "PurchaseId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNoteLineItem_BranchId",
                table: "DebitNoteLineItem",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNoteLineItem_ColorId",
                table: "DebitNoteLineItem",
                column: "ColorId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNoteLineItem_DebitNoteId",
                table: "DebitNoteLineItem",
                column: "DebitNoteId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNoteLineItem_MakeId",
                table: "DebitNoteLineItem",
                column: "MakeId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNoteLineItem_ModelId",
                table: "DebitNoteLineItem",
                column: "ModelId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNoteLineItem_ProductId",
                table: "DebitNoteLineItem",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNoteLineItem_SizeId",
                table: "DebitNoteLineItem",
                column: "SizeId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNoteLineItem_StyleId",
                table: "DebitNoteLineItem",
                column: "StyleId");

            migrationBuilder.CreateIndex(
                name: "IX_DebitNoteLineItem_UnitId",
                table: "DebitNoteLineItem",
                column: "UnitId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNote_BranchId",
                table: "DeliveryNote",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNote_BusinessAccountId",
                table: "DeliveryNote",
                column: "BusinessAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNote_PurchaseOrderId",
                table: "DeliveryNote",
                column: "PurchaseOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNoteLineItem_BranchId",
                table: "DeliveryNoteLineItem",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNoteLineItem_ColorId",
                table: "DeliveryNoteLineItem",
                column: "ColorId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNoteLineItem_DeliveryNoteId",
                table: "DeliveryNoteLineItem",
                column: "DeliveryNoteId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNoteLineItem_MakeId",
                table: "DeliveryNoteLineItem",
                column: "MakeId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNoteLineItem_ModelId",
                table: "DeliveryNoteLineItem",
                column: "ModelId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNoteLineItem_ProductId",
                table: "DeliveryNoteLineItem",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNoteLineItem_SizeId",
                table: "DeliveryNoteLineItem",
                column: "SizeId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNoteLineItem_StyleId",
                table: "DeliveryNoteLineItem",
                column: "StyleId");

            migrationBuilder.CreateIndex(
                name: "IX_DeliveryNoteLineItem_UnitId",
                table: "DeliveryNoteLineItem",
                column: "UnitId");

            migrationBuilder.CreateIndex(
                name: "IX_GeneralLedger_BusinessAccountId",
                table: "GeneralLedger",
                column: "BusinessAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_GeneralLedger_CompanyId",
                table: "GeneralLedger",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_GeneralLedger_TransactionType",
                table: "GeneralLedger",
                column: "TransactionType");

            migrationBuilder.CreateIndex(
                name: "IX_Make_CompanyId",
                table: "Make",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_MaterialType_CompanyId",
                table: "MaterialType",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Model_CompanyId",
                table: "Model",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_PackSize_CompanyId",
                table: "PackSize",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_PaymentMethod_CompanyId",
                table: "PaymentMethod",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_PaymentTerm_CompanyId",
                table: "PaymentTerm",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_ChapterHeadingId",
                table: "Product",
                column: "ChapterHeadingId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_ColorId",
                table: "Product",
                column: "ColorId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_CompanyId",
                table: "Product",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_MakeId",
                table: "Product",
                column: "MakeId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_MaterialTypeId",
                table: "Product",
                column: "MaterialTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_ModelId",
                table: "Product",
                column: "ModelId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_PackSizeId",
                table: "Product",
                column: "PackSizeId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_ProductGroupId",
                table: "Product",
                column: "ProductGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_RetailUnitId",
                table: "Product",
                column: "RetailUnitId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_SizeId",
                table: "Product",
                column: "SizeId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_StyleId",
                table: "Product",
                column: "StyleId");

            migrationBuilder.CreateIndex(
                name: "IX_Product_UnitId",
                table: "Product",
                column: "UnitId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductBusinessAccountMap_BusinessAccountId",
                table: "ProductBusinessAccountMap",
                column: "BusinessAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductBusinessAccountMap_CompanyId",
                table: "ProductBusinessAccountMap",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductBusinessAccountMap_ProductId",
                table: "ProductBusinessAccountMap",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductGroup_CompanyId",
                table: "ProductGroup",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductStock_ProductId",
                table: "ProductStock",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductStock_WarehouseId",
                table: "ProductStock",
                column: "WarehouseId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductUnitQuantityMap_CompanyId",
                table: "ProductUnitQuantityMap",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductUnitQuantityMap_ProductId",
                table: "ProductUnitQuantityMap",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductUnitQuantityMap_UnitId",
                table: "ProductUnitQuantityMap",
                column: "UnitId");

            migrationBuilder.CreateIndex(
                name: "IX_Purchase_BranchId",
                table: "Purchase",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_Purchase_BusinessAccountId",
                table: "Purchase",
                column: "BusinessAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_Purchase_DeliveryNoteId",
                table: "Purchase",
                column: "DeliveryNoteId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseLineItem_BranchId",
                table: "PurchaseLineItem",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseLineItem_ColorId",
                table: "PurchaseLineItem",
                column: "ColorId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseLineItem_DeliveryNoteLineItemId",
                table: "PurchaseLineItem",
                column: "DeliveryNoteLineItemId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseLineItem_MakeId",
                table: "PurchaseLineItem",
                column: "MakeId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseLineItem_ModelId",
                table: "PurchaseLineItem",
                column: "ModelId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseLineItem_ProductId",
                table: "PurchaseLineItem",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseLineItem_PurchaseId",
                table: "PurchaseLineItem",
                column: "PurchaseId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseLineItem_SizeId",
                table: "PurchaseLineItem",
                column: "SizeId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseLineItem_StyleId",
                table: "PurchaseLineItem",
                column: "StyleId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseLineItem_UnitId",
                table: "PurchaseLineItem",
                column: "UnitId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrder_BranchId",
                table: "PurchaseOrder",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrder_BusinessAccountId",
                table: "PurchaseOrder",
                column: "BusinessAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrderLineItem_BranchId",
                table: "PurchaseOrderLineItem",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrderLineItem_ColorId",
                table: "PurchaseOrderLineItem",
                column: "ColorId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrderLineItem_MakeId",
                table: "PurchaseOrderLineItem",
                column: "MakeId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrderLineItem_ModelId",
                table: "PurchaseOrderLineItem",
                column: "ModelId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrderLineItem_ProductId",
                table: "PurchaseOrderLineItem",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrderLineItem_PurchaseOrderId",
                table: "PurchaseOrderLineItem",
                column: "PurchaseOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrderLineItem_SizeId",
                table: "PurchaseOrderLineItem",
                column: "SizeId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrderLineItem_StyleId",
                table: "PurchaseOrderLineItem",
                column: "StyleId");

            migrationBuilder.CreateIndex(
                name: "IX_PurchaseOrderLineItem_UnitId",
                table: "PurchaseOrderLineItem",
                column: "UnitId");

            migrationBuilder.CreateIndex(
                name: "IX_Sale_BranchId",
                table: "Sale",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_Sale_BusinessAccountId",
                table: "Sale",
                column: "BusinessAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_Sale_SaleOrderId",
                table: "Sale",
                column: "SaleOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleLineItem_BranchId",
                table: "SaleLineItem",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleLineItem_ColorId",
                table: "SaleLineItem",
                column: "ColorId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleLineItem_MakeId",
                table: "SaleLineItem",
                column: "MakeId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleLineItem_ModelId",
                table: "SaleLineItem",
                column: "ModelId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleLineItem_ProductId",
                table: "SaleLineItem",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleLineItem_SaleId",
                table: "SaleLineItem",
                column: "SaleId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleLineItem_SizeId",
                table: "SaleLineItem",
                column: "SizeId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleLineItem_StyleId",
                table: "SaleLineItem",
                column: "StyleId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleLineItem_UnitId",
                table: "SaleLineItem",
                column: "UnitId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrder_BranchId",
                table: "SaleOrder",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrder_BusinessAccountId",
                table: "SaleOrder",
                column: "BusinessAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrderLineItem_BranchId",
                table: "SaleOrderLineItem",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrderLineItem_ColorId",
                table: "SaleOrderLineItem",
                column: "ColorId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrderLineItem_MakeId",
                table: "SaleOrderLineItem",
                column: "MakeId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrderLineItem_ModelId",
                table: "SaleOrderLineItem",
                column: "ModelId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrderLineItem_ProductId",
                table: "SaleOrderLineItem",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrderLineItem_SaleOrderId",
                table: "SaleOrderLineItem",
                column: "SaleOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrderLineItem_SizeId",
                table: "SaleOrderLineItem",
                column: "SizeId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrderLineItem_StyleId",
                table: "SaleOrderLineItem",
                column: "StyleId");

            migrationBuilder.CreateIndex(
                name: "IX_SaleOrderLineItem_UnitId",
                table: "SaleOrderLineItem",
                column: "UnitId");

            migrationBuilder.CreateIndex(
                name: "IX_Size_CompanyId",
                table: "Size",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_State_CountryId",
                table: "State",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_Style_CompanyId",
                table: "Style",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Unit_CompanyId",
                table: "Unit",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Warehouse_BranchId",
                table: "Warehouse",
                column: "BranchId");

            migrationBuilder.CreateIndex(
                name: "IX_Warehouse_CityId",
                table: "Warehouse",
                column: "CityId");

            migrationBuilder.CreateIndex(
                name: "IX_Warehouse_CountryId",
                table: "Warehouse",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_Warehouse_StateId",
                table: "Warehouse",
                column: "StateId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Accounts");

            migrationBuilder.DropTable(
                name: "BusinessAccountAddress");

            migrationBuilder.DropTable(
                name: "CreditNoteLineItem");

            migrationBuilder.DropTable(
                name: "DebitNoteLineItem");

            migrationBuilder.DropTable(
                name: "GeneralLedger");

            migrationBuilder.DropTable(
                name: "InvoiceStatusType");

            migrationBuilder.DropTable(
                name: "PaymentMethod");

            migrationBuilder.DropTable(
                name: "PaymentTerm");

            migrationBuilder.DropTable(
                name: "ProductBusinessAccountMap");

            migrationBuilder.DropTable(
                name: "ProductStock");

            migrationBuilder.DropTable(
                name: "ProductUnitQuantityMap");

            migrationBuilder.DropTable(
                name: "PurchaseLineItem");

            migrationBuilder.DropTable(
                name: "PurchaseOrderLineItem");

            migrationBuilder.DropTable(
                name: "SaleLineItem");

            migrationBuilder.DropTable(
                name: "SaleOrderLineItem");

            migrationBuilder.DropTable(
                name: "AccountType");

            migrationBuilder.DropTable(
                name: "CreditNote");

            migrationBuilder.DropTable(
                name: "DebitNote");

            migrationBuilder.DropTable(
                name: "TransactionType");

            migrationBuilder.DropTable(
                name: "Warehouse");

            migrationBuilder.DropTable(
                name: "DeliveryNoteLineItem");

            migrationBuilder.DropTable(
                name: "Sale");

            migrationBuilder.DropTable(
                name: "Purchase");

            migrationBuilder.DropTable(
                name: "Product");

            migrationBuilder.DropTable(
                name: "SaleOrder");

            migrationBuilder.DropTable(
                name: "DeliveryNote");

            migrationBuilder.DropTable(
                name: "ChapterHeading");

            migrationBuilder.DropTable(
                name: "Color");

            migrationBuilder.DropTable(
                name: "Make");

            migrationBuilder.DropTable(
                name: "MaterialType");

            migrationBuilder.DropTable(
                name: "Model");

            migrationBuilder.DropTable(
                name: "PackSize");

            migrationBuilder.DropTable(
                name: "ProductGroup");

            migrationBuilder.DropTable(
                name: "Unit");

            migrationBuilder.DropTable(
                name: "Size");

            migrationBuilder.DropTable(
                name: "Style");

            migrationBuilder.DropTable(
                name: "PurchaseOrder");

            migrationBuilder.DropTable(
                name: "Branch");

            migrationBuilder.DropTable(
                name: "BusinessAccount");

            migrationBuilder.DropTable(
                name: "City");

            migrationBuilder.DropTable(
                name: "BusinessType");

            migrationBuilder.DropTable(
                name: "State");

            migrationBuilder.DropTable(
                name: "Company");

            migrationBuilder.DropTable(
                name: "Country");

            migrationBuilder.DropTable(
                name: "CompanyType");
        }
    }
}
