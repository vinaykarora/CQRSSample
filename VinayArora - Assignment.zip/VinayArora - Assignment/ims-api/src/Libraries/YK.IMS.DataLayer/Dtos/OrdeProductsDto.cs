﻿using System;
using System.Collections.Generic;
using System.Text;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DataLayer.Dtos
{
    public struct OrderProductsDto
    {
        public int ProductId { get; }
        public Product ChosenProduct { get; }
        public short NumProducts { get; }

        public OrderProductsDto(int productId, Product chosenProduct, short numProducts) : this()
        {
            ProductId = productId;
            ChosenProduct = chosenProduct ?? throw new ArgumentNullException(nameof(chosenProduct));
            NumProducts = numProducts;
        }
    }
}
