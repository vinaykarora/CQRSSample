﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DataLayer.EfCode.Configurations
{
    internal class RefreshTokenConfig : IEntityTypeConfiguration<RefreshToken>
    {
        public void Configure(EntityTypeBuilder<RefreshToken> entity)
        {
            entity.HasKey(p => p.Id);

            entity.Property(e => e.Token)
                .IsRequired()
                .HasMaxLength(250);

            entity.Property(e => e.Expires).HasColumnType("datetime");

            entity.Property(e => e.RemoteIpAddress)
                   .HasMaxLength(500);

            entity.Property(e => e.CreatedAt).HasColumnType("datetime");

            entity.HasOne(d => d.ApplicationUser)
                   .WithMany(p => p.RefreshTokens)
                   .HasForeignKey(d => d.ApplicationUserId)
                   .OnDelete(DeleteBehavior.ClientSetNull)
                   .HasConstraintName("FK_RefreshTokens_ApplicationUser_PK_User");
        }
    }
}
