﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DataLayer.EfCode.Configurations
{
    internal class ApplicationUserConfig : IEntityTypeConfiguration<ApplicationUser>
    {
        public void Configure(EntityTypeBuilder<ApplicationUser> entity)
        {
            entity.ToTable(name: "User");

            //relationships
            entity.HasMany(p => p.RefreshTokens)
                .WithOne()
                .HasForeignKey(p => p.ApplicationUserId);

            entity.Metadata
                .FindNavigation(nameof(ApplicationUser.RefreshTokens))
                .SetPropertyAccessMode(PropertyAccessMode.Field);
        }
    }
}
