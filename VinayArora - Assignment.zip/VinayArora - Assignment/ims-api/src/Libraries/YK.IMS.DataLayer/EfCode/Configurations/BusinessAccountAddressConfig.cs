﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DataLayer.EfCode.Configurations
{
    internal class BusinessAccountAddressConfig : IEntityTypeConfiguration<BusinessAccountAddress>
    {
        public void Configure(EntityTypeBuilder<BusinessAccountAddress> entity)
        {
            entity.Property(e => e.Address1)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.Address2)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.Address3)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.CreatedAt).HasColumnType("datetime");

            entity.Property(e => e.Email)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

            entity.Property(e => e.Mobile)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.Property(e => e.AddressType)
                .IsRequired()
                .HasConversion<int>();

            entity.Property(e => e.Phone)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.Property(e => e.Pincode)
                .IsRequired()
                .HasMaxLength(10)
                .IsUnicode(false);

            entity.HasOne(d => d.BusinessAccount)
                .WithMany(p => p.BusinessAccountAddresses)
                .HasForeignKey(d => d.BusinessAccountId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessAccountAddress_BusinessAccountId_PK_BusinessAccount");

            entity.HasOne(d => d.City)
                .WithMany(p => p.BusinessAccountAddress)
                .HasForeignKey(d => d.CityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessAccountAddress_CityId_PK_City");

            entity.HasOne(d => d.Company)
                .WithMany(p => p.BusinessAccountAddress)
                .HasForeignKey(d => d.CompanyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessAccountAddress_CompanyId_PK_Company");

            entity.HasOne(d => d.Country)
                .WithMany(p => p.BusinessAccountAddress)
                .HasForeignKey(d => d.CountryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessAccountAddress_CountryId_PK_Country");

            entity.HasOne(d => d.State)
                .WithMany(p => p.BusinessAccountAddress)
                .HasForeignKey(d => d.StateId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessAccountAddress_StateId_PK_State");

        }
    }
}
