﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DataLayer.EfCode.Configurations
{
    internal class BusinessAccountConfig : IEntityTypeConfiguration<BusinessAccount>
    {
        public void Configure(EntityTypeBuilder<BusinessAccount> entity)
        {
            entity.Property(e => e.Code)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.Property(e => e.CreatedAt).HasColumnType("datetime");

            entity.Property(e => e.DefaultDiscountPercentage).HasColumnType("decimal(18, 2)");

            entity.Property(e => e.Description)
                .IsRequired()
                .HasMaxLength(500)
                .IsUnicode(false);

            entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

            entity.Property(e => e.Name)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.Property(e => e.TaxNumber)
                .HasMaxLength(20)
                .IsUnicode(false);

            entity.Property(e => e.BusinessType)
              .HasConversion<int>();

            entity.HasOne(d => d.BusinessTypeNavigation)
                .WithMany(p => p.BusinessAccount)
                .HasForeignKey(d => d.BusinessType)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessAccount_BusinessType_PK_BusinessType");

            entity.HasOne(d => d.Company)
                .WithMany(p => p.BusinessAccount)
                .HasForeignKey(d => d.CompanyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BusinessAccount_CompanyId_PK_Company");

            entity.Metadata
                .FindNavigation(nameof(BusinessAccount.BusinessAccountAddresses))
                .SetPropertyAccessMode(PropertyAccessMode.Field);
        }
    }
}
