﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace YK.IMS.DataLayer.EfCode
{
    public class IMSContextFactory : IDesignTimeDbContextFactory<IMSContext>
    {
        public IMSContext CreateDbContext(string[] args)
        {
            //Console.WriteLine("Path: " + Path.Combine(Directory.GetCurrentDirectory(), "../../Presentation/YK.IMS.Api"));

            // Build config
            IConfiguration config = new ConfigurationBuilder()
                .SetBasePath(Path.Combine(Directory.GetCurrentDirectory(), "../../Presentation/YK.IMS.Api"))
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();


            var optionsBuilder = new DbContextOptionsBuilder<IMSContext>()
                .UseSqlServer(
                config.GetConnectionString("DefaultConnection"),
                x => x.MigrationsAssembly(Assembly.GetAssembly(typeof(ApplicationDbContext)).FullName))
               .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);

            return new IMSContext(optionsBuilder.Options);
        }
    }
}
