﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DataLayer.EfCode.Configurations;

namespace YK.IMS.DataLayer.EfCode
{
    public partial class IMSContext : DbContext
    {
        public IMSContext(DbContextOptions<IMSContext> options)
            : base(options)
        {
        }

        #region Utilities

        /// <summary>
        /// Rollback of entity changes
        /// </summary>
        public void RollbackEntityChanges()
        {
            //rollback entity changes

            var entries = ChangeTracker.Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified).ToList();

            entries.ForEach(entry =>
            {
                try
                {
                    entry.State = EntityState.Unchanged;
                }
                catch (InvalidOperationException)
                {
                    // ignored
                }
            });

            //SaveChanges();
            //return exception.ToString();
        }

        #endregion

        public virtual DbSet<AccountType> AccountType { get; private set; }
        public virtual DbSet<Accounts> Accounts { get; private set; }
        public virtual DbSet<Branch> Branch { get; private set; }
        public virtual DbSet<BusinessAccount> BusinessAccount { get; private set; }
        public virtual DbSet<BusinessAccountAddress> BusinessAccountAddress { get; private set; }
        public virtual DbSet<BusinessType> BusinessType { get; private set; }
        public virtual DbSet<ChapterHeading> ChapterHeading { get; private set; }
        public virtual DbSet<City> City { get; private set; }
        public virtual DbSet<Color> Color { get; private set; }
        public virtual DbSet<Company> Company { get; private set; }
        public virtual DbSet<CompanyType> CompanyType { get; private set; }
        public virtual DbSet<Country> Country { get; private set; }
        public virtual DbSet<CreditNote> CreditNote { get; private set; }
        public virtual DbSet<CreditNoteLineItem> CreditNoteLineItem { get; private set; }
        public virtual DbSet<DebitNote> DebitNote { get; private set; }
        public virtual DbSet<DebitNoteLineItem> DebitNoteLineItem { get; private set; }
        public virtual DbSet<DeliveryNote> DeliveryNote { get; private set; }
        public virtual DbSet<DeliveryNoteLineItem> DeliveryNoteLineItem { get; private set; }
        public virtual DbSet<GeneralLedger> GeneralLedger { get; private set; }
        public virtual DbSet<InvoiceStatusType> InvoiceStatusType { get; private set; }
        public virtual DbSet<Make> Make { get; private set; }
        public virtual DbSet<MaterialType> MaterialType { get; private set; }
        public virtual DbSet<Model> Models { get; private set; }
        public virtual DbSet<PackSize> PackSize { get; private set; }
        public virtual DbSet<PaymentMethod> PaymentMethod { get; private set; }
        public virtual DbSet<PaymentTerm> PaymentTerm { get; private set; }
        public virtual DbSet<Product> Product { get; private set; }
        public virtual DbSet<ProductBusinessAccountMap> ProductBusinessAccountMap { get; private set; }
        public virtual DbSet<ProductGroup> ProductGroup { get; private set; }
        public virtual DbSet<ProductStock> ProductStock { get; private set; }
        public virtual DbSet<ProductUnitQuantityMap> ProductUnitQuantityMap { get; private set; }
        public virtual DbSet<Purchase> Purchase { get; private set; }
        public virtual DbSet<PurchaseLineItem> PurchaseLineItem { get; private set; }
        public virtual DbSet<PurchaseOrder> PurchaseOrder { get; private set; }
        public virtual DbSet<PurchaseOrderLineItem> PurchaseOrderLineItem { get; private set; }
        public virtual DbSet<Sale> Sale { get; private set; }
        public virtual DbSet<SaleLineItem> SaleLineItem { get; private set; }
        public virtual DbSet<SaleOrder> SaleOrder { get; private set; }
        public virtual DbSet<SaleOrderLineItem> SaleOrderLineItem { get; private set; }
        public virtual DbSet<Size> Size { get; private set; }
        public virtual DbSet<State> State { get; private set; }
        public virtual DbSet<Style> Style { get; private set; }
        public virtual DbSet<TransactionType> TransactionType { get; private set; }
        public virtual DbSet<Unit> Unit { get; private set; }
        public virtual DbSet<Warehouse> Warehouse { get; private set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<AccountType>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Accounts>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.AccountTypeNavigation)
                    .WithMany(p => p.Accounts)
                    .HasForeignKey(d => d.AccountType)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Accounts_AccountType_PK_AccountType");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.Accounts)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Accounts_CompanyId_PK_Company");

            });

            modelBuilder.Entity<Branch>(entity =>
            {
                entity.Property(e => e.Address1)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Address2)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Address3)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Fax)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Mobile)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pincode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.City)
                    .WithMany(p => p.Branch)
                    .HasForeignKey(d => d.CityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Branch_CityId_PK_City");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.Branch)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Branch_CompanyId_PK_Company");

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.Branch)
                    .HasForeignKey(d => d.CountryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Branch_CountryId_PK_Country");

                entity.HasOne(d => d.State)
                    .WithMany(p => p.Branch)
                    .HasForeignKey(d => d.StateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Branch_StateId_PK_State");
            });

            modelBuilder.ApplyConfiguration(new BusinessAccountConfig());

            modelBuilder.ApplyConfiguration(new BusinessAccountAddressConfig());

            modelBuilder.Entity<BusinessType>(entity =>
            {
                entity.Property(s => s.Id)
                .HasConversion<int>();

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.Company)
                   .WithMany(p => p.BusinessType)
                   .HasForeignKey(d => d.CompanyId)
                   .OnDelete(DeleteBehavior.ClientSetNull)
                   .HasConstraintName("FK_BusinessType_CompanyId_PK_Company");

            });

            modelBuilder.Entity<ChapterHeading>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.ChapterHeading)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ChapterHeading_CompanyId_PK_Company");

            });

            modelBuilder.Entity<City>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.State)
                    .WithMany(p => p.City)
                    .HasForeignKey(d => d.StateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_City_StateId_PK_State");
            });

            modelBuilder.Entity<Color>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.Color)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Color_CompanyId_PK_Company");

            });

            modelBuilder.Entity<Company>(entity =>
            {
                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.EndingDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StartingDate).HasColumnType("datetime");

                entity.Property(e => e.TaxNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.CompanyType)
                    .WithMany(p => p.Company)
                    .HasForeignKey(d => d.CompanyTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Company_CompanyTypeId_PK_CompanyType");

                entity.HasOne(d => d.ParentCompany)
                    .WithMany(p => p.InverseParentCompany)
                    .HasForeignKey(d => d.ParentCompanyId)
                    .HasConstraintName("FK_Company_ParentCompanyId_PK_Company");
            });

            modelBuilder.Entity<CompanyType>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Country>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CreditNote>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.InvoiceNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.IssueDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalDiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.CreditNote)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNote_BranchId_PK_Branch");

                entity.HasOne(d => d.BusinessAccount)
                    .WithMany(p => p.CreditNote)
                    .HasForeignKey(d => d.BusinessAccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNote_BusinessAccountId_PK_BusinessAccount");

                entity.HasOne(d => d.Sale)
                    .WithMany(p => p.CreditNote)
                    .HasForeignKey(d => d.SaleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNote_SaleId_PK_Sale");
            });

            modelBuilder.Entity<CreditNoteLineItem>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.CreditNoteLineItem)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNoteLineItem_BranchId_PK_Branch");

                entity.HasOne(d => d.Color)
                    .WithMany(p => p.CreditNoteLineItem)
                    .HasForeignKey(d => d.ColorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNoteLineItem_ColorId_PK_Color");

                entity.HasOne(d => d.CreditNote)
                    .WithMany(p => p.CreditNoteLineItem)
                    .HasForeignKey(d => d.CreditNoteId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNoteLineItem_CreditNoteId_PK_CreditNote");

                entity.HasOne(d => d.Make)
                    .WithMany(p => p.CreditNoteLineItem)
                    .HasForeignKey(d => d.MakeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNoteLineItem_MakeId_PK_Make");

                entity.HasOne(d => d.Model)
                    .WithMany(p => p.CreditNoteLineItem)
                    .HasForeignKey(d => d.ModelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNoteLineItem_ModelId_PK_Model");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.CreditNoteLineItem)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNoteLineItem_ProductId_PK_Product");

                entity.HasOne(d => d.Size)
                    .WithMany(p => p.CreditNoteLineItem)
                    .HasForeignKey(d => d.SizeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNoteLineItem_SizeId_PK_Size");

                entity.HasOne(d => d.Style)
                    .WithMany(p => p.CreditNoteLineItem)
                    .HasForeignKey(d => d.StyleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNoteLineItem_StyleId_PK_Style");

                entity.HasOne(d => d.Unit)
                    .WithMany(p => p.CreditNoteLineItem)
                    .HasForeignKey(d => d.UnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CreditNoteLineItem_UnitId_PK_Unit");
            });

            modelBuilder.Entity<DebitNote>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.InvoiceNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.IssueDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalDiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.DebitNote)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNote_BranchId_PK_Branch");

                entity.HasOne(d => d.BusinessAccount)
                    .WithMany(p => p.DebitNote)
                    .HasForeignKey(d => d.BusinessAccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNote_BusinessAccountId_PK_BusinessAccount");

                entity.HasOne(d => d.Purchase)
                    .WithMany(p => p.DebitNote)
                    .HasForeignKey(d => d.PurchaseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNote_PurchaseId_PK_Purchase");
            });

            modelBuilder.Entity<DebitNoteLineItem>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.DebitNoteLineItem)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNoteLineItem_BranchId_PK_Branch");

                entity.HasOne(d => d.Color)
                    .WithMany(p => p.DebitNoteLineItem)
                    .HasForeignKey(d => d.ColorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNoteLineItem_ColorId_PK_Color");

                entity.HasOne(d => d.DebitNote)
                    .WithMany(p => p.DebitNoteLineItem)
                    .HasForeignKey(d => d.DebitNoteId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNoteLineItem_DebitNoteId_PK_DebitNote");

                entity.HasOne(d => d.Make)
                    .WithMany(p => p.DebitNoteLineItem)
                    .HasForeignKey(d => d.MakeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNoteLineItem_MakeId_PK_Make");

                entity.HasOne(d => d.Model)
                    .WithMany(p => p.DebitNoteLineItem)
                    .HasForeignKey(d => d.ModelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNoteLineItem_ModelId_PK_Model");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.DebitNoteLineItem)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNoteLineItem_ProductId_PK_Product");

                entity.HasOne(d => d.Size)
                    .WithMany(p => p.DebitNoteLineItem)
                    .HasForeignKey(d => d.SizeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNoteLineItem_SizeId_PK_Size");

                entity.HasOne(d => d.Style)
                    .WithMany(p => p.DebitNoteLineItem)
                    .HasForeignKey(d => d.StyleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNoteLineItem_StyleId_PK_Style");

                entity.HasOne(d => d.Unit)
                    .WithMany(p => p.DebitNoteLineItem)
                    .HasForeignKey(d => d.UnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DebitNoteLineItem_UnitId_PK_Unit");
            });

            modelBuilder.Entity<DeliveryNote>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.DeliveryDate).HasColumnType("datetime");

                entity.Property(e => e.DeliveryNoteNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalDiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.DeliveryNote)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNote_BranchId_PK_Branch");

                entity.HasOne(d => d.BusinessAccount)
                    .WithMany(p => p.DeliveryNote)
                    .HasForeignKey(d => d.BusinessAccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNote_BusinessAccountId_PK_BusinessAccount");

                entity.HasOne(d => d.PurchaseOrder)
                    .WithMany(p => p.DeliveryNote)
                    .HasForeignKey(d => d.PurchaseOrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNote_PurchaseOrderId_PK_PurchaseOrder");
            });

            modelBuilder.Entity<DeliveryNoteLineItem>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.DeliveryNoteLineItem)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNoteLineItem_BranchId_PK_Branch");

                entity.HasOne(d => d.Color)
                    .WithMany(p => p.DeliveryNoteLineItem)
                    .HasForeignKey(d => d.ColorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNoteLineItem_ColorId_PK_Color");

                entity.HasOne(d => d.DeliveryNote)
                    .WithMany(p => p.DeliveryNoteLineItem)
                    .HasForeignKey(d => d.DeliveryNoteId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNoteLineItem_DeliveryNoteId_PK_DeliveryNote");

                entity.HasOne(d => d.Make)
                    .WithMany(p => p.DeliveryNoteLineItem)
                    .HasForeignKey(d => d.MakeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNoteLineItem_MakeId_PK_Make");

                entity.HasOne(d => d.Model)
                    .WithMany(p => p.DeliveryNoteLineItem)
                    .HasForeignKey(d => d.ModelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNoteLineItem_ModelId_PK_Model");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.DeliveryNoteLineItem)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNoteLineItem_ProductId_PK_Product");

                entity.HasOne(d => d.Size)
                    .WithMany(p => p.DeliveryNoteLineItem)
                    .HasForeignKey(d => d.SizeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNoteLineItem_SizeId_PK_Size");

                entity.HasOne(d => d.Style)
                    .WithMany(p => p.DeliveryNoteLineItem)
                    .HasForeignKey(d => d.StyleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNoteLineItem_StyleId_PK_Style");

                entity.HasOne(d => d.Unit)
                    .WithMany(p => p.DeliveryNoteLineItem)
                    .HasForeignKey(d => d.UnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DeliveryNoteLineItem_UnitId_PK_Unit");
            });

            modelBuilder.Entity<GeneralLedger>(entity =>
            {
                entity.Property(e => e.BalanceAmount).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.CreditAmount).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DebitAmount).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Narration)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.ReferenceNo)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.BusinessAccount)
                    .WithMany(p => p.GeneralLedger)
                    .HasForeignKey(d => d.BusinessAccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GeneralLedger_BusinessAccountId_PK_BusinessAccount");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.GeneralLedger)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GeneralLedger_CompanyId_PK_Company");

                entity.HasOne(d => d.TransactionTypeNavigation)
                    .WithMany(p => p.GeneralLedger)
                    .HasForeignKey(d => d.TransactionType)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GeneralLedger_TransactionTypeId_PK_TransactionType");
            });

            modelBuilder.Entity<InvoiceStatusType>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Make>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.Make)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Make_CompanyId_PK_Company");
            });

            modelBuilder.Entity<MaterialType>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.MaterialType)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MaterialType_CompanyId_PK_Company");

            });

            modelBuilder.Entity<Model>(entity =>
            {
                entity.ToTable("Model");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.Model)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Model_CompanyId_PK_Company");
            });

            modelBuilder.Entity<PackSize>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.PackSize)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PackSize_CompanyId_PK_Company");

            });

            modelBuilder.Entity<PaymentMethod>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.PaymentMethod)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PaymentMethod_CompanyId_PK_Company");

            });

            modelBuilder.Entity<PaymentTerm>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.PaymentTerm)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PaymentTerm_CompanyId_PK_Company");
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(e => e.Barcode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.DefaultDiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DefaultDiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DefaultPurchasePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DefaultSalePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RetailSalePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.RackNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.ChapterHeading)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.ChapterHeadingId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_ChapterHeadingId_PK_ChapterHeading");

                entity.HasOne(d => d.Color)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.ColorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_ColorId_PK_Color");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_CompanyId_PK_Company");

                entity.HasOne(d => d.Make)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.MakeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_MakeId_PK_Make");

                entity.HasOne(d => d.MaterialType)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.MaterialTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_MaterialTypeId_PK_MaterialType");

                entity.HasOne(d => d.Model)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.ModelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_ModelId_PK_Model");

                entity.HasOne(d => d.PackSize)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.PackSizeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_PackSizeId_PK_PackSize");

                entity.HasOne(d => d.ProductGroup)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.ProductGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_ProductGroupId_PK_ProductGroup");

                entity.HasOne(d => d.RetailUnit)
                    .WithMany(p => p.ProductRetailUnit)
                    .HasForeignKey(d => d.RetailUnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_RetailUnitId_PK_Unit");

                entity.HasOne(d => d.Size)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.SizeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_SizeId_PK_Size");

                entity.HasOne(d => d.Style)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.StyleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_StyleId_PK_Style");

                entity.HasOne(d => d.Unit)
                    .WithMany(p => p.ProductUnit)
                    .HasForeignKey(d => d.UnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_UnitId_PK_Unit");
            });

            modelBuilder.Entity<ProductBusinessAccountMap>(entity =>
            {
                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.DefaultDiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DefaultDiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DefaultSalePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.BusinessAccount)
                    .WithMany(p => p.ProductBusinessAccountMap)
                    .HasForeignKey(d => d.BusinessAccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductBusinessAccountMap_BusinessAccountId_PK_BusinessAccount");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.ProductBusinessAccountMap)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductBusinessAccountMap_CompanyId_PK_Company");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.ProductBusinessAccountMap)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductBusinessAccountMap_ProductId_PK_Product");
            });

            modelBuilder.Entity<ProductGroup>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.ProductGroup)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductGroup_CompanyId_PK_Company");

            });

            modelBuilder.Entity<ProductStock>(entity =>
            {
                entity.Property(e => e.BalanceQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.OpeningQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.ReceivingQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.RejectedQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.ShipmentQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TransferInQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TransferOutQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.ProductStocks)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductStock_ProductId_PK_Product");

                entity.HasOne(d => d.Warehouse)
                    .WithMany(p => p.ProductStock)
                    .HasForeignKey(d => d.WarehouseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductStock_WarehouseId_PK_Warehouse");
            });

            modelBuilder.Entity<ProductUnitQuantityMap>(entity =>
            {
                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.DefaultDiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DefaultDiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DefaultUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.MaxUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.MinUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.ProductUnitQuantityMap)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductUnitQuantityMap_CompanyId_PK_Company");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.ProductUnitQuantityMap)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductUnitQuantityMap_ProductId_PK_Product");

                entity.HasOne(d => d.Unit)
                    .WithMany(p => p.ProductUnitQuantityMap)
                    .HasForeignKey(d => d.UnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductUnitQuantityMap_UnitId_PK_Unit");
            });

            modelBuilder.Entity<Purchase>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.InvoiceNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.ReceiveDate).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalDiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.Purchase)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Purchase_BranchId_PK_Branch");

                entity.HasOne(d => d.BusinessAccount)
                    .WithMany(p => p.Purchase)
                    .HasForeignKey(d => d.BusinessAccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Purchase_BusinessAccountId_PK_BusinessAccount");

                entity.HasOne(d => d.DeliveryNote)
                    .WithMany(p => p.Purchase)
                    .HasForeignKey(d => d.DeliveryNoteId)
                    .HasConstraintName("FK_Purchase_DeliveryNoteId_PK_DeliveryNote");
            });

            modelBuilder.Entity<PurchaseLineItem>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.PurchaseLineItem)
                    .HasForeignKey(d => d.BranchId)
                    .HasConstraintName("FK_PurchaseLineItem_BranchId_PK_Branch");

                entity.HasOne(d => d.Color)
                    .WithMany(p => p.PurchaseLineItem)
                    .HasForeignKey(d => d.ColorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseLineItem_ColorId_PK_Color");

                entity.HasOne(d => d.DeliveryNoteLineItem)
                    .WithMany(p => p.PurchaseLineItem)
                    .HasForeignKey(d => d.DeliveryNoteLineItemId)
                    .HasConstraintName("FK_PurchaseLineItem_DeliveryNoteLineItemId_PK_DeliveryNoteLineItem");

                entity.HasOne(d => d.Make)
                    .WithMany(p => p.PurchaseLineItem)
                    .HasForeignKey(d => d.MakeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseLineItem_MakeId_PK_Make");

                entity.HasOne(d => d.Model)
                    .WithMany(p => p.PurchaseLineItem)
                    .HasForeignKey(d => d.ModelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseLineItem_ModelId_PK_Model");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.PurchaseLineItem)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseLineItem_ProductId_PK_Product");

                entity.HasOne(d => d.Purchase)
                    .WithMany(p => p.PurchaseLineItem)
                    .HasForeignKey(d => d.PurchaseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseLineItem_PurchaseId_PK_Purchase");

                entity.HasOne(d => d.Size)
                    .WithMany(p => p.PurchaseLineItem)
                    .HasForeignKey(d => d.SizeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseLineItem_SizeId_PK_Size");

                entity.HasOne(d => d.Style)
                    .WithMany(p => p.PurchaseLineItem)
                    .HasForeignKey(d => d.StyleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseLineItem_StyleId_PK_Style");

                entity.HasOne(d => d.Unit)
                    .WithMany(p => p.PurchaseLineItem)
                    .HasForeignKey(d => d.UnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseLineItem_UnitId_PK_Unit");
            });

            modelBuilder.Entity<PurchaseOrder>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.DeliveryAddress)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.IssueDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.PaymentDue).HasColumnType("datetime");

                entity.Property(e => e.PurchaseOrderNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.StockDue).HasColumnType("datetime");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalDiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalReceivedUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.PurchaseOrder)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrder_BranchId_PK_Branch");

                entity.HasOne(d => d.BusinessAccount)
                    .WithMany(p => p.PurchaseOrder)
                    .HasForeignKey(d => d.BusinessAccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrder_BusinessAccountId_PK_BusinessAccount");
            });

            modelBuilder.Entity<PurchaseOrderLineItem>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.ReceivedUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.PurchaseOrderLineItem)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrderLineItem_BranchId_PK_Branch");

                entity.HasOne(d => d.Color)
                    .WithMany(p => p.PurchaseOrderLineItem)
                    .HasForeignKey(d => d.ColorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrderLineItem_ColorId_PK_Color");

                entity.HasOne(d => d.Make)
                    .WithMany(p => p.PurchaseOrderLineItem)
                    .HasForeignKey(d => d.MakeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrderLineItem_MakeId_PK_Make");

                entity.HasOne(d => d.Model)
                    .WithMany(p => p.PurchaseOrderLineItem)
                    .HasForeignKey(d => d.ModelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrderLineItem_ModelId_PK_Model");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.PurchaseOrderLineItem)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrderLineItem_ProductId_PK_Product");

                entity.HasOne(d => d.PurchaseOrder)
                    .WithMany(p => p.PurchaseOrderLineItem)
                    .HasForeignKey(d => d.PurchaseOrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrderLineItem_PurchaseOrderId_PK_PurchaseOrder");

                entity.HasOne(d => d.Size)
                    .WithMany(p => p.PurchaseOrderLineItem)
                    .HasForeignKey(d => d.SizeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrderLineItem_SizeId_PK_Size");

                entity.HasOne(d => d.Style)
                    .WithMany(p => p.PurchaseOrderLineItem)
                    .HasForeignKey(d => d.StyleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrderLineItem_StyleId_PK_Style");

                entity.HasOne(d => d.Unit)
                    .WithMany(p => p.PurchaseOrderLineItem)
                    .HasForeignKey(d => d.UnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PurchaseOrderLineItem_UnitId_PK_Unit");
            });

            modelBuilder.Entity<Sale>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.DeliveryAddress)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.DeliveryDate).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.InvoiceNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.IssueDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalDiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.Sale)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Sale_BranchId_PK_Branch");

                entity.HasOne(d => d.BusinessAccount)
                    .WithMany(p => p.Sale)
                    .HasForeignKey(d => d.BusinessAccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Sale_BusinessAccountId_PK_BusinessAccount");

                entity.HasOne(d => d.SaleOrder)
                    .WithMany(p => p.Sale)
                    .HasForeignKey(d => d.SaleOrderId)
                    .HasConstraintName("FK_Sale_SaleOrderId_PK_SaleOrder");
            });

            modelBuilder.Entity<SaleLineItem>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.SaleLineItem)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleLineItem_BranchId_PK_Branch");

                entity.HasOne(d => d.Color)
                    .WithMany(p => p.SaleLineItem)
                    .HasForeignKey(d => d.ColorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleLineItem_ColorId_PK_Color");

                entity.HasOne(d => d.Make)
                    .WithMany(p => p.SaleLineItem)
                    .HasForeignKey(d => d.MakeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleLineItem_MakeId_PK_Make");

                entity.HasOne(d => d.Model)
                    .WithMany(p => p.SaleLineItem)
                    .HasForeignKey(d => d.ModelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleLineItem_ModelId_PK_Model");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.SaleLineItem)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleLineItem_ProductId_PK_Product");

                entity.HasOne(d => d.Sale)
                    .WithMany(p => p.SaleLineItem)
                    .HasForeignKey(d => d.SaleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleLineItem_SaleId_PK_Sale");

                entity.HasOne(d => d.Size)
                    .WithMany(p => p.SaleLineItem)
                    .HasForeignKey(d => d.SizeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleLineItem_SizeId_PK_Size");

                entity.HasOne(d => d.Style)
                    .WithMany(p => p.SaleLineItem)
                    .HasForeignKey(d => d.StyleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleLineItem_StyleId_PK_Style");

                entity.HasOne(d => d.Unit)
                    .WithMany(p => p.SaleLineItem)
                    .HasForeignKey(d => d.UnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleLineItem_UnitId_PK_Unit");
            });

            modelBuilder.Entity<SaleOrder>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.DeliveryAddress)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.IssueDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.PaymentDue).HasColumnType("datetime");

                entity.Property(e => e.SaleOrderNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.StockDue).HasColumnType("datetime");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalDeliveredUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalDiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.SaleOrder)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrder_BranchId_PK_Branch");

                entity.HasOne(d => d.BusinessAccount)
                    .WithMany(p => p.SaleOrder)
                    .HasForeignKey(d => d.BusinessAccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrder_BusinessAccountId_PK_BusinessAccount");

            });

            modelBuilder.Entity<SaleOrderLineItem>(entity =>
            {
                entity.Property(e => e.Cgstpercentage)
                    .HasColumnName("CGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.DeliveredUnitQuantity).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.DiscountPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Igstpercentage)
                    .HasColumnName("IGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Sgstpercentage)
                    .HasColumnName("SGSTPercentage")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TaxPercentage).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalCgstprice)
                    .HasColumnName("TotalCGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalIgstprice)
                    .HasColumnName("TotalIGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalSgstprice)
                    .HasColumnName("TotalSGSTPrice")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalTaxablePrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TotalUnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitPrice).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.UnitQuantity).HasColumnType("decimal(18, 2)");

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.SaleOrderLineItem)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrderLineItem_BranchId_PK_Branch");

                entity.HasOne(d => d.Color)
                    .WithMany(p => p.SaleOrderLineItem)
                    .HasForeignKey(d => d.ColorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrderLineItem_ColorId_PK_Color");

                entity.HasOne(d => d.Make)
                    .WithMany(p => p.SaleOrderLineItem)
                    .HasForeignKey(d => d.MakeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrderLineItem_MakeId_PK_Make");

                entity.HasOne(d => d.Model)
                    .WithMany(p => p.SaleOrderLineItem)
                    .HasForeignKey(d => d.ModelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrderLineItem_ModelId_PK_Model");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.SaleOrderLineItem)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrderLineItem_ProductId_PK_Product");

                entity.HasOne(d => d.SaleOrder)
                    .WithMany(p => p.SaleOrderLineItem)
                    .HasForeignKey(d => d.SaleOrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrderLineItem_SaleOrderId_PK_Sale");

                entity.HasOne(d => d.Size)
                    .WithMany(p => p.SaleOrderLineItem)
                    .HasForeignKey(d => d.SizeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrderLineItem_SizeId_PK_Size");

                entity.HasOne(d => d.Style)
                    .WithMany(p => p.SaleOrderLineItem)
                    .HasForeignKey(d => d.StyleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrderLineItem_StyleId_PK_Style");

                entity.HasOne(d => d.Unit)
                    .WithMany(p => p.SaleOrderLineItem)
                    .HasForeignKey(d => d.UnitId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SaleOrderLineItem_UnitId_PK_Unit");
            });

            modelBuilder.Entity<Size>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.Size)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Size_CompanyId_PK_Company");

            });

            modelBuilder.Entity<State>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.State)
                    .HasForeignKey(d => d.CountryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_State_CountryId_PK_Country");

            });

            modelBuilder.Entity<Style>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.Style)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Style_CompanyId_PK_Company");

            });

            modelBuilder.Entity<TransactionType>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

            });

            modelBuilder.Entity<Unit>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.Unit)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Unit_CompanyId_PK_Company");

            });

            modelBuilder.Entity<Warehouse>(entity =>
            {
                entity.Property(e => e.Address1)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Address2)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Address3)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Fax)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedAt).HasColumnType("datetime");

                entity.Property(e => e.Mobile)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pincode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Branch)
                    .WithMany(p => p.Warehouse)
                    .HasForeignKey(d => d.BranchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Warehouse_BranchId_PK_Branch");

                entity.HasOne(d => d.City)
                    .WithMany(p => p.Warehouse)
                    .HasForeignKey(d => d.CityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Warehouse_CityId_PK_City");

                entity.HasOne(d => d.Country)
                    .WithMany(p => p.Warehouse)
                    .HasForeignKey(d => d.CountryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Warehouse_CountryId_PK_Country");

                entity.HasOne(d => d.State)
                    .WithMany(p => p.Warehouse)
                    .HasForeignKey(d => d.StateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Warehouse_StateId_PK_State");
            });
        }
    }
}
