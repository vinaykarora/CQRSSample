﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YK.IMS.DataLayer.Requests
{
    public interface IRequest
    {
    }
}
