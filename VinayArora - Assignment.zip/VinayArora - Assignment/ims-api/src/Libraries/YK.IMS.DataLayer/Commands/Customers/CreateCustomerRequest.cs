﻿using System;
using YK.IMS.Core.Enums;

namespace YK.IMS.DataLayer.Requests.Customers
{
    public class CreateCustomerRequest : BaseCreateRequest
    {
        public CreateCustomerRequest(int companyId, string name, string code, string description, string createdBy, BusinessType businessType, string taxNumber, int? assignedTo, int? defaultStockLocation, decimal defaultDiscountPercentage, int? defaultPaymentTerm, int? defaultPaymentMethod, AddAddressRequest address)
            : base(companyId, name, code, description, createdBy)
        {
            BusinessType = businessType;
            TaxNumber = taxNumber ?? throw new ArgumentNullException(nameof(taxNumber));
            AssignedTo = assignedTo;
            DefaultStockLocation = defaultStockLocation;
            DefaultDiscountPercentage = defaultDiscountPercentage;
            DefaultPaymentTerm = defaultPaymentTerm;
            DefaultPaymentMethod = defaultPaymentMethod;
            Address = address ?? throw new ArgumentNullException(nameof(address));
        }

        public BusinessType BusinessType { get; }
        public string TaxNumber { get; }
        public int? AssignedTo { get; }
        public int? DefaultStockLocation { get; }
        public decimal DefaultDiscountPercentage { get; }
        public int? DefaultPaymentTerm { get; }
        public int? DefaultPaymentMethod { get; }
        public AddAddressRequest Address { get; }
    }
}
