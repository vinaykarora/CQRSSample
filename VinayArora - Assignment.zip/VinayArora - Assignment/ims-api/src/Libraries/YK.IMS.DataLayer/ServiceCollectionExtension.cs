﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DataLayer.EfCode;

namespace YK.IMS.DataLayer
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection ConfigureApplicationDbContext(this IServiceCollection services, Serilog.ILogger logger, IConfiguration configuration)
        {
            logger.Information($"Add {nameof(ApplicationDbContext)} to the service collection.");
            string connection = configuration.GetConnectionString("DefaultConnection");

            services.AddDbContext<ApplicationDbContext>(options =>
               options
               .UseSqlServer(connection, x => x.MigrationsAssembly(Assembly.GetAssembly(typeof(ApplicationDbContext)).FullName))
               .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking));

            return services;
        }

        public static IServiceCollection ConfigureIMSContext(this IServiceCollection services, Serilog.ILogger logger, IConfiguration configuration)
        {
            logger.Information($"Add {nameof(ApplicationDbContext)} to the service collection.");
            string connection = configuration.GetConnectionString("DefaultConnection");

            services.AddDbContext<IMSContext>(options =>
               options.UseSqlServer(connection,
                   x => x.MigrationsAssembly(Assembly.GetAssembly(typeof(IMSContext)).FullName)));
            services.AddScoped<DbContext, IMSContext>();
            return services;
        }

        public static IServiceCollection ConfigureIdentity(this IServiceCollection services, Serilog.ILogger logger)
        {
            logger.Information("Add identity to the service collection.");
            services.AddIdentity<ApplicationUser, IdentityRole>(options =>
            {
                // Password settings.
                options.Password.RequireDigit = true;
                options.Password.RequireLowercase = true;
                options.Password.RequireNonAlphanumeric = true;
                options.Password.RequireUppercase = true;
                options.Password.RequiredLength = 6;
                options.Password.RequiredUniqueChars = 1;

                // Lockout settings.
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(5);
                options.Lockout.MaxFailedAccessAttempts = 5;
                options.Lockout.AllowedForNewUsers = true;

                // User settings.
                options.User.AllowedUserNameCharacters =
                   "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._@+";
                options.User.RequireUniqueEmail = true;
            })
               .AddEntityFrameworkStores<ApplicationDbContext>()
               .AddDefaultTokenProviders();

            return services;
        }
    }
}
