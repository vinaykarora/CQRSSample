﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Styles
{
    public interface IStyleDbAccess
    {
        Task Create(Style style);
        void Update(Style style);
        Task<IEnumerable<Style>> FindByName(string name);
        Task<Style> FindById(int id);
        Task<bool> IsDuplicate(int id, string name, string code);

        IQueryable<Style> NoTrackingEntity { get; }
        DbSet<Style> Entity { get; }
    }
}
