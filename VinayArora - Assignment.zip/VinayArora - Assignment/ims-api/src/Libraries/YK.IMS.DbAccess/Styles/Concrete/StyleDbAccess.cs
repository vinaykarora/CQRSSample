﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Styles
{
    public class StyleDbAccess : BaseDbAccess, IStyleDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<Style> NoTrackingEntity => Context.Set<Style>().AsNoTracking();

        public DbSet<Style> Entity => Context.Set<Style>();

        public StyleDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<StyleDbAccess>();
        }

        public async Task Create(Style style)
        {
            if (style == null)
            {
                throw new ArgumentNullException(nameof(style));
            }

            _logger.Information($"Create the style in the store.");
            if (!await IsDuplicate(style.Id, style.Name, style.Code))
            {
                await Entity.AddAsync(style);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<Style>> FindByName(string name)
        {
            _logger.Information($"Find the style by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()).ToListAsync();
        }

        public async Task<Style> FindById(int id)
        {
            _logger.Information($"Find the style by id '{id}' from the storage.");
            return await NoTrackingEntity.SingleOrDefaultAsync(f => f.Id == id);
        }

        public async Task<bool> IsDuplicate(int id, string name, string code)
        {
            _logger.Information($"Ensure style is not duplicate by name '{name}' and code '{code}'.");
            return await NoTrackingEntity.AnyAsync(
                w => w.IsDelete == false && w.Id != id
                && (w.Name.ToLower() == name.ToLower() || w.Code.ToLower() == code.ToLower()));
        }

        public void Update(Style style)
        {
            if (style == null)
            {
                throw new ArgumentNullException(nameof(style));
            }

            _logger.Information($"Update the style in the store.");
            if (!IsDuplicate(style.Id, style.Name, style.Code).GetAwaiter().GetResult())
            {
                Entity.Update(style);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }
    }
}
