﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Makes
{
    public class MakeDbAccess : BaseDbAccess, IMakeDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<Make> NoTrackingEntity => Context.Set<Make>().AsNoTracking();

        public DbSet<Make> Entity => Context.Set<Make>();

        public MakeDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<MakeDbAccess>();
        }

        public async Task Create(Make make)
        {
            if (make == null)
            {
                throw new ArgumentNullException(nameof(make));
            }

            _logger.Information($"Create the make in the store.");
            if (!await IsDuplicate(make.Id, make.Name, make.Code))
            {
                await Entity.AddAsync(make);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<Make>> FindByName(string name)
        {
            _logger.Information($"Find the make by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()).ToListAsync();
        }

        public async Task<Make> FindById(int id)
        {
            _logger.Information($"Find the make by id '{id}' from the storage.");
            return await NoTrackingEntity.SingleOrDefaultAsync(f => f.Id == id);
        }

        public async Task<bool> IsDuplicate(int id, string name, string code)
        {
            _logger.Information($"Ensure make is not duplicate by name '{name}' and code '{code}'.");
            return await NoTrackingEntity.AnyAsync(
                w => w.IsDelete == false && w.Id != id
                && (w.Name.ToLower() == name.ToLower() || w.Code.ToLower() == code.ToLower()));
        }

        public void Update(Make make)
        {
            if (make == null)
            {
                throw new ArgumentNullException(nameof(make));
            }

            _logger.Information($"Update the make in the store.");
            if (!IsDuplicate(make.Id, make.Name, make.Code).GetAwaiter().GetResult())
            {
                Entity.Update(make);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }
    }
}
