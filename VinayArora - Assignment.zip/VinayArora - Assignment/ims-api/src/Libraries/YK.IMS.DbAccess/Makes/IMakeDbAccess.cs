﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Makes
{
    public interface IMakeDbAccess
    {
        Task Create(Make make);
        void Update(Make make);
        Task<IEnumerable<Make>> FindByName(string name);
        Task<Make> FindById(int id);
        Task<bool> IsDuplicate(int id, string name, string code);

        IQueryable<Make> NoTrackingEntity { get; }
        DbSet<Make> Entity { get; }
    }
}
