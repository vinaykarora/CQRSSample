﻿using System;
using System.Collections.Generic;
using System.Text;
using YK.IMS.Core.Dto;

namespace YK.IMS.DbAccess
{
    public abstract class BaseDbResponse
    {
        public bool Success { get; }
        public IEnumerable<Error> Errors { get; }

        protected BaseDbResponse(bool success = false, IEnumerable<Error> errors = null)
        {
            Success = success;
            Errors = errors;
        }
    }
}