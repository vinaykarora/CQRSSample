﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Products
{
    public interface IProductDbAccess
    {
        Task Create(Product product);
        void Update(Product product);
        Task<IEnumerable<Product>> FindByName(string name);
        Task<Product> FindById(int id);
        Task<bool> IsDuplicate(int id, string name, string code);

        IQueryable<Product> NoTrackingEntity { get; }
        DbSet<Product> Entity { get; }
    }
}
