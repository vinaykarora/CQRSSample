﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Products
{
    public class ProductDbAccess : BaseDbAccess, IProductDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<Product> NoTrackingEntity => Context.Set<Product>().AsNoTracking();

        public DbSet<Product> Entity => Context.Set<Product>();

        public ProductDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<ProductDbAccess>();
        }

        public async Task Create(Product product)
        {
            if (product == null)
            {
                throw new ArgumentNullException(nameof(product));
            }

            _logger.Information($"Create the product in the store.");
            if (!await IsDuplicate(product.Id, product.Name, product.Code))
            {
                await Entity.AddAsync(product);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<Product>> FindByName(string name)
        {
            _logger.Information($"Find the product by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()).ToListAsync();
        }

        public async Task<Product> FindById(int id)
        {
            _logger.Information($"Find the product by id '{id}' from the storage.");
            return await NoTrackingEntity.SingleOrDefaultAsync(f => f.Id == id);
        }

        public async Task<bool> IsDuplicate(int id, string name, string code)
        {
            _logger.Information($"Ensure product is not duplicate by name '{name}' and code '{code}'.");
            return await NoTrackingEntity.AnyAsync(
                w => w.IsDelete == false && w.Id != id
                && (w.Name.ToLower() == name.ToLower() || w.Code.ToLower() == code.ToLower()));
        }

        public void Update(Product product)
        {
            if (product == null)
            {
                throw new ArgumentNullException(nameof(product));
            }

            _logger.Information($"Update the product in the store.");
            if (!IsDuplicate(product.Id, product.Name, product.Code).GetAwaiter().GetResult())
            {
                Entity.Update(product);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }
    }
}
