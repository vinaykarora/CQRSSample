﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Customers
{
    public interface ICustomerDbAccess
    {
        Task Create(BusinessAccount Customer);
        void Update(BusinessAccount Customer);
        Task<IEnumerable<BusinessAccount>> FindByName(string name);
        Task<BusinessAccount> FindById(int id);
        Task<bool> IsDuplicate(int id, string email);

        IQueryable<BusinessAccount> NoTrackingEntity { get; }
        DbSet<BusinessAccount> Entity { get; }
    }
}
