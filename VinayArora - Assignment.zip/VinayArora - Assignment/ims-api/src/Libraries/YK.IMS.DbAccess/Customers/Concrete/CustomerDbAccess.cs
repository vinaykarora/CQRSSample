﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Customers
{
    public class CustomerDbAccess : BaseDbAccess, ICustomerDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<BusinessAccount> NoTrackingEntity => Context.Set<BusinessAccount>().AsNoTracking();
        public IQueryable<BusinessAccountAddress> AddressNoTrackingEntity => Context.Set<BusinessAccountAddress>().AsNoTracking();
        public DbSet<BusinessAccount> Entity => Context.Set<BusinessAccount>();

        public CustomerDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<CustomerDbAccess>();
        }

        public async Task Create(BusinessAccount businessAccount)
        {
            if (businessAccount == null)
            {
                throw new ArgumentNullException(nameof(businessAccount));
            }

            _logger.Information($"Create the BusinessAccount in the store.");
            if (!await IsDuplicate(businessAccount.Id, businessAccount.BusinessAccountAddresses.FirstOrDefault().Email))
            {
                await Entity.AddAsync(businessAccount);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<BusinessAccount>> FindByName(string name)
        {
            _logger.Information($"Find the BusinessAccount by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()
            && w.BusinessType == Core.Enums.BusinessType.Customer
            ).ToListAsync();
        }

        public async Task<BusinessAccount> FindById(int id)
        {
            _logger.Information($"Find the BusinessAccount by id '{id}' from the storage.");
            return await NoTrackingEntity.Include(i => i.BusinessAccountAddresses)
                .SingleOrDefaultAsync(f => f.Id == id
                                           && f.BusinessType == Core.Enums.BusinessType.Customer);
        }

        public async Task<bool> IsDuplicate(int id, string email)
        {
            _logger.Information($"Ensure BusinessAccount is not duplicate by email '{email}'.");
            return await AddressNoTrackingEntity.AnyAsync(w => w.IsDelete == false && w.Email.ToLower() == email.ToLower());
        }

        public void Update(BusinessAccount businessAccount)
        {
            if (businessAccount == null)
            {
                throw new ArgumentNullException(nameof(businessAccount));
            }

            _logger.Information($"Update the BusinessAccount in the store.");
            Entity.Update(businessAccount);
        }
    }
}
