﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using YK.IMS.Core.Dto;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DataLayer.EfCode;

namespace YK.IMS.DbAccess.Users
{
    public class UserDbAccess : BaseDbAccess, IUserDbAccess
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _applicationDb;
        private readonly ILogger Logger;
        public UserDbAccess(DbContext context, IMapper mapper,
            UserManager<ApplicationUser> userManager,
            ApplicationDbContext applicationDb,
            ILogger logger)
            : base(context, mapper)
        {
            Logger = logger.ForContext<UserDbAccess>();
            _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
            _applicationDb = applicationDb ?? throw new ArgumentNullException(nameof(applicationDb));
        }

        public async Task<CreateUserResponse> Create(ApplicationUser applicationUser, string password)
        {
            Logger.Information($"Create the user in the store.");
            var identityResult = await _userManager.CreateAsync(applicationUser, password);

            if (!identityResult.Succeeded)
            {
                Logger.Information($"Could not store user.");
                return new CreateUserResponse(applicationUser.Id, false, identityResult.Errors.Select(e => new Error(e.Code, e.Description)));
            }

            Logger.Information($"Returing create user response.");
            return new CreateUserResponse(applicationUser.Id, identityResult.Succeeded, identityResult.Succeeded ? null : identityResult.Errors.Select(e => new Error(e.Code, e.Description)));
        }

        public async Task<ApplicationUser> FindByName(string userName)
        {
            Logger.Information($"Find the user by name from the storage.");
            return await _userManager.FindByNameAsync(userName);
        }

        public async Task<ApplicationUser> FindById(string id)
        {
            Logger.Information($"Find the user by id from the storage.");
            return await _applicationDb.Users.Include(i => i.RefreshTokens).FirstAsync(f => f.Id == id);
            //return await _userManager.FindByIdAsync(id);
        }

        public async Task<UserDto> FindByNameDto(string userName)
        {
            var appUser = await FindByName(userName);
            return null;
        }

        public async Task<bool> CheckPassword(ApplicationUser user, string password)
        {
            Logger.Information($"Ensure password is valid for the user.");
            return await _userManager.CheckPasswordAsync(user, password);
        }

        public async Task<IList<Claim>> GetClaimsAsync(ApplicationUser user)
        {
            Logger.Information($"{nameof(GetClaimsAsync)} invoked.");
            return await _userManager.GetClaimsAsync(user);
        }
    }
}
