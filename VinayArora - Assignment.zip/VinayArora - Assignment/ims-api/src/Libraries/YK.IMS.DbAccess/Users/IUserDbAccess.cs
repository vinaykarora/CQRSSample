﻿using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Users
{
    public interface IUserDbAccess
    {
        Task<CreateUserResponse> Create(ApplicationUser user, string password);
        Task<ApplicationUser> FindByName(string userName);
        Task<ApplicationUser> FindById(string id);
        Task<UserDto> FindByNameDto(string userName);
        Task<bool> CheckPassword(ApplicationUser user, string password);
        Task<IList<Claim>> GetClaimsAsync(ApplicationUser user);
    }
}
