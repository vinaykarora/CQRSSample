﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.ProductGroups
{
    public interface IProductGroupDbAccess
    {
        Task Create(ProductGroup productGroups);
        void Update(ProductGroup productGroups);
        Task<IEnumerable<ProductGroup>> FindByName(string name);
        Task<ProductGroup> FindById(int id);
        Task<bool> IsDuplicate(int id, string name, string code);

        IQueryable<ProductGroup> NoTrackingEntity { get; }
        DbSet<ProductGroup> Entity { get; }
    }
}
