﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.ProductGroups
{
    public class ProductGroupDbAccess : BaseDbAccess, IProductGroupDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<ProductGroup> NoTrackingEntity => Context.Set<ProductGroup>().AsNoTracking();

        public DbSet<ProductGroup> Entity => Context.Set<ProductGroup>();

        public ProductGroupDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<ProductGroupDbAccess>();
        }

        public async Task Create(ProductGroup productGroups)
        {
            if (productGroups == null)
            {
                throw new ArgumentNullException(nameof(productGroups));
            }

            _logger.Information($"Create the productGroups in the store.");
            if (!await IsDuplicate(productGroups.Id, productGroups.Name, productGroups.Code))
            {
                await Entity.AddAsync(productGroups);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<ProductGroup>> FindByName(string name)
        {
            _logger.Information($"Find the productGroups by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()).ToListAsync();
        }

        public async Task<ProductGroup> FindById(int id)
        {
            _logger.Information($"Find the productGroups by id '{id}' from the storage.");
            return await NoTrackingEntity.SingleOrDefaultAsync(f => f.Id == id);
        }

        public async Task<bool> IsDuplicate(int id, string name, string code)
        {
            _logger.Information($"Ensure productGroups is not duplicate by name '{name}' and code '{code}'.");
            return await NoTrackingEntity.AnyAsync(
                w => w.IsDelete == false && w.Id != id
                && (w.Name.ToLower() == name.ToLower() || w.Code.ToLower() == code.ToLower()));
        }

        public void Update(ProductGroup productGroups)
        {
            if (productGroups == null)
            {
                throw new ArgumentNullException(nameof(productGroups));
            }

            _logger.Information($"Update the productGroups in the store.");
            if (!IsDuplicate(productGroups.Id, productGroups.Name, productGroups.Code).GetAwaiter().GetResult())
            {
                Entity.Update(productGroups);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }
    }
}
