﻿using YK.IMS.DataLayer.Dtos;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.SaleOrders
{
    public interface IPlaceSaleOrderDbAccess
    {
        OrderProductsDto BuildProductsDto(int productId, byte numProducts);

        void Add(SaleOrder newSaleOrder);
    }
}
