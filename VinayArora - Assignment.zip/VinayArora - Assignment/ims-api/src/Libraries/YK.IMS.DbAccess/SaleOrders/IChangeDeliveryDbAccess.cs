﻿using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.SaleOrders
{
    public interface IChangeDeliveryDbAccess
    {
        SaleOrder GetSaleOrder(int saleOrderId);
    }
}
