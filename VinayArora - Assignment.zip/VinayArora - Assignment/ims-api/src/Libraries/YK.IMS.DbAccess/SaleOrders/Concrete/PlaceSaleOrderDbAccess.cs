﻿using AutoMapper;
using Serilog;
using YK.IMS.DataLayer.Dtos;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DataLayer.EfCode;

namespace YK.IMS.DbAccess.SaleOrders
{
    public class PlaceSaleOrderDbAccess : BaseDbAccess, IPlaceSaleOrderDbAccess
    {
        private readonly ILogger _logger;
        public PlaceSaleOrderDbAccess(IMSContext context, IMapper mapper, ILogger logger) : base(context, mapper)
        {
            _logger = logger.ForContext<PlaceSaleOrderDbAccess>();
        }

        public void Add(SaleOrder newSaleOrder)
        {
            Context.Add(newSaleOrder);
        }

        public OrderProductsDto BuildProductsDto(int productId, byte numProducts)
        {
            return new OrderProductsDto(productId, Context.Find<Product>(productId), numProducts);
        }
    }
}
