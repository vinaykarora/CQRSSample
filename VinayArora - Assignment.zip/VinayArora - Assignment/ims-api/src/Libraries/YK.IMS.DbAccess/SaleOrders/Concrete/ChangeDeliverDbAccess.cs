﻿using AutoMapper;
using Serilog;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DataLayer.EfCode;

namespace YK.IMS.DbAccess.SaleOrders
{
    public class ChangeDeliverDbAccess : BaseDbAccess, IChangeDeliveryDbAccess
    {
        private readonly ILogger _logger;
        public ChangeDeliverDbAccess(IMSContext context, IMapper mapper, ILogger logger) : base(context, mapper)
        {
            _logger = logger.ForContext<ChangeDeliverDbAccess>();
        }

        public SaleOrder GetSaleOrder(int saleOrderId)
        {
            return Context.Find<SaleOrder>(saleOrderId);
        }
    }
}
