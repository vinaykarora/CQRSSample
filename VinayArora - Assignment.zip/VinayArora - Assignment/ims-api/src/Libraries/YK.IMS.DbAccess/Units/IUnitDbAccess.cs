﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Units
{
    public interface IUnitDbAccess
    {
        Task Create(Unit unit);
        void Update(Unit unit);
        Task<IEnumerable<Unit>> FindByName(string name);
        Task<Unit> FindById(int id);
        Task<bool> IsDuplicate(int id, string name, string code);

        IQueryable<Unit> NoTrackingEntity { get; }
        DbSet<Unit> Entity { get; }
    }
}
