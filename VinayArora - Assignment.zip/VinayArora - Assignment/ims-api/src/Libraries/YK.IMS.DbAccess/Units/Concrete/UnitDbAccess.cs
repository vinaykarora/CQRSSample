﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Units
{
    public class UnitDbAccess : BaseDbAccess, IUnitDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<Unit> NoTrackingEntity => Context.Set<Unit>().AsNoTracking();

        public DbSet<Unit> Entity => Context.Set<Unit>();

        public UnitDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<UnitDbAccess>();
        }

        public async Task Create(Unit unit)
        {
            if (unit == null)
            {
                throw new ArgumentNullException(nameof(unit));
            }

            _logger.Information($"Create the unit in the store.");
            if (!await IsDuplicate(unit.Id, unit.Name, unit.Code))
            {
                await Entity.AddAsync(unit);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<Unit>> FindByName(string name)
        {
            _logger.Information($"Find the unit by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()).ToListAsync();
        }

        public async Task<Unit> FindById(int id)
        {
            _logger.Information($"Find the unit by id '{id}' from the storage.");
            return await NoTrackingEntity.SingleOrDefaultAsync(f => f.Id == id);
        }

        public async Task<bool> IsDuplicate(int id, string name, string code)
        {
            _logger.Information($"Ensure unit is not duplicate by name '{name}' and code '{code}'.");
            return await NoTrackingEntity.AnyAsync(
                w => w.IsDelete == false && w.Id != id
                && (w.Name.ToLower() == name.ToLower() || w.Code.ToLower() == code.ToLower()));
        }

        public void Update(Unit unit)
        {
            if (unit == null)
            {
                throw new ArgumentNullException(nameof(unit));
            }

            _logger.Information($"Update the unit in the store.");
            if (!IsDuplicate(unit.Id, unit.Name, unit.Code).GetAwaiter().GetResult())
            {
                Entity.Update(unit);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }
    }
}
