﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Colors
{
    public class ColorDbAccess : BaseDbAccess, IColorDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<Color> NoTrackingEntity => Context.Set<Color>().AsNoTracking();

        public DbSet<Color> Entity => Context.Set<Color>();

        public ColorDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<ColorDbAccess>();
        }

        public async Task Create(Color color)
        {
            if (color == null)
            {
                throw new ArgumentNullException(nameof(color));
            }

            _logger.Information($"Create the color in the store.");
            if (!await IsDuplicate(color.Id, color.Name, color.Code))
            {
                await Entity.AddAsync(color);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<Color>> FindByName(string name)
        {
            _logger.Information($"Find the color by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()).ToListAsync();
        }

        public async Task<Color> FindById(int id)
        {
            _logger.Information($"Find the color by id '{id}' from the storage.");
            return await NoTrackingEntity.SingleOrDefaultAsync(f => f.Id == id);
        }

        public async Task<bool> IsDuplicate(int id, string name, string code)
        {
            _logger.Information($"Ensure color is not duplicate by name '{name}' and code '{code}'.");
            return await NoTrackingEntity.AnyAsync(
                w => w.IsDelete == false && w.Id != id
                && (w.Name.ToLower() == name.ToLower() || w.Code.ToLower() == code.ToLower()));
        }

        public void Update(Color color)
        {
            if (color == null)
            {
                throw new ArgumentNullException(nameof(color));
            }

            _logger.Information($"Update the color in the store.");
            if (!IsDuplicate(color.Id, color.Name, color.Code).GetAwaiter().GetResult())
            {
                Entity.Update(color);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }
    }
}
