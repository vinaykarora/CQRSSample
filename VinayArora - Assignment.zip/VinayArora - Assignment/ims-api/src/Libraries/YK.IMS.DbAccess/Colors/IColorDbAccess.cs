﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Colors
{
    public interface IColorDbAccess
    {
        Task Create(Color color);
        void Update(Color color);
        Task<IEnumerable<Color>> FindByName(string name);
        Task<Color> FindById(int id);
        Task<bool> IsDuplicate(int id, string name, string code);

        IQueryable<Color> NoTrackingEntity { get; }
        DbSet<Color> Entity { get; }
    }
}
