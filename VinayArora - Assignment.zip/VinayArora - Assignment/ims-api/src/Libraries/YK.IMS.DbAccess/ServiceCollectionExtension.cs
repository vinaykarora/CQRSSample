﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using YK.IMS.DbAccess.Colors;
using YK.IMS.DbAccess.Customers;
using YK.IMS.DbAccess.Makes;
using YK.IMS.DbAccess.MaterialTypes;
using YK.IMS.DbAccess.Models;
using YK.IMS.DbAccess.PackSizes;
using YK.IMS.DbAccess.ProductGroups;
using YK.IMS.DbAccess.Products;
using YK.IMS.DbAccess.Sizes;
using YK.IMS.DbAccess.Styles;
using YK.IMS.DbAccess.Units;
using YK.IMS.DbAccess.Users;

namespace YK.IMS.DbAccess
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection ConfigureDbAccess(this IServiceCollection services, ILogger logger)
        {
            logger.Information("Db access services registration started.");
            services.AddScoped<IUserDbAccess, UserDbAccess>();
            services.AddScoped<IColorDbAccess, ColorDbAccess>();
            services.AddScoped<IMakeDbAccess, MakeDbAccess>();
            services.AddScoped<IMaterialTypeDbAccess, MaterialTypeDbAccess>();
            services.AddScoped<IModelDbAccess, ModelDbAccess>();
            services.AddScoped<IPackSizeDbAccess, PackSizeDbAccess>();
            services.AddScoped<IProductGroupDbAccess, ProductGroupDbAccess>();
            services.AddScoped<IProductDbAccess, ProductDbAccess>();
            services.AddScoped<ISizeDbAccess, SizeDbAccess>();
            services.AddScoped<IStyleDbAccess, StyleDbAccess>();
            services.AddScoped<IUnitDbAccess, UnitDbAccess>();
            services.AddScoped<ICustomerDbAccess, CustomerDbAccess>();

            return services;
        }
    }
}
