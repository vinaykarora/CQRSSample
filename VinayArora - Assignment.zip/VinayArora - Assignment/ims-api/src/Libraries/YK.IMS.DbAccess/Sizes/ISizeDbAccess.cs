﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Sizes
{
    public interface ISizeDbAccess
    {
        Task Create(Size size);
        void Update(Size size);
        Task<IEnumerable<Size>> FindByName(string name);
        Task<Size> FindById(int id);
        Task<bool> IsDuplicate(int id, string name, string code);

        IQueryable<Size> NoTrackingEntity { get; }
        DbSet<Size> Entity { get; }
    }
}
