﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Sizes
{
    public class SizeDbAccess : BaseDbAccess, ISizeDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<Size> NoTrackingEntity => Context.Set<Size>().AsNoTracking();

        public DbSet<Size> Entity => Context.Set<Size>();

        public SizeDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<SizeDbAccess>();
        }

        public async Task Create(Size size)
        {
            if (size == null)
            {
                throw new ArgumentNullException(nameof(size));
            }

            _logger.Information($"Create the size in the store.");
            if (!await IsDuplicate(size.Id, size.Name, size.Code))
            {
                await Entity.AddAsync(size);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<Size>> FindByName(string name)
        {
            _logger.Information($"Find the size by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()).ToListAsync();
        }

        public async Task<Size> FindById(int id)
        {
            _logger.Information($"Find the size by id '{id}' from the storage.");
            return await NoTrackingEntity.SingleOrDefaultAsync(f => f.Id == id);
        }

        public async Task<bool> IsDuplicate(int id, string name, string code)
        {
            _logger.Information($"Ensure size is not duplicate by name '{name}' and code '{code}'.");
            return await NoTrackingEntity.AnyAsync(
                w => w.IsDelete == false && w.Id != id
                && (w.Name.ToLower() == name.ToLower() || w.Code.ToLower() == code.ToLower()));
        }

        public void Update(Size size)
        {
            if (size == null)
            {
                throw new ArgumentNullException(nameof(size));
            }

            _logger.Information($"Update the size in the store.");
            if (!IsDuplicate(size.Id, size.Name, size.Code).GetAwaiter().GetResult())
            {
                Entity.Update(size);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }
    }
}
