﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.MaterialTypes
{
    public class MaterialTypeDbAccess : BaseDbAccess, IMaterialTypeDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<MaterialType> NoTrackingEntity => Context.Set<MaterialType>().AsNoTracking();

        public DbSet<MaterialType> Entity => Context.Set<MaterialType>();

        public MaterialTypeDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<MaterialTypeDbAccess>();
        }

        public async Task Create(MaterialType materialType)
        {
            if (materialType == null)
            {
                throw new ArgumentNullException(nameof(materialType));
            }

            _logger.Information($"Create the materialType in the store.");
            if (!await IsDuplicate(materialType.Id, materialType.Name, materialType.Code))
            {
                await Entity.AddAsync(materialType);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<MaterialType>> FindByName(string name)
        {
            _logger.Information($"Find the materialType by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()).ToListAsync();
        }

        public async Task<MaterialType> FindById(int id)
        {
            _logger.Information($"Find the materialType by id '{id}' from the storage.");
            return await NoTrackingEntity.SingleOrDefaultAsync(f => f.Id == id);
        }

        public async Task<bool> IsDuplicate(int id, string name, string code)
        {
            _logger.Information($"Ensure materialType is not duplicate by name '{name}' and code '{code}'.");
            return await NoTrackingEntity.AnyAsync(
                w => w.IsDelete == false && w.Id != id
                && (w.Name.ToLower() == name.ToLower() || w.Code.ToLower() == code.ToLower()));
        }

        public void Update(MaterialType materialType)
        {
            if (materialType == null)
            {
                throw new ArgumentNullException(nameof(materialType));
            }

            _logger.Information($"Update the materialType in the store.");
            if (!IsDuplicate(materialType.Id, materialType.Name, materialType.Code).GetAwaiter().GetResult())
            {
                Entity.Update(materialType);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }
    }
}
