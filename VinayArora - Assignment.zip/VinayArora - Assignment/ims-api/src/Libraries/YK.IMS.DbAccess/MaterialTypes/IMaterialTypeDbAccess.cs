﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.MaterialTypes
{
    public interface IMaterialTypeDbAccess
    {
        Task Create(MaterialType materialType);
        void Update(MaterialType materialType);
        Task<IEnumerable<MaterialType>> FindByName(string name);
        Task<MaterialType> FindById(int id);
        Task<bool> IsDuplicate(int id, string name, string code);

        IQueryable<MaterialType> NoTrackingEntity { get; }
        DbSet<MaterialType> Entity { get; }
    }
}
