﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Models
{
    public class ModelDbAccess : BaseDbAccess, IModelDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<Model> NoTrackingEntity => Context.Set<Model>().AsNoTracking();

        public DbSet<Model> Entity => Context.Set<Model>();

        public ModelDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<ModelDbAccess>();
        }

        public async Task Create(Model model)
        {
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }

            _logger.Information($"Create the model in the store.");
            if (!await IsDuplicate(model.Id, model.Name, model.Code))
            {
                await Entity.AddAsync(model);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<Model>> FindByName(string name)
        {
            _logger.Information($"Find the model by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()).ToListAsync();
        }

        public async Task<Model> FindById(int id)
        {
            _logger.Information($"Find the model by id '{id}' from the storage.");
            return await NoTrackingEntity.SingleOrDefaultAsync(f => f.Id == id);
        }

        public async Task<bool> IsDuplicate(int id, string name, string code)
        {
            _logger.Information($"Ensure model is not duplicate by name '{name}' and code '{code}'.");
            return await NoTrackingEntity.AnyAsync(
                w => w.IsDelete == false && w.Id != id
                && (w.Name.ToLower() == name.ToLower() || w.Code.ToLower() == code.ToLower()));
        }

        public void Update(Model model)
        {
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }

            _logger.Information($"Update the model in the store.");
            if (!IsDuplicate(model.Id, model.Name, model.Code).GetAwaiter().GetResult())
            {
                Entity.Update(model);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }
    }
}
