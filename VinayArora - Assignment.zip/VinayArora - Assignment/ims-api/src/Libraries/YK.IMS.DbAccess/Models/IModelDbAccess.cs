﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.Models
{
    public interface IModelDbAccess
    {
        Task Create(Model model);
        void Update(Model model);
        Task<IEnumerable<Model>> FindByName(string name);
        Task<Model> FindById(int id);
        Task<bool> IsDuplicate(int id, string name, string code);

        IQueryable<Model> NoTrackingEntity { get; }
        DbSet<Model> Entity { get; }
    }
}
