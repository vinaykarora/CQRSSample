﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.PackSizes
{
    public class PackSizeDbAccess : BaseDbAccess, IPackSizeDbAccess
    {
        private readonly ILogger _logger;

        public IQueryable<PackSize> NoTrackingEntity => Context.Set<PackSize>().AsNoTracking();

        public DbSet<PackSize> Entity => Context.Set<PackSize>();

        public PackSizeDbAccess(DbContext dbContext, IMapper mapper, ILogger logger)
            : base(dbContext, mapper)
        {
            _logger = logger.ForContext<PackSizeDbAccess>();
        }

        public async Task Create(PackSize packSizes)
        {
            if (packSizes == null)
            {
                throw new ArgumentNullException(nameof(packSizes));
            }

            _logger.Information($"Create the packSizes in the store.");
            if (!await IsDuplicate(packSizes.Id, packSizes.Name, packSizes.Code))
            {
                await Entity.AddAsync(packSizes);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }

        public async Task<IEnumerable<PackSize>> FindByName(string name)
        {
            _logger.Information($"Find the packSizes by name '{name}' from the storage.");
            return await NoTrackingEntity.Where(w => w.Name.ToLower() == name.ToLower()).ToListAsync();
        }

        public async Task<PackSize> FindById(int id)
        {
            _logger.Information($"Find the packSizes by id '{id}' from the storage.");
            return await NoTrackingEntity.SingleOrDefaultAsync(f => f.Id == id);
        }

        public async Task<bool> IsDuplicate(int id, string name, string code)
        {
            _logger.Information($"Ensure packSizes is not duplicate by name '{name}' and code '{code}'.");
            return await NoTrackingEntity.AnyAsync(
                w => w.IsDelete == false && w.Id != id
                && (w.Name.ToLower() == name.ToLower() || w.Code.ToLower() == code.ToLower()));
        }

        public void Update(PackSize packSizes)
        {
            if (packSizes == null)
            {
                throw new ArgumentNullException(nameof(packSizes));
            }

            _logger.Information($"Update the packSizes in the store.");
            if (!IsDuplicate(packSizes.Id, packSizes.Name, packSizes.Code).GetAwaiter().GetResult())
            {
                Entity.Update(packSizes);
            }
            else
            {
                _logger.Warning($"Duplicate record found.");
            }
        }
    }
}
