﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.DbAccess.PackSizes
{
    public interface IPackSizeDbAccess
    {
        Task Create(PackSize packSizes);
        void Update(PackSize packSizes);
        Task<IEnumerable<PackSize>> FindByName(string name);
        Task<PackSize> FindById(int id);
        Task<bool> IsDuplicate(int id, string name, string code);

        IQueryable<PackSize> NoTrackingEntity { get; }
        DbSet<PackSize> Entity { get; }
    }
}
