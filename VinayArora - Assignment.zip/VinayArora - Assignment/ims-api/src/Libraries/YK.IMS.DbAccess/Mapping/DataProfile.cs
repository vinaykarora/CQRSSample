﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Users;

namespace YK.IMS.DbAccess.Mapping
{
    public class DataProfile : Profile
    {
        public DataProfile()
        {
            //CreateMap<UserDto, ApplicationUser>()
            //    .ConstructUsing(u => new ApplicationUser(u.CompanyId, u.Name, u.Code, u.Description, u.CreatedBy) { UserName = u.Email, Email = u.Email })
            //    .ForMember(au => au.Id, opt => opt.Ignore());
            //CreateMap<ApplicationUser, UserDto>()
            //    .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.Email))
            //    .ForAllOtherMembers(opt => opt.Ignore());
        }
    }
}
