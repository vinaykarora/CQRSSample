﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;


namespace YK.IMS.Service.ProductGroups
{
    public class ListProductGroupHandler : IListProductGroupHandler
    {
        private readonly IMSContext _context;
        private readonly ILogger _logger;
        public ListProductGroupHandler(IMSContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<ProductGroupDropdownResponse>> Handle(DropdownProductGroupQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get productGroup(s) dropdown.");
            return await _context.ProductGroup
                  .AsNoTracking()
                  .FilterProductGroupsBy(request.FilterBy)
                  .OrderProductGroupsDropdownBy(request.OrderByOptions, request.SortOrder)
                  .MapProductGroupToDropdown()
                  .ToListAsync();
        }

        public async Task<IEnumerable<ProductGroupListResponse>> Handle(ListProductGroupQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get productGroup(s) list.");

            IQueryable<ProductGroupListResponse> productGroupsQuery = _context.ProductGroup
                .AsNoTracking()
                .FilterProductGroupsBy(request.FilterBy)
                .OrderProductGroupsBy(request.OrderByOptions, request.SortOrder)
                .MapProductGroupToResponse();

            await request.SetupRestOfDto(productGroupsQuery);

            return productGroupsQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<ProductGroupListResponse> Handle(SingleProductGroupQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get ProductGroup.");

            return await _context.ProductGroup
                .AsNoTracking()
                .FilterProductGroupsBy(request.FilterBy)
                .MapProductGroupToResponse()
                .FirstOrDefaultAsync();
        }
    }
}