﻿using MediatR;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DbAccess.ProductGroups;

namespace YK.IMS.Service.ProductGroups
{
    public class ProductGroupCreatedHandler : INotificationHandler<ProductGroupCreatedEvent>
    {
        private readonly IProductGroupDbAccess _dbAccess;
        private readonly ILogger _logger;

        public ProductGroupCreatedHandler(ILogger logger, IProductGroupDbAccess dbAccess)
        {
            _logger = logger.ForContext<ProductGroupCreatedHandler>();
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task Handle(ProductGroupCreatedEvent notification, CancellationToken cancellationToken)
        {
            var productGroup = await _dbAccess.FindById(notification.ProductGroupId);

            if (productGroup == null)
            {
                //TODO: Handle next business logic if customer is not found
                _logger.Warning("ProductGroup is not found by customer id from publisher");
            }
            else
            {
                _logger.Information($"ProductGroup has found by productGroup id: {notification.ProductGroupId} from publisher");
            }
        }
    }
}
