﻿namespace YK.IMS.Service.ProductGroups
{
    public class UpdateProductGroupResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
