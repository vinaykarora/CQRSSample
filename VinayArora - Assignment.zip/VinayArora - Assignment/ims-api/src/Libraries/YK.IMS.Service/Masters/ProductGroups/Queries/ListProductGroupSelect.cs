﻿using System.Linq;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.ProductGroups
{
    public static class ListProductGroupSelect
    {
        public static IQueryable<ProductGroupListResponse> MapProductGroupToResponse(this IQueryable<ProductGroup> productGroups)
        {
            return productGroups.Select(p =>
                    new ProductGroupListResponse
                    (
                        p.Id,
                        p.CompanyId,
                        p.Name,
                        p.Code,
                        p.Description,
                        p.IsActive,
                        p.IsDelete,
                        p.CreatedAt,
                        p.CreatedBy,
                        string.Empty,
                        p.LastUpdatedAt,
                        p.LastUpdatedBy,
                        string.Empty
                    )
                );
        }

        public static IQueryable<ProductGroupDropdownResponse> MapProductGroupToDropdown(this IQueryable<ProductGroup> productGroups)
        {
            return productGroups.Select(p => new ProductGroupDropdownResponse(p.Id, p.Name));
        }
    }
}