﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.ProductGroups;

namespace YK.IMS.Service.ProductGroups
{
    public class ChangeNameHandler : StatusGenericHandler, IChangeNameHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly IProductGroupDbAccess _dbAccess;

        public ChangeNameHandler(DbContext dbContext, ILogger logger, IProductGroupDbAccess dbAccess)
        {
            _logger = logger.ForContext<ChangeNameHandler>();
            _context = dbContext ?? throw new ArgumentNullException(nameof(dbContext)); ;
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper> Handle(ChangeNameCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");
            if (request == null)
            {
                _logger.Error($"'Null or invalid object '{nameof(request)}' found.");
                throw new ArgumentNullException(nameof(request));
            }

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid productGroup {nameof(request.Id)} '{request.Id}'");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            if (string.IsNullOrEmpty(request.Name))
            {
                _logger.Error($"Null or empty {nameof(request.Name)} '{request.Name}' is invalid.");
                AddError("Name Is Required", nameof(request.Name));
            }

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                _logger.Information($"Validation failed for '{nameof(ProductGroup)}' entity object.");
                return new ServiceResponseWrapper(this);
            }

            _logger.Debug($"Find productGroup '{request.Id}'.");
            ProductGroup productGroupToUpdate = await _dbAccess.FindById(request.Id);
            if (productGroupToUpdate == null)
            {
                _logger.Error($"Sorry, I could not find the productGroup '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the productGroup you were looking for.");
                return new ServiceResponseWrapper(this);
            }

            if (await _dbAccess.IsDuplicate(productGroupToUpdate.Id, request.Name, productGroupToUpdate.Code))
            {
                _logger.Error($"Duplicate entry found for '{request.Name}'.");
                AddError("Duplicate entry found.", nameof(request.Name));
                return new ServiceResponseWrapper(this);
            }

            CombineErrors(productGroupToUpdate.ChangeName(request.Name));

            if (!HasErrors)
            {
                _logger.Information($"Update productGroup entity.");
                _dbAccess.Update(productGroupToUpdate);
                await _context.SaveChangesAsync();
                Message = $"Successfully update the ProductGroup '{request.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(ProductGroup)}' entity object.");
            }

            return new ServiceResponseWrapper(this);
        }
    }
}
