﻿namespace YK.IMS.Service.ProductGroups
{
    public interface IProductGroupDxos
    {
        CreateProductGroupResponse MapCreateProductGroupResponse(DataLayer.EfClasses.ProductGroup productGroup);
    }
}
