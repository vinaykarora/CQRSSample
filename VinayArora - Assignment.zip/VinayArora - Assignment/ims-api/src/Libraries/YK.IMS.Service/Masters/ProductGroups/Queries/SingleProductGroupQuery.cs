﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.ProductGroups
{
    public class SingleProductGroupQuery : QueryBase<ProductGroupListResponse>
    {
        public SingleProductGroupQuery(ListProductGroupFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListProductGroupFilterBy FilterBy { get; }
    }
}