﻿using System;
using System.Linq;
using YK.IMS.Core.Helpers;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.ProductGroups
{
    public static class ListProductGroupSort
    {
        public static IQueryable<ProductGroup> OrderProductGroupsBy(this IQueryable<ProductGroup> productGroups, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.Id); }
                    else { return productGroups.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.Name); }
                    else { return productGroups.OrderBy(x => x.Name); }
                case Constants.Strings.OrderByOptions.CREATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.CreatedAt); }
                    else { return productGroups.OrderBy(x => x.CreatedAt); }
                case Constants.Strings.OrderByOptions.CODE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.Code); }
                    else { return productGroups.OrderBy(x => x.Code); }
                case Constants.Strings.OrderByOptions.DESCRIPTION:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.Description); }
                    else { return productGroups.OrderBy(x => x.Description); }
                case Constants.Strings.OrderByOptions.CREATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.CreatedBy); }
                    else { return productGroups.OrderBy(x => x.CreatedBy); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.LastUpdatedAt); }
                    else { return productGroups.OrderBy(x => x.LastUpdatedAt); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.LastUpdatedBy); }
                    else { return productGroups.OrderBy(x => x.LastUpdatedBy); }
                case Constants.Strings.OrderByOptions.ACTIVE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.IsActive); }
                    else { return productGroups.OrderBy(x => x.IsActive); }
                case Constants.Strings.OrderByOptions.DELETED:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.IsDelete); }
                    else { return productGroups.OrderBy(x => x.IsDelete); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }

        public static IQueryable<ProductGroup> OrderProductGroupsDropdownBy(this IQueryable<ProductGroup> productGroups, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.Id); }
                    else { return productGroups.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return productGroups.OrderByDescending(x => x.Name); }
                    else { return productGroups.OrderBy(x => x.Name); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }
    }
}