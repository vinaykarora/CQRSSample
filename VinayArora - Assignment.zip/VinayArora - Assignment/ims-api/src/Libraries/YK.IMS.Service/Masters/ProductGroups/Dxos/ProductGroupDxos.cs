﻿using AutoMapper;

namespace YK.IMS.Service.ProductGroups
{
    public class ProductGroupDxos : IProductGroupDxos
    {
        private readonly IMapper _mapper;

        public ProductGroupDxos()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<DataLayer.EfClasses.ProductGroup, CreateProductGroupResponse>()
                    .ForMember(dst => dst.Id, opt => opt.MapFrom(src => src.Id))
                    .ForMember(dst => dst.Name, opt => opt.MapFrom(src => src.Name));
            });

            _mapper = config.CreateMapper();
        }

        public CreateProductGroupResponse MapCreateProductGroupResponse(DataLayer.EfClasses.ProductGroup productGroup)
        {
            if (productGroup == null)
                return null;

            return _mapper.Map<DataLayer.EfClasses.ProductGroup, CreateProductGroupResponse>(productGroup);
        }
    }
}
