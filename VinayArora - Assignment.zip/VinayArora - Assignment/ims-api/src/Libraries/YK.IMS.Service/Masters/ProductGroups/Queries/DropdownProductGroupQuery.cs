﻿using System.Collections.Generic;
using YK.IMS.Core.Queries;

namespace YK.IMS.Service.ProductGroups
{
    public class DropdownProductGroupQuery : QueryBase<IEnumerable<ProductGroupDropdownResponse>>
    {
        public ListProductGroupFilterBy FilterBy { get; set; }
    }
}