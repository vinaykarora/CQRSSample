﻿using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.ProductGroups
{
    public class DeleteProductGroupCommand : CommandBase<ServiceResponseWrapper>
    {
        public DeleteProductGroupCommand(int id)
        {
            Id = id;
        }

        public int Id { get;  }
    }
}
