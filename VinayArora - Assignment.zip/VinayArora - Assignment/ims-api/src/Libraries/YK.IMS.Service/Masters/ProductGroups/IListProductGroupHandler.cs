﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.ProductGroups
{
    public interface IListProductGroupHandler : IRequestHandler<ListProductGroupQuery, IEnumerable<ProductGroupListResponse>>, 
        IRequestHandler<DropdownProductGroupQuery, IEnumerable<ProductGroupDropdownResponse>>,
        IRequestHandler<SingleProductGroupQuery, ProductGroupListResponse>
    {
    }
}
