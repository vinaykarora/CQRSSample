﻿using MediatR;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.ProductGroups
{
    public interface IDeleteProductGroupHandler :  IRequestHandler<DeleteProductGroupCommand, ServiceResponseWrapper> { }
}
