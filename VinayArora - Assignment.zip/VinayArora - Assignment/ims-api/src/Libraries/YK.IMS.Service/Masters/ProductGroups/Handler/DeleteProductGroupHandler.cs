﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.ProductGroups;

namespace YK.IMS.Service.ProductGroups
{
    public class DeleteProductGroupHandler : StatusGenericHandler, IDeleteProductGroupHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly IProductGroupDbAccess _dbAccess;

        public DeleteProductGroupHandler(DbContext context, ILogger logger, IProductGroupDbAccess dbAccess)
        {
            _logger = logger.ForContext<DeleteProductGroupHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper> Handle(DeleteProductGroupCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid productGroup id '{request.Id}'.");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            _logger.Debug($"Deleting existing productGroup '{request.Id}'.");

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                return new ServiceResponseWrapper(this);
            }

            _logger.Debug($"Find productGroup '{request.Id}'.");

            ProductGroup productGroupToDelete = await _dbAccess.FindById(request.Id);
            if (productGroupToDelete == null)
            {
                _logger.Error($"Sorry, I could not find the productGroup '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the productGroup you were looking for.");
            }

            if (!HasErrors)
            {
                _logger.Information($"Delete productGroup entity.");
                productGroupToDelete.Delete();
                _dbAccess.Update(productGroupToDelete);
                await _context.SaveChangesAsync();
                Message = $"Successfully delete the ProductGroup '{productGroupToDelete.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(ProductGroup)}' entity object.");
            }

            return new ServiceResponseWrapper(this);
        }
    }
}
