﻿using MediatR;

namespace YK.IMS.Service.ProductGroups
{
    public class ProductGroupCreatedEvent : INotification
    {
        public int ProductGroupId { get; }

        public ProductGroupCreatedEvent(int productGroupId)
        {
            ProductGroupId = productGroupId;
        }
    }
}
