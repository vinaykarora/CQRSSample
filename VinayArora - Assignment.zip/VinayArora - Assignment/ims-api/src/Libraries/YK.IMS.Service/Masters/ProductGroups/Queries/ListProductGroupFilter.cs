﻿using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.ProductGroups
{
    public class ListProductGroupFilterBy : FilterByBase
    {

    }

    public static class ListProductGroupFilter
    {
        public static IQueryable<ProductGroup> FilterProductGroupsBy(this IQueryable<ProductGroup> productGroups, ListProductGroupFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return productGroups;
            }

            if (filterBy.Id > 0) { productGroups = productGroups.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { productGroups = productGroups.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                productGroups = productGroups.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { productGroups = productGroups.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { productGroups = productGroups.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            productGroups = productGroups.Where(x => x.IsActive == filterBy.IsActive);
            productGroups = productGroups.Where(x => x.IsDelete == filterBy.IsDelete);
            return productGroups;
        }

    }
}