﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.Core.Queries;

namespace YK.IMS.Service.ProductGroups
{
    public class ListProductGroupQuery : QueryBase<IEnumerable<ProductGroupListResponse>>
    {
        public ListProductGroupFilterBy FilterBy { get; set; }

        public override async Task SetupRestOfDto<T>(IQueryable<T> query)
        {
            await base.SetupRestOfDto(query);
            string newCheckState = GenerateCheckState();
            //if (PrevCheckState != newCheckState)
            //{
            //    PageNum = 1;
            //}

            PrevCheckState = newCheckState;
        }

        /// <summary>
        /// This returns a string containing the state of the SortFilterPage data
        /// that, if they change, should cause the PageNum to be set back to 0
        /// </summary>
        /// <returns></returns>
        private string GenerateCheckState()
        {
            return $"{FilterBy?.GetHashCode().ToString()},{PageSize},{NumPages}";
        }
    }
}