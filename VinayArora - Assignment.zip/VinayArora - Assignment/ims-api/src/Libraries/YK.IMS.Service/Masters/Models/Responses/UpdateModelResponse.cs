﻿namespace YK.IMS.Service.Models
{
    public class UpdateModelResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
