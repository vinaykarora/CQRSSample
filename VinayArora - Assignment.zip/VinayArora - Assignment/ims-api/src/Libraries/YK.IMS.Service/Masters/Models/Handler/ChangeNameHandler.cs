﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Models;

namespace YK.IMS.Service.Models
{
    public class ChangeNameHandler : StatusGenericHandler, IChangeNameHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly IModelDbAccess _dbAccess;

        public ChangeNameHandler(DbContext dbContext, ILogger logger, IModelDbAccess dbAccess)
        {
            _logger = logger.ForContext<ChangeNameHandler>();
            _context = dbContext ?? throw new ArgumentNullException(nameof(dbContext)); ;
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper> Handle(ChangeNameCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");
            if (request == null)
            {
                _logger.Error($"'Null or invalid object '{nameof(request)}' found.");
                throw new ArgumentNullException(nameof(request));
            }

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid model {nameof(request.Id)} '{request.Id}'");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            if (string.IsNullOrEmpty(request.Name))
            {
                _logger.Error($"Null or empty {nameof(request.Name)} '{request.Name}' is invalid.");
                AddError("Name Is Required", nameof(request.Name));
            }

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                _logger.Information($"Validation failed for '{nameof(Model)}' entity object.");
                return new ServiceResponseWrapper(this);
            }

            _logger.Debug($"Find model '{request.Id}'.");
            Model modelToUpdate = await _dbAccess.FindById(request.Id);
            if (modelToUpdate == null)
            {
                _logger.Error($"Sorry, I could not find the model '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the model you were looking for.");
                return new ServiceResponseWrapper(this);
            }

            if (await _dbAccess.IsDuplicate(modelToUpdate.Id, request.Name, modelToUpdate.Code))
            {
                _logger.Error($"Duplicate entry found for '{request.Name}'.");
                AddError("Duplicate entry found.", nameof(request.Name));
                return new ServiceResponseWrapper(this);
            }

            CombineErrors(modelToUpdate.ChangeName(request.Name));

            if (!HasErrors)
            {
                _logger.Information($"Update model entity.");
                _dbAccess.Update(modelToUpdate);
                await _context.SaveChangesAsync();
                Message = $"Successfully update the Model '{request.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(Model)}' entity object.");
            }

            return new ServiceResponseWrapper(this);
        }
    }
}
