﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;


namespace YK.IMS.Service.Models
{
    public class ListModelHandler : IListModelHandler
    {
        private readonly IMSContext _context;
        private readonly ILogger _logger;
        public ListModelHandler(IMSContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<ModelDropdownResponse>> Handle(DropdownModelQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get model(s) dropdown.");
            return await _context.Models
                  .AsNoTracking()
                  .FilterModelsBy(request.FilterBy)
                  .OrderModelsDropdownBy(request.OrderByOptions, request.SortOrder)
                  .MapModelToDropdown()
                  .ToListAsync();
        }

        public async Task<IEnumerable<ModelListResponse>> Handle(ListModelQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get model(s) list.");

            IQueryable<ModelListResponse> modelsQuery = _context.Models
                .AsNoTracking()
                .FilterModelsBy(request.FilterBy)
                .OrderModelsBy(request.OrderByOptions, request.SortOrder)
                .MapModelToResponse();

            await request.SetupRestOfDto(modelsQuery);

            return modelsQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<ModelListResponse> Handle(SingleModelQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get Model.");

            return await _context.Models
                .AsNoTracking()
                .FilterModelsBy(request.FilterBy)
                .MapModelToResponse()
                .FirstOrDefaultAsync();
        }
    }
}