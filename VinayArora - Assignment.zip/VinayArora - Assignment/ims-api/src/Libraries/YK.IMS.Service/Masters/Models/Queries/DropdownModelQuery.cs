﻿using System.Collections.Generic;
using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Models
{
    public class DropdownModelQuery : QueryBase<IEnumerable<ModelDropdownResponse>>
    {
        public ListModelFilterBy FilterBy { get; set; }
    }
}