﻿using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Models
{
    public class DeleteModelCommand : CommandBase<ServiceResponseWrapper>
    {
        public DeleteModelCommand(int id)
        {
            Id = id;
        }

        public int Id { get;  }
    }
}
