﻿namespace YK.IMS.Service.Models
{
    public class CreateModelResponse 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
