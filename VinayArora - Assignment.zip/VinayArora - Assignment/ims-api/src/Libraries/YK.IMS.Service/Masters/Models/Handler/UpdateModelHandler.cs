﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Models;

namespace YK.IMS.Service.Models
{
    public class UpdateModelHandler : StatusGenericHandler, IUpdateModelHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly IModelDbAccess _dbAccess;

        public UpdateModelHandler(DbContext context, ILogger logger, IModelDbAccess dbAccess)
        {
            _logger = logger.ForContext<UpdateModelHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper<UpdateModelResponse>> Handle(UpdateModelCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");
            if (request == null)
            {
                _logger.Error($"'Null or invalid object '{nameof(request)}' found.");
                throw new ArgumentNullException(nameof(request));
            }

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid model {nameof(request.Id)} '{request.Id}'");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            if (string.IsNullOrEmpty(request.Name))
            {
                _logger.Error($"Null or empty {nameof(request.Name)} '{request.Name}' is invalid.");
                AddError("Name Is Required", nameof(request.Name));
            }

            if (string.IsNullOrEmpty(request.Description))
            {
                //_logger.Error($"Null or empty {nameof(request.Description)} '{request.Description}' is invalid.");
                // AddError("Description Is Required", nameof(request.Description));
            }

            if (string.IsNullOrEmpty(request.Code))
            {
                _logger.Error($"Null or empty {nameof(request.Code)} '{request.Code}' is invalid.");
                AddError("Code Is Required", nameof(request.Code));
            }

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                _logger.Information($"Validation failed for '{nameof(Model)}' entity object.");
                return new ServiceResponseWrapper<UpdateModelResponse>(null, this);
            }

            _logger.Debug($"Find model '{request.Id}'.");
            Model modelToUpdate = await _dbAccess.FindById(request.Id);
            if (modelToUpdate == null)
            {
                _logger.Error($"Sorry, I could not find the model '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the model you were looking for.");
                return new ServiceResponseWrapper<UpdateModelResponse>(null, this);
            }

            if (await _dbAccess.IsDuplicate(modelToUpdate.Id, request.Name, modelToUpdate.Code))
            {
                _logger.Error($"Duplicate entry found for '{request.Name}'.");
                AddError("Duplicate entry found.", nameof(request.Name));
                AddError("Duplicate entry found.", nameof(request.Code));
                return new ServiceResponseWrapper<UpdateModelResponse>(null, this);
            }

            CombineErrors(modelToUpdate.ChangeCode(request.Code));
            CombineErrors(modelToUpdate.ChangeName(request.Name));
            CombineErrors(modelToUpdate.ChangeDescription(request.Description));
            CombineErrors(modelToUpdate.ChangeUpdatedBy(request.LastUpdatedBy));

            if (!HasErrors)
            {
                _logger.Information($"Update model entity.");
                _dbAccess.Update(modelToUpdate);
                await _context.SaveChangesAsync();
                Message = $"Successfully update the Model '{request.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(Model)}' entity object.");
            }

            return new ServiceResponseWrapper<UpdateModelResponse>(null, this);
        }
    }
}
