﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Models
{
    public class SingleModelQuery : QueryBase<ModelListResponse>
    {
        public SingleModelQuery(ListModelFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListModelFilterBy FilterBy { get; }
    }
}