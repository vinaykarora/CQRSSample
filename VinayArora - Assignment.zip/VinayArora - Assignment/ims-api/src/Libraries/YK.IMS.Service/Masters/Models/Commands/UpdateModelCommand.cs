﻿using System;
using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Models
{
    public class UpdateModelCommand : CommandBase<ServiceResponseWrapper<UpdateModelResponse>>
    {
        public UpdateModelCommand(int id, int companyId, string name, string code, string description, string lastUpdatedBy, bool isActive = true, bool isDelete = false)
        {
            Id = id;
            CompanyId = companyId;
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Code = code ?? throw new ArgumentNullException(nameof(code));
            Description = description;
            IsActive = isActive;
            IsDelete = isDelete;
            LastUpdatedAt = DateTime.UtcNow;
            LastUpdatedBy = lastUpdatedBy ?? throw new ArgumentNullException(nameof(lastUpdatedBy));
        }

        public int Id { get; }
        public int CompanyId { get; }
        public string Name { get; }
        public string Code { get; }
        public string Description { get; }
        public bool IsActive { get; }
        public bool IsDelete { get; }
        public DateTime LastUpdatedAt { get; }
        public string LastUpdatedBy { get; }
    }
}
