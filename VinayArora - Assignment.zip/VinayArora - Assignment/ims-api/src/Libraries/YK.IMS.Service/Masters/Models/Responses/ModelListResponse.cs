﻿using System;

namespace YK.IMS.Service.Models
{
    public class ModelListResponse
    {
        public ModelListResponse(int id, int companyId, string name, string code, string description, bool isActive, bool isDelete, DateTime createdAt, string createdBy, string createdByName, DateTime? lastUpdatedAt, string lastUpdatedBy, string lastUpdatedByName)
        {
            Id = id;
            CompanyId = companyId;
            Name = name;
            Code = code;
            Description = description;
            IsActive = isActive;
            IsDelete = isDelete;
            CreatedAt = createdAt;
            CreatedBy = createdBy;
            CreatedByName = createdByName;
            LastUpdatedAt = lastUpdatedAt;
            LastUpdatedBy = lastUpdatedBy;
            LastUpdatedByName = lastUpdatedByName;
        }

        public int Id { get; }
        public int CompanyId { get; }
        public string Name { get; }
        public string Code { get; }
        public string Description { get; }
        public bool IsActive { get; }
        public bool IsDelete { get; }
        public DateTime CreatedAt { get; }
        public string CreatedBy { get; }
        public string CreatedByName { get; }
        public DateTime? LastUpdatedAt { get; }
        public string LastUpdatedBy { get; }
        public string LastUpdatedByName { get; }
    }
}
