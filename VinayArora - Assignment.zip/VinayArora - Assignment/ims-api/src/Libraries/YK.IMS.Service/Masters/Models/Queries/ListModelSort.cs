﻿using System;
using System.Linq;
using YK.IMS.Core.Helpers;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Models
{
    public static class ListModelSort
    {
        public static IQueryable<Model> OrderModelsBy(this IQueryable<Model> models, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.Id); }
                    else { return models.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.Name); }
                    else { return models.OrderBy(x => x.Name); }
                case Constants.Strings.OrderByOptions.CREATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.CreatedAt); }
                    else { return models.OrderBy(x => x.CreatedAt); }
                case Constants.Strings.OrderByOptions.CODE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.Code); }
                    else { return models.OrderBy(x => x.Code); }
                case Constants.Strings.OrderByOptions.DESCRIPTION:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.Description); }
                    else { return models.OrderBy(x => x.Description); }
                case Constants.Strings.OrderByOptions.CREATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.CreatedBy); }
                    else { return models.OrderBy(x => x.CreatedBy); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.LastUpdatedAt); }
                    else { return models.OrderBy(x => x.LastUpdatedAt); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.LastUpdatedBy); }
                    else { return models.OrderBy(x => x.LastUpdatedBy); }
                case Constants.Strings.OrderByOptions.ACTIVE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.IsActive); }
                    else { return models.OrderBy(x => x.IsActive); }
                case Constants.Strings.OrderByOptions.DELETED:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.IsDelete); }
                    else { return models.OrderBy(x => x.IsDelete); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }

        public static IQueryable<Model> OrderModelsDropdownBy(this IQueryable<Model> models, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.Id); }
                    else { return models.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return models.OrderByDescending(x => x.Name); }
                    else { return models.OrderBy(x => x.Name); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }
    }
}