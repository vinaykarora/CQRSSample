﻿using System.Linq;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Models
{
    public static class ListModelSelect
    {
        public static IQueryable<ModelListResponse> MapModelToResponse(this IQueryable<Model> models)
        {
            return models.Select(p =>
                    new ModelListResponse
                    (
                        p.Id,
                        p.CompanyId,
                        p.Name,
                        p.Code,
                        p.Description,
                        p.IsActive,
                        p.IsDelete,
                        p.CreatedAt,
                        p.CreatedBy,
                        string.Empty,
                        p.LastUpdatedAt,
                        p.LastUpdatedBy,
                        string.Empty
                    )
                );
        }

        public static IQueryable<ModelDropdownResponse> MapModelToDropdown(this IQueryable<Model> models)
        {
            return models.Select(p => new ModelDropdownResponse(p.Id, p.Name));
        }
    }
}