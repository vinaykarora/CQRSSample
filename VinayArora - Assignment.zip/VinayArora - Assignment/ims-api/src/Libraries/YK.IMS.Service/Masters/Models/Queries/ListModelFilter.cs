﻿using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Models
{
    public class ListModelFilterBy : FilterByBase
    {

    }

    public static class ListModelFilter
    {
        public static IQueryable<Model> FilterModelsBy(this IQueryable<Model> models, ListModelFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return models;
            }

            if (filterBy.Id > 0) { models = models.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { models = models.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                models = models.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { models = models.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { models = models.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            models = models.Where(x => x.IsActive == filterBy.IsActive);
            models = models.Where(x => x.IsDelete == filterBy.IsDelete);
            return models;
        }

    }
}