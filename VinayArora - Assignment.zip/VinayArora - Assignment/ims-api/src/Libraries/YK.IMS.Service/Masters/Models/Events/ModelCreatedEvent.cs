﻿using MediatR;

namespace YK.IMS.Service.Models
{
    public class ModelCreatedEvent : INotification
    {
        public int ModelId { get; }

        public ModelCreatedEvent(int modelId)
        {
            ModelId = modelId;
        }
    }
}
