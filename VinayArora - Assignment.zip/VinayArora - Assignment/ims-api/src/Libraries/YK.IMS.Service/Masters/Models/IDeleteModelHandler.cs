﻿using MediatR;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Models
{
    public interface IDeleteModelHandler :  IRequestHandler<DeleteModelCommand, ServiceResponseWrapper> { }
}
