﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.Models
{
    public interface IListModelHandler : IRequestHandler<ListModelQuery, IEnumerable<ModelListResponse>>, 
        IRequestHandler<DropdownModelQuery, IEnumerable<ModelDropdownResponse>>,
        IRequestHandler<SingleModelQuery, ModelListResponse>
    {
    }
}
