﻿using MediatR;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DbAccess.Models;

namespace YK.IMS.Service.Models
{
    public class ModelCreatedHandler : INotificationHandler<ModelCreatedEvent>
    {
        private readonly IModelDbAccess _dbAccess;
        private readonly ILogger _logger;

        public ModelCreatedHandler(ILogger logger, IModelDbAccess dbAccess)
        {
            _logger = logger.ForContext<ModelCreatedHandler>();
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task Handle(ModelCreatedEvent notification, CancellationToken cancellationToken)
        {
            var model = await _dbAccess.FindById(notification.ModelId);

            if (model == null)
            {
                //TODO: Handle next business logic if customer is not found
                _logger.Warning("Model is not found by customer id from publisher");
            }
            else
            {
                _logger.Information($"Model has found by model id: {notification.ModelId} from publisher");
            }
        }
    }
}
