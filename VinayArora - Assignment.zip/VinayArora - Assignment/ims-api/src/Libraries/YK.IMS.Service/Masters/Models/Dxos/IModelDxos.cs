﻿namespace YK.IMS.Service.Models
{
    public interface IModelDxos
    {
        CreateModelResponse MapCreateModelResponse(DataLayer.EfClasses.Model model);
    }
}
