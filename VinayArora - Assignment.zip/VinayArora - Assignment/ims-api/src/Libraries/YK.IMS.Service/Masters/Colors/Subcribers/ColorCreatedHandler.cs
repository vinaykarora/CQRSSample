﻿using MediatR;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DbAccess.Colors;

namespace YK.IMS.Service.Colors
{
    public class ColorCreatedHandler : INotificationHandler<ColorCreatedEvent>
    {
        private readonly IColorDbAccess _dbAccess;
        private readonly ILogger _logger;

        public ColorCreatedHandler(ILogger logger, IColorDbAccess dbAccess)
        {
            _logger = logger.ForContext<ColorCreatedHandler>();
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task Handle(ColorCreatedEvent notification, CancellationToken cancellationToken)
        {
            var color = await _dbAccess.FindById(notification.ColorId);

            if (color == null)
            {
                //TODO: Handle next business logic if customer is not found
                _logger.Warning("Color is not found by customer id from publisher");
            }
            else
            {
                _logger.Information($"Color has found by color id: {notification.ColorId} from publisher");
            }
        }
    }
}
