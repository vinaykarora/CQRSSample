﻿using MediatR;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;

namespace YK.IMS.Service.Colors
{
    public interface ICreateColorHandler : IStatusGeneric, IRequestHandler<CreateColorCommand, ServiceResponseWrapper<CreateColorResponse>> { }
}
