﻿using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Colors
{
    public class DeleteColorCommand : CommandBase<ServiceResponseWrapper>
    {
        public DeleteColorCommand(int id)
        {
            Id = id;
        }

        public int Id { get;  }
    }
}
