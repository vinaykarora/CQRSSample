﻿using System;

namespace YK.IMS.Service.Colors
{
    public class ColorListResponse
    {
        public ColorListResponse(int id, int companyId, string name, string code, string description, bool isActive, bool isDelete, string createdAt, string createdBy, string createdByName, string lastUpdatedAt, string lastUpdatedBy, string lastUpdatedByName)
        {
            Id = id;
            CompanyId = companyId;
            Name = name;
            Code = code;
            Description = description;
            IsActive = isActive;
            IsDelete = isDelete;
            CreatedAt = createdAt;
            CreatedBy = createdBy;
            CreatedByName = createdByName;
            LastUpdatedAt = lastUpdatedAt;
            LastUpdatedBy = lastUpdatedBy;
            LastUpdatedByName = lastUpdatedByName;
        }

        public int Id { get; }
        public int CompanyId { get; }
        public string Name { get; }
        public string Code { get; }
        public string Description { get; }
        public bool IsActive { get; }
        public bool IsDelete { get; }
        public string CreatedAt { get; }
        public string CreatedBy { get; }
        public string CreatedByName { get; }
        public string LastUpdatedAt { get; }
        public string LastUpdatedBy { get; }
        public string LastUpdatedByName { get; }
    }
}
