﻿using AutoMapper;

namespace YK.IMS.Service.Colors
{
    public class ColorDxos : IColorDxos
    {
        private readonly IMapper _mapper;

        public ColorDxos()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<DataLayer.EfClasses.Color, CreateColorResponse>()
                    .ForMember(dst => dst.Id, opt => opt.MapFrom(src => src.Id))
                    .ForMember(dst => dst.Name, opt => opt.MapFrom(src => src.Name));
            });

            _mapper = config.CreateMapper();
        }

        public CreateColorResponse MapCreateColorResponse(DataLayer.EfClasses.Color color)
        {
            if (color == null)
                return null;

            return _mapper.Map<DataLayer.EfClasses.Color, CreateColorResponse>(color);
        }
    }
}
