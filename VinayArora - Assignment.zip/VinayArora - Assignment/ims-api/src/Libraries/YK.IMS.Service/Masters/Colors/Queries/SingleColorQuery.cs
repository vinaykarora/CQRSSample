﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Colors
{
    public class SingleColorQuery : QueryBase<ColorListResponse>
    {
        public SingleColorQuery(ListColorFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListColorFilterBy FilterBy { get; }
    }
}