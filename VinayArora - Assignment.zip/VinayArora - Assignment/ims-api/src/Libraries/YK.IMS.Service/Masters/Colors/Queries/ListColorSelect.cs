﻿using System;
using System.Linq;
using YK.IMS.Core.Helpers;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Colors
{
    public static class ListColorSelect
    {
        public static IQueryable<ColorListResponse> MapColorToResponse(this IQueryable<Color> colors)
        {
            return colors.Select(p =>
                    new ColorListResponse
                    (
                        p.Id,
                        p.CompanyId,
                        p.Name,
                        p.Code,
                        p.Description,
                        p.IsActive,
                        p.IsDelete,
                        p.CreatedAt.GetIndianFormatedDateTimeString(),
                        p.CreatedBy,
                        string.Empty,
                        p.LastUpdatedAt.HasValue ? p.LastUpdatedAt.Value.GetIndianFormatedDateTimeString() : string.Empty,
                        p.LastUpdatedBy,
                        string.Empty
                    )
                );
        }

        public static IQueryable<ColorDropdownResponse> MapColorToDropdown(this IQueryable<Color> colors)
        {
            return colors.Select(p => new ColorDropdownResponse(p.Id, p.Name));
        }
    }
}