﻿using System;
using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Colors
{
    public class ListColorFilterBy : FilterByBase
    {

    }

    public static class ListColorFilter
    {
        public static IQueryable<Color> FilterColorsBy(this IQueryable<Color> colors, ListColorFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return colors;
            }

            if (filterBy.Id > 0) { colors = colors.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { colors = colors.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                colors = colors.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { colors = colors.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { colors = colors.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            colors = colors.Where(x => x.IsActive == filterBy.IsActive);
            colors = colors.Where(x => x.IsDelete == filterBy.IsDelete);
            return colors;
        }

    }
}