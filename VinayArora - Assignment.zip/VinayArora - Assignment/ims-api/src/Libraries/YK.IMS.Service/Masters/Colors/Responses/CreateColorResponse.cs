﻿namespace YK.IMS.Service.Colors
{
    public class CreateColorResponse 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
