﻿using MediatR;

namespace YK.IMS.Service.Colors
{
    public class ColorCreatedEvent : INotification
    {
        public int ColorId { get; }

        public ColorCreatedEvent(int colorId)
        {
            ColorId = colorId;
        }
    }
}
