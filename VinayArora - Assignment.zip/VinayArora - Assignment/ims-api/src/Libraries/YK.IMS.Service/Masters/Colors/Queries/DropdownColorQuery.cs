﻿using System.Collections.Generic;
using YK.IMS.Core.Enums;
using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Colors
{
    public class DropdownColorQuery : QueryBase<IEnumerable<ColorDropdownResponse>>
    {
        public ListColorFilterBy FilterBy { get; set; }
    }
}