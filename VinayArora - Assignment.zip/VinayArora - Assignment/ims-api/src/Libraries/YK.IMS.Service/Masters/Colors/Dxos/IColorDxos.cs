﻿namespace YK.IMS.Service.Colors
{
    public interface IColorDxos
    {
        CreateColorResponse MapCreateColorResponse(DataLayer.EfClasses.Color color);
    }
}
