﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;
using YK.IMS.DbAccess.Colors;

namespace YK.IMS.Service.Colors
{
    public class ListColorHandler : IListColorHandler
    {
        private readonly ILogger _logger;
        private readonly IColorDbAccess _dbAccess;
        public ListColorHandler(ILogger logger, IColorDbAccess dbAccess)
        {
            _logger = logger;
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<IEnumerable<ColorDropdownResponse>> Handle(DropdownColorQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get color(s) dropdown.");
            return await _dbAccess
                .NoTrackingEntity
                .FilterColorsBy(request.FilterBy)
                .OrderColorsDropdownBy(request.OrderByOptions, request.SortOrder)
                .MapColorToDropdown()
                .ToListAsync();
        }

        public async Task<IEnumerable<ColorListResponse>> Handle(ListColorQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get color(s) list.");

            IQueryable<ColorListResponse> colorsQuery = _dbAccess
                  .NoTrackingEntity
                  .FilterColorsBy(request.FilterBy)
                  .OrderColorsBy(request.OrderByOptions, request.SortOrder)
                  .MapColorToResponse();

            await request.SetupRestOfDto(colorsQuery);

            return colorsQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<ColorListResponse> Handle(SingleColorQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get color.");

            return await _dbAccess
                  .NoTrackingEntity
                  .FilterColorsBy(request.FilterBy)
                  .MapColorToResponse()
                  .FirstOrDefaultAsync();
        }
    }
}