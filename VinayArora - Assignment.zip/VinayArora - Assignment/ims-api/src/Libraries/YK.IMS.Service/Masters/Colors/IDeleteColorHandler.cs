﻿using MediatR;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Colors
{
    public interface IDeleteColorHandler :  IRequestHandler<DeleteColorCommand, ServiceResponseWrapper> { }
}
