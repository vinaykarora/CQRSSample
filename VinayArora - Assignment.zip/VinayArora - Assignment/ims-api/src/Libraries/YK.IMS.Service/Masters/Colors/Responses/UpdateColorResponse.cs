﻿namespace YK.IMS.Service.Colors
{
    public class UpdateColorResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
