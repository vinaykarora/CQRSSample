﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.Colors
{
    public interface IListColorHandler : IRequestHandler<ListColorQuery, IEnumerable<ColorListResponse>>, 
        IRequestHandler<DropdownColorQuery, IEnumerable<ColorDropdownResponse>>,
        IRequestHandler<SingleColorQuery, ColorListResponse>
    {
    }
}
