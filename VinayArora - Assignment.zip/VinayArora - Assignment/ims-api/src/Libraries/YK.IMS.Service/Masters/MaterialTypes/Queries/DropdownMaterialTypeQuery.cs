﻿using System.Collections.Generic;
using YK.IMS.Core.Queries;

namespace YK.IMS.Service.MaterialTypes
{
    public class DropdownMaterialTypeQuery : QueryBase<IEnumerable<MaterialTypeDropdownResponse>>
    {
       
        public ListMaterialTypeFilterBy FilterBy { get; set; }
    }
}