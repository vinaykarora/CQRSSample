﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;


namespace YK.IMS.Service.MaterialTypes
{
    public class ListMaterialTypeHandler : IListMaterialTypeHandler
    {
        private readonly IMSContext _context;
        private readonly ILogger _logger;
        public ListMaterialTypeHandler(IMSContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<MaterialTypeDropdownResponse>> Handle(DropdownMaterialTypeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get materialType(s) dropdown.");
            return await _context.MaterialType
                  .AsNoTracking()
                  .FilterMaterialTypesBy(request.FilterBy)
                  .OrderMaterialTypesDropdownBy(request.OrderByOptions, request.SortOrder)
                  .MapMaterialTypeToDropdown()
                  .ToListAsync();
        }

        public async Task<IEnumerable<MaterialTypeListResponse>> Handle(ListMaterialTypeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get materialType(s) list.");

            IQueryable<MaterialTypeListResponse> materialTypesQuery = _context.MaterialType
                .AsNoTracking()
                .FilterMaterialTypesBy(request.FilterBy)
                .OrderMaterialTypesBy(request.OrderByOptions, request.SortOrder)
                .MapMaterialTypeToResponse();

            await request.SetupRestOfDto(materialTypesQuery);

            return materialTypesQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<MaterialTypeListResponse> Handle(SingleMaterialTypeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get MaterialType.");

            return await _context.MaterialType
                .AsNoTracking()
                .FilterMaterialTypesBy(request.FilterBy)
                .MapMaterialTypeToResponse()
                .FirstOrDefaultAsync();
        }
    }
}