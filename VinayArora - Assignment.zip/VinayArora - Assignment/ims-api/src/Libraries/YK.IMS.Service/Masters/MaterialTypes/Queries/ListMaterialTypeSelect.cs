﻿using System.Linq;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.MaterialTypes
{
    public static class ListMaterialTypeSelect
    {
        public static IQueryable<MaterialTypeListResponse> MapMaterialTypeToResponse(this IQueryable<MaterialType> materialTypes)
        {
            return materialTypes.Select(p =>
                    new MaterialTypeListResponse
                    (
                        p.Id,
                        p.CompanyId,
                        p.Name,
                        p.Code,
                        p.Description,
                        p.IsActive,
                        p.IsDelete,
                        p.CreatedAt,
                        p.CreatedBy,
                        string.Empty,
                        p.LastUpdatedAt,
                        p.LastUpdatedBy,
                        string.Empty
                    )
                );
        }

        public static IQueryable<MaterialTypeDropdownResponse> MapMaterialTypeToDropdown(this IQueryable<MaterialType> materialTypes)
        {
            return materialTypes.Select(p => new MaterialTypeDropdownResponse(p.Id, p.Name));
        }
    }
}