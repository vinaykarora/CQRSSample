﻿using MediatR;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DbAccess.MaterialTypes;

namespace YK.IMS.Service.MaterialTypes
{
    public class MaterialTypeCreatedHandler : INotificationHandler<MaterialTypeCreatedEvent>
    {
        private readonly IMaterialTypeDbAccess _dbAccess;
        private readonly ILogger _logger;

        public MaterialTypeCreatedHandler(ILogger logger, IMaterialTypeDbAccess dbAccess)
        {
            _logger = logger.ForContext<MaterialTypeCreatedHandler>();
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task Handle(MaterialTypeCreatedEvent notification, CancellationToken cancellationToken)
        {
            var materialType = await _dbAccess.FindById(notification.MaterialTypeId);

            if (materialType == null)
            {
                //TODO: Handle next business logic if customer is not found
                _logger.Warning("MaterialType is not found by customer id from publisher");
            }
            else
            {
                _logger.Information($"MaterialType has found by materialType id: {notification.MaterialTypeId} from publisher");
            }
        }
    }
}
