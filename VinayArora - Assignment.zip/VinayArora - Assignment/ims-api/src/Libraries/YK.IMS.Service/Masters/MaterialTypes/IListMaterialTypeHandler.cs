﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.MaterialTypes
{
    public interface IListMaterialTypeHandler : IRequestHandler<ListMaterialTypeQuery, IEnumerable<MaterialTypeListResponse>>, 
        IRequestHandler<DropdownMaterialTypeQuery, IEnumerable<MaterialTypeDropdownResponse>>,
        IRequestHandler<SingleMaterialTypeQuery, MaterialTypeListResponse>
    {
    }
}
