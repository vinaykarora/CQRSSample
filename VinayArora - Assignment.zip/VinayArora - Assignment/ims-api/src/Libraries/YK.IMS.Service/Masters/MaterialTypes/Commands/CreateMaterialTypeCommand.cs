﻿using System;
using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.MaterialTypes
{
    public class CreateMaterialTypeCommand : CommandBase<ServiceResponseWrapper<CreateMaterialTypeResponse>>
    {
        public CreateMaterialTypeCommand(int companyId, string name, string code, string description, string createdBy)
        {
            CompanyId = companyId;
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Code = code ?? throw new ArgumentNullException(nameof(code));
            Description = description;
            IsActive = true;
            IsDelete = false;
            CreatedAt = DateTime.UtcNow;
            if (string.IsNullOrWhiteSpace(createdBy) || !Guid.TryParse(createdBy, out Guid result))
            {
                throw new ArgumentNullException(nameof(createdBy));
            }
            CreatedBy = createdBy;
        }

        public int CompanyId { get; }
        public string Name { get; }
        public string Code { get; }
        public string Description { get; }
        public bool IsActive { get; }
        public bool IsDelete { get; }
        public DateTime CreatedAt { get; }
        public string CreatedBy { get; }
    }
}
