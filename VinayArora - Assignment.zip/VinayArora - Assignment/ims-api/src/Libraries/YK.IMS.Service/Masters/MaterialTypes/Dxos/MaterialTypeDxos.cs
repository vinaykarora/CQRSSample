﻿using AutoMapper;

namespace YK.IMS.Service.MaterialTypes
{
    public class MaterialTypeDxos : IMaterialTypeDxos
    {
        private readonly IMapper _mapper;

        public MaterialTypeDxos()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<DataLayer.EfClasses.MaterialType, CreateMaterialTypeResponse>()
                    .ForMember(dst => dst.Id, opt => opt.MapFrom(src => src.Id))
                    .ForMember(dst => dst.Name, opt => opt.MapFrom(src => src.Name));
            });

            _mapper = config.CreateMapper();
        }

        public CreateMaterialTypeResponse MapCreateMaterialTypeResponse(DataLayer.EfClasses.MaterialType materialType)
        {
            if (materialType == null)
                return null;

            return _mapper.Map<DataLayer.EfClasses.MaterialType, CreateMaterialTypeResponse>(materialType);
        }
    }
}
