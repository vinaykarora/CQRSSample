﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.MaterialTypes
{
    public class SingleMaterialTypeQuery : QueryBase<MaterialTypeListResponse>
    {
        public SingleMaterialTypeQuery(ListMaterialTypeFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListMaterialTypeFilterBy FilterBy { get; }
    }
}