﻿using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.MaterialTypes
{
    public class ListMaterialTypeFilterBy : FilterByBase
    {

    }

    public static class ListMaterialTypeFilter
    {
        public static IQueryable<MaterialType> FilterMaterialTypesBy(this IQueryable<MaterialType> materialTypes, ListMaterialTypeFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return materialTypes;
            }

            if (filterBy.Id > 0) { materialTypes = materialTypes.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { materialTypes = materialTypes.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                materialTypes = materialTypes.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { materialTypes = materialTypes.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { materialTypes = materialTypes.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            materialTypes = materialTypes.Where(x => x.IsActive == filterBy.IsActive);
            materialTypes = materialTypes.Where(x => x.IsDelete == filterBy.IsDelete);
            return materialTypes;
        }

    }
}