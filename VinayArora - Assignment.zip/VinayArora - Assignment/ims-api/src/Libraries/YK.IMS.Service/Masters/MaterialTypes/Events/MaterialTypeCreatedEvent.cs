﻿using MediatR;

namespace YK.IMS.Service.MaterialTypes
{
    public class MaterialTypeCreatedEvent : INotification
    {
        public int MaterialTypeId { get; }

        public MaterialTypeCreatedEvent(int materialTypeId)
        {
            MaterialTypeId = materialTypeId;
        }
    }
}
