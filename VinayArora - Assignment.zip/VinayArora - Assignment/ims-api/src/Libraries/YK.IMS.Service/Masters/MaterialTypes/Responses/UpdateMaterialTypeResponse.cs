﻿namespace YK.IMS.Service.MaterialTypes
{
    public class UpdateMaterialTypeResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
