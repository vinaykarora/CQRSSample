﻿using MediatR;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.MaterialTypes
{
    public interface IDeleteMaterialTypeHandler :  IRequestHandler<DeleteMaterialTypeCommand, ServiceResponseWrapper> { }
}
