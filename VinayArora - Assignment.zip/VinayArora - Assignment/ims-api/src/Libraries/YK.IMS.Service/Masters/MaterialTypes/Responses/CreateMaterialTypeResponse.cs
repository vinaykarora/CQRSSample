﻿namespace YK.IMS.Service.MaterialTypes
{
    public class CreateMaterialTypeResponse 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
