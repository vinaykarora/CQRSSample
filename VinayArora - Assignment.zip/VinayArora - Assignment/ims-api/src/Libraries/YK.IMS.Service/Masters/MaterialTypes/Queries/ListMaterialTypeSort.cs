﻿using System;
using System.Linq;
using YK.IMS.Core.Helpers;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.MaterialTypes
{
    public static class ListMaterialTypeSort
    {
        public static IQueryable<MaterialType> OrderMaterialTypesBy(this IQueryable<MaterialType> materialTypes, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.Id); }
                    else { return materialTypes.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.Name); }
                    else { return materialTypes.OrderBy(x => x.Name); }
                case Constants.Strings.OrderByOptions.CREATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.CreatedAt); }
                    else { return materialTypes.OrderBy(x => x.CreatedAt); }
                case Constants.Strings.OrderByOptions.CODE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.Code); }
                    else { return materialTypes.OrderBy(x => x.Code); }
                case Constants.Strings.OrderByOptions.DESCRIPTION:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.Description); }
                    else { return materialTypes.OrderBy(x => x.Description); }
                case Constants.Strings.OrderByOptions.CREATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.CreatedBy); }
                    else { return materialTypes.OrderBy(x => x.CreatedBy); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.LastUpdatedAt); }
                    else { return materialTypes.OrderBy(x => x.LastUpdatedAt); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.LastUpdatedBy); }
                    else { return materialTypes.OrderBy(x => x.LastUpdatedBy); }
                case Constants.Strings.OrderByOptions.ACTIVE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.IsActive); }
                    else { return materialTypes.OrderBy(x => x.IsActive); }
                case Constants.Strings.OrderByOptions.DELETED:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.IsDelete); }
                    else { return materialTypes.OrderBy(x => x.IsDelete); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }

        public static IQueryable<MaterialType> OrderMaterialTypesDropdownBy(this IQueryable<MaterialType> materialTypes, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.Id); }
                    else { return materialTypes.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return materialTypes.OrderByDescending(x => x.Name); }
                    else { return materialTypes.OrderBy(x => x.Name); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }
    }
}