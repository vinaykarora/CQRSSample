﻿namespace YK.IMS.Service.MaterialTypes
{
    public interface IMaterialTypeDxos
    {
        CreateMaterialTypeResponse MapCreateMaterialTypeResponse(DataLayer.EfClasses.MaterialType materialType);
    }
}
