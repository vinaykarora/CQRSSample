﻿using MediatR;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;

namespace YK.IMS.Service.MaterialTypes
{
    public interface IUpdateMaterialTypeHandler : IStatusGeneric, IRequestHandler<UpdateMaterialTypeCommand, ServiceResponseWrapper<UpdateMaterialTypeResponse>> { }
}
