﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.MaterialTypes;

namespace YK.IMS.Service.MaterialTypes
{
    public class CreateMaterialTypeHandler : StatusGenericHandler, ICreateMaterialTypeHandler
    {
        private readonly ILogger _logger;
        private readonly IMediator _mediator;
        private readonly IMaterialTypeDxos _materialTypeDxos;
        private readonly DbContext _context;
        private readonly IMaterialTypeDbAccess _dbAccess;

        public CreateMaterialTypeHandler(DbContext context, ILogger logger, IMediator mediator, IMaterialTypeDxos materialTypeDxos, IMaterialTypeDbAccess dbAccess)
        {
            _logger = logger.ForContext<CreateMaterialTypeHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _materialTypeDxos = materialTypeDxos ?? throw new ArgumentNullException(nameof(materialTypeDxos));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper<CreateMaterialTypeResponse>> Handle(CreateMaterialTypeCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");
            if (request == null)
            {
                _logger.Error($"'Null or invalid object '{nameof(request)}' found.");
                throw new ArgumentNullException(nameof(request));
            }

            _logger.Debug($"Creating new '{request.Name}' materialType.");

            if (string.IsNullOrEmpty(request.Name))
            {
                _logger.Error($"Null or empty {nameof(request.Name)} '{request.Name}' is invalid.");
                AddError("Name Is Required", nameof(request.Name));
            }

            if (string.IsNullOrEmpty(request.Description))
            {
                //_logger.Error($"Null or empty {nameof(request.Description)} '{request.Description}' is invalid.");
                // AddError("Description Is Required", nameof(request.Description));
            }

            if (string.IsNullOrEmpty(request.Code))
            {
                _logger.Error($"Null or empty {nameof(request.Code)} '{request.Code}' is invalid.");
                AddError("Code Is Required", nameof(request.Code));
            }

            if (HasErrors)
            {
                return new ServiceResponseWrapper<CreateMaterialTypeResponse>(null, this);
            }


            if (await _dbAccess.IsDuplicate(0, request.Name, request.Code))
            {
                _logger.Error($"Duplicate entry found for name '{request.Name}' and code '{request.Code}'.");
                AddError("Duplicate entry found.", nameof(request.Name));
                AddError("Duplicate entry found.", nameof(request.Code));
                return new ServiceResponseWrapper<CreateMaterialTypeResponse>(null, this);
            }

            _logger.Information($"Create '{nameof(MaterialType)}' entity object.");
            IStatusGeneric<MaterialType> status = MaterialType.CreateMaterialTypeFactory(request.CompanyId, request.Name, request.Code, request.Description, request.CreatedBy);
            CombineErrors(status);

            if (!HasErrors)
            {
                _logger.Information($"Add '{nameof(MaterialType)}' entity object.");
                await _dbAccess.Create(status.Result);
                await _context.SaveChangesAsync();
                Message = $"Successfully saved the MaterialType '{request.Name}'.";
                _logger.Information(Message);

                await _mediator.Publish(new MaterialTypeCreatedEvent(status.Result.Id), cancellationToken);
            }
            else
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                _logger.Information($"Validation failed for '{nameof(MaterialType)}' entity object.");
            }

            return new ServiceResponseWrapper<CreateMaterialTypeResponse>(_materialTypeDxos.MapCreateMaterialTypeResponse(status.Result), this);
        }
    }
}
