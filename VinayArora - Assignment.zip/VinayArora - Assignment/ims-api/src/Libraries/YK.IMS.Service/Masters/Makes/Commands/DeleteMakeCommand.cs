﻿using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Makes
{
    public class DeleteMakeCommand : CommandBase<ServiceResponseWrapper>
    {
        public DeleteMakeCommand(int id)
        {
            Id = id;
        }

        public int Id { get;  }
    }
}
