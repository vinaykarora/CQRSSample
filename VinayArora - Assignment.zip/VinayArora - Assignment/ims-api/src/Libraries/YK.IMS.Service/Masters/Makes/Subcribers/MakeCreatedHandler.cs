﻿using MediatR;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DbAccess.Makes;

namespace YK.IMS.Service.Makes
{
    public class MakeCreatedHandler : INotificationHandler<MakeCreatedEvent>
    {
        private readonly IMakeDbAccess _dbAccess;
        private readonly ILogger _logger;

        public MakeCreatedHandler(ILogger logger, IMakeDbAccess dbAccess)
        {
            _logger = logger.ForContext<MakeCreatedHandler>();
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task Handle(MakeCreatedEvent notification, CancellationToken cancellationToken)
        {
            var make = await _dbAccess.FindById(notification.MakeId);

            if (make == null)
            {
                //TODO: Handle next business logic if customer is not found
                _logger.Warning("Make is not found by customer id from publisher");
            }
            else
            {
                _logger.Information($"Make has found by make id: {notification.MakeId} from publisher");
            }
        }
    }
}
