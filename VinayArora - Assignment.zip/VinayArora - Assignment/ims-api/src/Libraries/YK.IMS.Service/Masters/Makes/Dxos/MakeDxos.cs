﻿using AutoMapper;

namespace YK.IMS.Service.Makes
{
    public class MakeDxos : IMakeDxos
    {
        private readonly IMapper _mapper;

        public MakeDxos()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<DataLayer.EfClasses.Make, CreateMakeResponse>()
                    .ForMember(dst => dst.Id, opt => opt.MapFrom(src => src.Id))
                    .ForMember(dst => dst.Name, opt => opt.MapFrom(src => src.Name));
            });

            _mapper = config.CreateMapper();
        }

        public CreateMakeResponse MapCreateMakeResponse(DataLayer.EfClasses.Make make)
        {
            if (make == null)
                return null;

            return _mapper.Map<DataLayer.EfClasses.Make, CreateMakeResponse>(make);
        }
    }
}
