﻿using System.Collections.Generic;
using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Makes
{
    public class DropdownMakeQuery : QueryBase<IEnumerable<MakeDropdownResponse>>
    {
        public ListMakeFilterBy FilterBy { get; set; }
    }
}