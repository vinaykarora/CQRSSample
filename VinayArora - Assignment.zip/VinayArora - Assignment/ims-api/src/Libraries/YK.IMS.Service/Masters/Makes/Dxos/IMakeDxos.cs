﻿namespace YK.IMS.Service.Makes
{
    public interface IMakeDxos
    {
        CreateMakeResponse MapCreateMakeResponse(DataLayer.EfClasses.Make make);
    }
}
