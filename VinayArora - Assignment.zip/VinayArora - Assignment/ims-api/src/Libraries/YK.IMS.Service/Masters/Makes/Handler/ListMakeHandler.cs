﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;


namespace YK.IMS.Service.Makes
{
    public class ListMakeHandler : IListMakeHandler
    {
        private readonly IMSContext _context;
        private readonly ILogger _logger;
        public ListMakeHandler(IMSContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<MakeDropdownResponse>> Handle(DropdownMakeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get make(s) dropdown.");
            return await _context.Make
                  .AsNoTracking()
                  .FilterMakesBy(request.FilterBy)
                  .OrderMakesDropdownBy(request.OrderByOptions, request.SortOrder)
                  .MapMakeToDropdown()
                  .ToListAsync();
        }

        public async Task<IEnumerable<MakeListResponse>> Handle(ListMakeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get make(s) list.");

            IQueryable<MakeListResponse> makesQuery = _context.Make
                .AsNoTracking()
                .FilterMakesBy(request.FilterBy)
                .OrderMakesBy(request.OrderByOptions, request.SortOrder)
                .MapMakeToResponse();

            await request.SetupRestOfDto(makesQuery);

            return makesQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<MakeListResponse> Handle(SingleMakeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get Make.");

            return await _context.Make
                .AsNoTracking()
                .FilterMakesBy(request.FilterBy)
                .MapMakeToResponse()
                .FirstOrDefaultAsync();
        }
    }
}