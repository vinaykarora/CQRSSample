﻿using MediatR;

namespace YK.IMS.Service.Makes
{
    public class MakeCreatedEvent : INotification
    {
        public int MakeId { get; }

        public MakeCreatedEvent(int makeId)
        {
            MakeId = makeId;
        }
    }
}
