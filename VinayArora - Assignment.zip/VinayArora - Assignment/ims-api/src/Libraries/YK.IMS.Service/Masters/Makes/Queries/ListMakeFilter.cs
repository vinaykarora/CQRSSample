﻿using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Makes
{
    public class ListMakeFilterBy : FilterByBase
    {

    }

    public static class ListMakeFilter
    {
        public static IQueryable<Make> FilterMakesBy(this IQueryable<Make> makes, ListMakeFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return makes;
            }

            if (filterBy.Id > 0) { makes = makes.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { makes = makes.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                makes = makes.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { makes = makes.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { makes = makes.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            makes = makes.Where(x => x.IsActive == filterBy.IsActive);
            makes = makes.Where(x => x.IsDelete == filterBy.IsDelete);
            return makes;
        }

    }
}