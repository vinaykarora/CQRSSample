﻿namespace YK.IMS.Service.Makes
{
    public class CreateMakeResponse 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
