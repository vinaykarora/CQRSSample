﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.Makes
{
    public interface IListMakeHandler : IRequestHandler<ListMakeQuery, IEnumerable<MakeListResponse>>, 
        IRequestHandler<DropdownMakeQuery, IEnumerable<MakeDropdownResponse>>,
        IRequestHandler<SingleMakeQuery, MakeListResponse>
    {
    }
}
