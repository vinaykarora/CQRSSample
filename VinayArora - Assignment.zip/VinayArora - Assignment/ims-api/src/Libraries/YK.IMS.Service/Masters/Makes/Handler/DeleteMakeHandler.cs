﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Makes;

namespace YK.IMS.Service.Makes
{
    public class DeleteMakeHandler : StatusGenericHandler, IDeleteMakeHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly IMakeDbAccess _dbAccess;

        public DeleteMakeHandler(DbContext context, ILogger logger, IMakeDbAccess dbAccess)
        {
            _logger = logger.ForContext<DeleteMakeHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper> Handle(DeleteMakeCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid make id '{request.Id}'.");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            _logger.Debug($"Deleting existing make '{request.Id}'.");

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                return new ServiceResponseWrapper(this);
            }

            _logger.Debug($"Find make '{request.Id}'.");

            Make makeToDelete = await _dbAccess.FindById(request.Id);
            if (makeToDelete == null)
            {
                _logger.Error($"Sorry, I could not find the make '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the make you were looking for.");
            }

            if (!HasErrors)
            {
                _logger.Information($"Delete make entity.");
                makeToDelete.Delete();
                _dbAccess.Update(makeToDelete);
                await _context.SaveChangesAsync();
                Message = $"Successfully delete the Make '{makeToDelete.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(Make)}' entity object.");
            }

            return new ServiceResponseWrapper(this);
        }
    }
}
