﻿using MediatR;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;

namespace YK.IMS.Service.Makes
{
    public interface IChangeNameHandler : IStatusGeneric, IRequestHandler<ChangeNameCommand, ServiceResponseWrapper> { }
}
