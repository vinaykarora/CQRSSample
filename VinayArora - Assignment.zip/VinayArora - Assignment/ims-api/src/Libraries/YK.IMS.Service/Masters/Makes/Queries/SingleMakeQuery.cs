﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Makes
{
    public class SingleMakeQuery : QueryBase<MakeListResponse>
    {
        public SingleMakeQuery(ListMakeFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListMakeFilterBy FilterBy { get; }
    }
}