﻿using MediatR;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Makes
{
    public interface IDeleteMakeHandler :  IRequestHandler<DeleteMakeCommand, ServiceResponseWrapper> { }
}
