﻿namespace YK.IMS.Service.Makes
{
    public class UpdateMakeResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
