﻿namespace YK.IMS.Service.Products
{
    public class CreateProductResponse 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
