﻿using System.Linq;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.Core.Helpers;
namespace YK.IMS.Service.Products
{
    public static class ListProductSelect
    {
        public static IQueryable<ProductListResponse> MapProductToResponse(this IQueryable<Product> products)
        {
            return products.Select(p =>
                    new ProductListResponse
                    (p.Id,
                     p.CompanyId,
                     p.Name,
                     p.Code,
                     p.Description,
                     p.IsActive,
                     p.IsDelete,
                     p.CreatedAt.GetIndianFormatedDateTimeString(),
                     p.CreatedBy,
                     p.Barcode,
                     p.MaterialTypeId,
                     p.ProductGroupId,
                     p.UnitId,
                     p.RetailUnitId,
                     p.SizeId,
                     p.MakeId,
                     p.ColorId,
                     p.StyleId,
                     p.ChapterHeadingId,
                     p.PackSizeId,
                     p.ModelId,
                     p.DefaultSalePrice,
                     p.RetailSalePrice,
                     p.DefaultPurchasePrice,
                     p.DefaultDiscountPercentage,
                     p.DefaultDiscountPrice,
                     p.TaxPercentage,
                     string.Empty,
                     p.LastUpdatedAt.HasValue ? p.LastUpdatedAt.Value.GetIndianFormatedDateTimeString() : string.Empty,
                     p.LastUpdatedBy,
                     string.Empty,
                     p.RackNumber)
                );
        }

        public static IQueryable<ProductDropdownResponse> MapProductToDropdown(this IQueryable<Product> products)
        {
            return products.Select(p => new ProductDropdownResponse(p.Id, p.Name));
        }
    }
}