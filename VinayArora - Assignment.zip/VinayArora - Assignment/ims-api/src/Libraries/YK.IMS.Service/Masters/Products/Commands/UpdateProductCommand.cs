﻿using System;
using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Products
{
    public class UpdateProductCommand : CommandBase<ServiceResponseWrapper<UpdateProductResponse>>
    {
        public UpdateProductCommand(int id, int companyId, string name, string code, string description, string lastUpdatedBy,
                                   string barcode, int materialTypeId, int productGroupId, int unitId, int retailUnitId,
                                   int sizeId, int makeId, int colorId, int styleId, int chapterHeadingId,
                                   int packSizeId, int modelId, decimal defaultSalePrice, decimal retailSalePrice,
                                   decimal defaultPurchasePrice, decimal defaultDiscountPercentage,
                                   decimal defaultDiscountPrice, decimal taxPercentage, decimal stockQuantity,
                                   bool moveItemInStock, string rackNumber)
        {
            Id = id;
            CompanyId = companyId;
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Code = code ?? throw new ArgumentNullException(nameof(code));
            Description = description;
            IsActive = true;
            IsDelete = false;
            LastUpdatedAt = DateTime.UtcNow;
            if (string.IsNullOrWhiteSpace(lastUpdatedBy) || !Guid.TryParse(lastUpdatedBy, out Guid result))
            {
                throw new ArgumentNullException(nameof(lastUpdatedBy));
            }
            LastUpdatedBy = lastUpdatedBy;

            Barcode = barcode ?? string.Empty;
            MaterialTypeId = materialTypeId;
            ProductGroupId = productGroupId;
            UnitId = unitId;
            RetailUnitId = retailUnitId;
            SizeId = sizeId;
            MakeId = makeId;
            ColorId = colorId;
            StyleId = styleId;
            ChapterHeadingId = chapterHeadingId;
            PackSizeId = packSizeId;
            ModelId = modelId;
            DefaultSalePrice = defaultSalePrice;
            RetailSalePrice = retailSalePrice;
            DefaultPurchasePrice = defaultPurchasePrice;
            DefaultDiscountPercentage = defaultDiscountPercentage;
            DefaultDiscountPrice = defaultDiscountPrice;
            TaxPercentage = taxPercentage;
            StockQuantity = stockQuantity;
            MoveItemInStock = moveItemInStock;
            RackNumber = rackNumber;
        }

        public int Id { get; }
        public int CompanyId { get; }
        public string Name { get; }
        public string Code { get; }
        public string Description { get; }
        public bool IsActive { get; }
        public bool IsDelete { get; }
        public DateTime CreatedAt { get; }
        public string CreatedBy { get; }
        public string Barcode { get; }
        public int MaterialTypeId { get; }
        public int ProductGroupId { get; }
        public int UnitId { get; }
        public int RetailUnitId { get; }
        public int SizeId { get; }
        public int MakeId { get; }
        public int ColorId { get; }
        public int StyleId { get; }
        public int ChapterHeadingId { get; }
        public int PackSizeId { get; }
        public int ModelId { get; }
        public decimal DefaultSalePrice { get; }
        public decimal RetailSalePrice { get; }
        public decimal DefaultPurchasePrice { get; }
        public decimal DefaultDiscountPercentage { get; }
        public decimal DefaultDiscountPrice { get; }
        public decimal TaxPercentage { get; }
        public decimal StockQuantity { get; }
        public bool MoveItemInStock { get; }
        public string RackNumber { get; }
        public DateTime LastUpdatedAt { get; }
        public string LastUpdatedBy { get; }
    }
}
