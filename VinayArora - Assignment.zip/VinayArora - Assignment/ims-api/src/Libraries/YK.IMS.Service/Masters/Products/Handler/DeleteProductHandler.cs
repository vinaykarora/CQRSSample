﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Products;

namespace YK.IMS.Service.Products
{
    public class DeleteProductHandler : StatusGenericHandler, IDeleteProductHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly IProductDbAccess _dbAccess;

        public DeleteProductHandler(DbContext context, ILogger logger, IProductDbAccess dbAccess)
        {
            _logger = logger.ForContext<DeleteProductHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper> Handle(DeleteProductCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid product id '{request.Id}'.");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            _logger.Debug($"Deleting existing product '{request.Id}'.");

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                return new ServiceResponseWrapper(this);
            }

            _logger.Debug($"Find product '{request.Id}'.");

            Product productToDelete = await _dbAccess.FindById(request.Id);
            if (productToDelete == null)
            {
                _logger.Error($"Sorry, I could not find the product '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the product you were looking for.");
            }

            if (!HasErrors)
            {
                _logger.Information($"Delete product entity.");
                productToDelete.Delete();
                _dbAccess.Update(productToDelete);
                await _context.SaveChangesAsync();
                Message = $"Successfully delete the Product '{productToDelete.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(Product)}' entity object.");
            }

            return new ServiceResponseWrapper(this);
        }
    }
}
