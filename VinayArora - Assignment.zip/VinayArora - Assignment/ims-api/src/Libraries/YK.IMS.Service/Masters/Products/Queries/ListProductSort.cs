﻿using System;
using System.Linq;
using YK.IMS.Core.Helpers;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Products
{
    public static class ListProductSort
    {
        public static IQueryable<Product> OrderProductsBy(this IQueryable<Product> products, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.Id); }
                    else { return products.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.Name); }
                    else { return products.OrderBy(x => x.Name); }
                case Constants.Strings.OrderByOptions.CREATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.CreatedAt); }
                    else { return products.OrderBy(x => x.CreatedAt); }
                case Constants.Strings.OrderByOptions.CODE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.Code); }
                    else { return products.OrderBy(x => x.Code); }
                case Constants.Strings.OrderByOptions.DESCRIPTION:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.Description); }
                    else { return products.OrderBy(x => x.Description); }
                case Constants.Strings.OrderByOptions.CREATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.CreatedBy); }
                    else { return products.OrderBy(x => x.CreatedBy); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.LastUpdatedAt); }
                    else { return products.OrderBy(x => x.LastUpdatedAt); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.LastUpdatedBy); }
                    else { return products.OrderBy(x => x.LastUpdatedBy); }
                case Constants.Strings.OrderByOptions.ACTIVE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.IsActive); }
                    else { return products.OrderBy(x => x.IsActive); }
                case Constants.Strings.OrderByOptions.DELETED:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.IsDelete); }
                    else { return products.OrderBy(x => x.IsDelete); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }

        public static IQueryable<Product> OrderProductsDropdownBy(this IQueryable<Product> products, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.Id); }
                    else { return products.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return products.OrderByDescending(x => x.Name); }
                    else { return products.OrderBy(x => x.Name); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }
    }
}