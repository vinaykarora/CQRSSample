﻿using MediatR;

namespace YK.IMS.Service.Products
{
    public class ProductCreatedEvent : INotification
    {
        public int ProductId { get; }

        public ProductCreatedEvent(int productId)
        {
            ProductId = productId;
        }
    }
}
