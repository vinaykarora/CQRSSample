﻿using System;

namespace YK.IMS.Service.Products
{
    public class ProductListResponse
    {
        public ProductListResponse(int id, int companyId, string name, string code, string description, bool isActive,
            bool isDelete, string createdAt, string createdBy, string barcode, int materialTypeId, int productGroupId,
            int unitId, int retailUnitId, int sizeId, int makeId, int colorId, int styleId, int chapterHeadingId,
            int packSizeId, int modelId, decimal defaultSalePrice, decimal retailSalePrice, decimal defaultPurchasePrice,
            decimal defaultDiscountPercentage, decimal defaultDiscountPrice, decimal taxPercentage, string createdByName,
            string lastUpdatedAt, string lastUpdatedBy, string lastUpdatedByName, string rackNumber)
        {
            Id = id;
            CompanyId = companyId;
            Name = name;
            Code = code;
            Description = description;
            IsActive = isActive;
            IsDelete = isDelete;
            CreatedAt = createdAt;
            CreatedBy = createdBy;
            Barcode = barcode;
            MaterialTypeId = materialTypeId;
            ProductGroupId = productGroupId;
            UnitId = unitId;
            RetailUnitId = retailUnitId;
            SizeId = sizeId;
            MakeId = makeId;
            ColorId = colorId;
            StyleId = styleId;
            ChapterHeadingId = chapterHeadingId;
            PackSizeId = packSizeId;
            ModelId = modelId;
            DefaultSalePrice = defaultSalePrice;
            RetailSalePrice = retailSalePrice;
            DefaultPurchasePrice = defaultPurchasePrice;
            DefaultDiscountPercentage = defaultDiscountPercentage;
            DefaultDiscountPrice = defaultDiscountPrice;
            TaxPercentage = taxPercentage;
            CreatedByName = createdByName;
            LastUpdatedAt = lastUpdatedAt;
            LastUpdatedBy = lastUpdatedBy;
            LastUpdatedByName = lastUpdatedByName;
            RackNumber = rackNumber;
        }

        public int Id { get; }
        public int CompanyId { get; }
        public string Name { get; }
        public string Code { get; }
        public string Description { get; }
        public bool IsActive { get; }
        public bool IsDelete { get; }
        public string CreatedAt { get; }
        public string CreatedBy { get; }
        public string Barcode { get; }
        public int MaterialTypeId { get; }
        public int ProductGroupId { get; }
        public int UnitId { get; }
        public int RetailUnitId { get; }
        public int SizeId { get; }
        public int MakeId { get; }
        public int ColorId { get; }
        public int StyleId { get; }
        public int ChapterHeadingId { get; }
        public int PackSizeId { get; }
        public int ModelId { get; }
        public decimal DefaultSalePrice { get; }
        public decimal RetailSalePrice { get; }
        public decimal DefaultPurchasePrice { get; }
        public decimal DefaultDiscountPercentage { get; }
        public decimal DefaultDiscountPrice { get; }
        public decimal TaxPercentage { get; }
        public string CreatedByName { get; }
        public string LastUpdatedAt { get; }
        public string LastUpdatedBy { get; }
        public string LastUpdatedByName { get; }
        public string RackNumber { get; set; }
    }
}
