﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;


namespace YK.IMS.Service.Products
{
    public class ListProductHandler : IListProductHandler
    {
        private readonly IMSContext _context;
        private readonly ILogger _logger;
        public ListProductHandler(IMSContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<ProductDropdownResponse>> Handle(DropdownProductQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get product(s) dropdown.");
            return await _context.Product
                  .AsNoTracking()
                  .FilterProductsBy(request.FilterBy)
                  .OrderProductsDropdownBy(request.OrderByOptions, request.SortOrder)
                  .MapProductToDropdown()
                  .ToListAsync();
        }

        public async Task<IEnumerable<ProductListResponse>> Handle(ListProductQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get product(s) list.");

            IQueryable<ProductListResponse> productsQuery = _context.Product
                .AsNoTracking()
                .FilterProductsBy(request.FilterBy)
                .OrderProductsBy(request.OrderByOptions, request.SortOrder)
                .MapProductToResponse();

            await request.SetupRestOfDto(productsQuery);

            return productsQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<ProductListResponse> Handle(SingleProductQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get Product.");

            return await _context.Product
                .AsNoTracking()
                .FilterProductsBy(request.FilterBy)
                .MapProductToResponse()
                .FirstOrDefaultAsync();
        }
    }
}