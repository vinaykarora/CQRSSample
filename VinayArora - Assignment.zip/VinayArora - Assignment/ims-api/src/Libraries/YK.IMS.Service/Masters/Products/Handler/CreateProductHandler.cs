﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Products;

namespace YK.IMS.Service.Products
{
    public class CreateProductHandler : StatusGenericHandler, ICreateProductHandler
    {
        private readonly ILogger _logger;
        private readonly IMediator _mediator;
        private readonly IProductDxos _productDxos;
        private readonly DbContext _context;
        private readonly IProductDbAccess _dbAccess;

        public CreateProductHandler(DbContext context, ILogger logger, IMediator mediator, IProductDxos productDxos, IProductDbAccess dbAccess)
        {
            _logger = logger.ForContext<CreateProductHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _productDxos = productDxos ?? throw new ArgumentNullException(nameof(productDxos));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper<CreateProductResponse>> Handle(CreateProductCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");
            if (request == null)
            {
                _logger.Error($"'Null or invalid object '{nameof(request)}' found.");
                throw new ArgumentNullException(nameof(request));
            }

            _logger.Debug($"Creating new '{request.Name}' product.");

            if (string.IsNullOrEmpty(request.Name))
            {
                _logger.Error($"Null or empty {nameof(request.Name)} '{request.Name}' is invalid.");
                AddError("Name Is Required", nameof(request.Name));
            }

            if (string.IsNullOrEmpty(request.Description))
            {
                //_logger.Error($"Null or empty {nameof(request.Description)} '{request.Description}' is invalid.");
                // AddError("Description Is Required", nameof(request.Description));
            }

            if (string.IsNullOrEmpty(request.Code))
            {
                _logger.Error($"Null or empty {nameof(request.Code)} '{request.Code}' is invalid.");
                AddError("Code Is Required", nameof(request.Code));
            }

            if (HasErrors)
            {
                return new ServiceResponseWrapper<CreateProductResponse>(null, this);
            }


            if (await _dbAccess.IsDuplicate(0, request.Name, request.Code))
            {
                _logger.Error($"Duplicate entry found for name '{request.Name}' and code '{request.Code}'.");
                AddError("Duplicate entry found.", nameof(request.Name));
                AddError("Duplicate entry found.", nameof(request.Code));
                return new ServiceResponseWrapper<CreateProductResponse>(null, this);
            }

            _logger.Information($"Create '{nameof(Product)}' entity object.");
            IStatusGeneric<Product> status = Product.CreateProductFactory(
                request.CompanyId,
                request.Name,
                request.Code,
                request.Description,
                request.Barcode,
                request.MaterialTypeId,
                request.ProductGroupId,
                request.UnitId,
                request.RetailUnitId,
                request.SizeId,
                request.MakeId,
                request.ColorId,
                request.StyleId,
                request.ChapterHeadingId,
                request.PackSizeId,
                request.ModelId,
                request.DefaultSalePrice,
                request.RetailUnitId,
                request.DefaultPurchasePrice,
                request.DefaultDiscountPercentage,
                request.DefaultDiscountPrice,
                request.TaxPercentage,
                request.IsActive,
                request.IsDelete,
                request.CreatedBy,
                request.RackNumber);
            CombineErrors(status);

            if (!HasErrors)
            {
                _logger.Information($"Add '{nameof(Product)}' entity object.");
                await _dbAccess.Create(status.Result);
                await _context.SaveChangesAsync();
                Message = $"Successfully saved the Product '{request.Name}'.";
                _logger.Information(Message);

                await _mediator.Publish(new ProductCreatedEvent(status.Result.Id), cancellationToken);
            }
            else
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                _logger.Information($"Validation failed for '{nameof(Product)}' entity object.");
            }

            return new ServiceResponseWrapper<CreateProductResponse>(_productDxos.MapCreateProductResponse(status.Result), this);
        }
    }
}
