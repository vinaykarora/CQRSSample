﻿using MediatR;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DbAccess.Products;

namespace YK.IMS.Service.Products
{
    public class ProductCreatedHandler : INotificationHandler<ProductCreatedEvent>
    {
        private readonly IProductDbAccess _dbAccess;
        private readonly ILogger _logger;

        public ProductCreatedHandler(ILogger logger, IProductDbAccess dbAccess)
        {
            _logger = logger.ForContext<ProductCreatedHandler>();
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task Handle(ProductCreatedEvent notification, CancellationToken cancellationToken)
        {
            var product = await _dbAccess.FindById(notification.ProductId);

            if (product == null)
            {
                //TODO: Handle next business logic if customer is not found
                _logger.Warning("Product is not found by customer id from publisher");
            }
            else
            {
                _logger.Information($"Product has found by product id: {notification.ProductId} from publisher");
            }
        }
    }
}
