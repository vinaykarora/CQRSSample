﻿using System.Collections.Generic;
using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Products
{
    public class DropdownProductQuery : QueryBase<IEnumerable<ProductDropdownResponse>>
    {
        public ListProductFilterBy FilterBy { get; set; }
    }
}