﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.Products
{
    public interface IListProductHandler : IRequestHandler<ListProductQuery, IEnumerable<ProductListResponse>>, 
        IRequestHandler<DropdownProductQuery, IEnumerable<ProductDropdownResponse>>,
        IRequestHandler<SingleProductQuery, ProductListResponse>
    {
    }
}
