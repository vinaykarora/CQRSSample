﻿using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Products
{
    public class ListProductFilterBy : FilterByBase
    {

    }

    public static class ListProductFilter
    {
        public static IQueryable<Product> FilterProductsBy(this IQueryable<Product> products, ListProductFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return products;
            }

            if (filterBy.Id > 0) { products = products.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { products = products.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                products = products.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { products = products.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { products = products.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            products = products.Where(x => x.IsActive == filterBy.IsActive);
            products = products.Where(x => x.IsDelete == filterBy.IsDelete);
            return products;
        }

    }
}