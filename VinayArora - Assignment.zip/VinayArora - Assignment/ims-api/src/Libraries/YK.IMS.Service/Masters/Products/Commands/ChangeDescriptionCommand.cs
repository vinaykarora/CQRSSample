﻿using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Products
{
    public class ChangeDescriptionCommand : CommandBase<ServiceResponseWrapper>
    {
        public int Id { get; set; }

        public string Description { get; set; }
    }
}