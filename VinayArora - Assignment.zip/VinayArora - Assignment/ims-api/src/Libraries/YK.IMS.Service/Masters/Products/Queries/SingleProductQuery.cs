﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Products
{
    public class SingleProductQuery : QueryBase<ProductListResponse>
    {
        public SingleProductQuery(ListProductFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListProductFilterBy FilterBy { get; }
    }
}