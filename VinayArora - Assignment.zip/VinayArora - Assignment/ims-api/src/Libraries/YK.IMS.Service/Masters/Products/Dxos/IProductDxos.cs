﻿namespace YK.IMS.Service.Products
{
    public interface IProductDxos
    {
        CreateProductResponse MapCreateProductResponse(DataLayer.EfClasses.Product product);
    }
}
