﻿using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Products
{
    public class DeleteProductCommand : CommandBase<ServiceResponseWrapper>
    {
        public DeleteProductCommand(int id)
        {
            Id = id;
        }

        public int Id { get;  }
    }
}
