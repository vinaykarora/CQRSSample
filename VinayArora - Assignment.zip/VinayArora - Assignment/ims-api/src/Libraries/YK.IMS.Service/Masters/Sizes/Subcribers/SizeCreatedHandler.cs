﻿using MediatR;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DbAccess.Sizes;

namespace YK.IMS.Service.Sizes
{
    public class SizeCreatedHandler : INotificationHandler<SizeCreatedEvent>
    {
        private readonly ISizeDbAccess _dbAccess;
        private readonly ILogger _logger;

        public SizeCreatedHandler(ILogger logger, ISizeDbAccess dbAccess)
        {
            _logger = logger.ForContext<SizeCreatedHandler>();
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task Handle(SizeCreatedEvent notification, CancellationToken cancellationToken)
        {
            var size = await _dbAccess.FindById(notification.SizeId);

            if (size == null)
            {
                //TODO: Handle next business logic if customer is not found
                _logger.Warning("Size is not found by customer id from publisher");
            }
            else
            {
                _logger.Information($"Size has found by size id: {notification.SizeId} from publisher");
            }
        }
    }
}
