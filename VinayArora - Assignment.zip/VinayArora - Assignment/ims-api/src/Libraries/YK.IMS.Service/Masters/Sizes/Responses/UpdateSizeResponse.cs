﻿namespace YK.IMS.Service.Sizes
{
    public class UpdateSizeResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
