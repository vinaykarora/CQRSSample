﻿namespace YK.IMS.Service.Sizes
{
    public class CreateSizeResponse 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
