﻿using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Sizes
{
    public class DeleteSizeCommand : CommandBase<ServiceResponseWrapper>
    {
        public DeleteSizeCommand(int id)
        {
            Id = id;
        }

        public int Id { get;  }
    }
}
