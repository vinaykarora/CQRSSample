﻿using System.Collections.Generic;
using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Sizes
{
    public class DropdownSizeQuery : QueryBase<IEnumerable<SizeDropdownResponse>>
    {
        public ListSizeFilterBy FilterBy { get; set; }
    }
}