﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Sizes
{
    public class SingleSizeQuery : QueryBase<SizeListResponse>
    {
        public SingleSizeQuery(ListSizeFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListSizeFilterBy FilterBy { get; }
    }
}