﻿using MediatR;

namespace YK.IMS.Service.Sizes
{
    public class SizeCreatedEvent : INotification
    {
        public int SizeId { get; }

        public SizeCreatedEvent(int sizeId)
        {
            SizeId = sizeId;
        }
    }
}
