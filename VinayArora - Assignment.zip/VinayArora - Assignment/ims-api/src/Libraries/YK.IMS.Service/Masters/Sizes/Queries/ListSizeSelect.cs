﻿using System.Linq;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Sizes
{
    public static class ListSizeSelect
    {
        public static IQueryable<SizeListResponse> MapSizeToResponse(this IQueryable<Size> sizes)
        {
            return sizes.Select(p =>
                    new SizeListResponse
                    (
                        p.Id,
                        p.CompanyId,
                        p.Name,
                        p.Code,
                        p.Description,
                        p.IsActive,
                        p.IsDelete,
                        p.CreatedAt,
                        p.CreatedBy,
                        string.Empty,
                        p.LastUpdatedAt,
                        p.LastUpdatedBy,
                        string.Empty
                    )
                );
        }

        public static IQueryable<SizeDropdownResponse> MapSizeToDropdown(this IQueryable<Size> sizes)
        {
            return sizes.Select(p => new SizeDropdownResponse(p.Id, p.Name));
        }
    }
}