﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Sizes;

namespace YK.IMS.Service.Sizes
{
    public class DeleteSizeHandler : StatusGenericHandler, IDeleteSizeHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly ISizeDbAccess _dbAccess;

        public DeleteSizeHandler(DbContext context, ILogger logger, ISizeDbAccess dbAccess)
        {
            _logger = logger.ForContext<DeleteSizeHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper> Handle(DeleteSizeCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid size id '{request.Id}'.");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            _logger.Debug($"Deleting existing size '{request.Id}'.");

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                return new ServiceResponseWrapper(this);
            }

            _logger.Debug($"Find size '{request.Id}'.");

            Size sizeToDelete = await _dbAccess.FindById(request.Id);
            if (sizeToDelete == null)
            {
                _logger.Error($"Sorry, I could not find the size '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the size you were looking for.");
            }

            if (!HasErrors)
            {
                _logger.Information($"Delete size entity.");
                sizeToDelete.Delete();
                _dbAccess.Update(sizeToDelete);
                await _context.SaveChangesAsync();
                Message = $"Successfully delete the Size '{sizeToDelete.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(Size)}' entity object.");
            }

            return new ServiceResponseWrapper(this);
        }
    }
}
