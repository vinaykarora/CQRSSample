﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;


namespace YK.IMS.Service.Sizes
{
    public class ListSizeHandler : IListSizeHandler
    {
        private readonly IMSContext _context;
        private readonly ILogger _logger;
        public ListSizeHandler(IMSContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<SizeDropdownResponse>> Handle(DropdownSizeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get size(s) dropdown.");
            return await _context.Size
                  .AsNoTracking()
                  .FilterSizesBy(request.FilterBy)
                  .OrderSizesDropdownBy(request.OrderByOptions, request.SortOrder)
                  .MapSizeToDropdown()
                  .ToListAsync();
        }

        public async Task<IEnumerable<SizeListResponse>> Handle(ListSizeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get size(s) list.");

            IQueryable<SizeListResponse> sizesQuery = _context.Size
                .AsNoTracking()
                .FilterSizesBy(request.FilterBy)
                .OrderSizesBy(request.OrderByOptions, request.SortOrder)
                .MapSizeToResponse();

            await request.SetupRestOfDto(sizesQuery);

            return sizesQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<SizeListResponse> Handle(SingleSizeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get Size.");

            return await _context.Size
                .AsNoTracking()
                .FilterSizesBy(request.FilterBy)
                .MapSizeToResponse()
                .FirstOrDefaultAsync();
        }
    }
}