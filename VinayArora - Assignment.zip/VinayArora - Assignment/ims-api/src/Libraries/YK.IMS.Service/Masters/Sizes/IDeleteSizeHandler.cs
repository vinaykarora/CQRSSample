﻿using MediatR;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Sizes
{
    public interface IDeleteSizeHandler :  IRequestHandler<DeleteSizeCommand, ServiceResponseWrapper> { }
}
