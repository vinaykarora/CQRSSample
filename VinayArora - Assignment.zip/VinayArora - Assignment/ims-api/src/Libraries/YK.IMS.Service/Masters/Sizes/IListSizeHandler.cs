﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.Sizes
{
    public interface IListSizeHandler : IRequestHandler<ListSizeQuery, IEnumerable<SizeListResponse>>, 
        IRequestHandler<DropdownSizeQuery, IEnumerable<SizeDropdownResponse>>,
        IRequestHandler<SingleSizeQuery, SizeListResponse>
    {
    }
}
