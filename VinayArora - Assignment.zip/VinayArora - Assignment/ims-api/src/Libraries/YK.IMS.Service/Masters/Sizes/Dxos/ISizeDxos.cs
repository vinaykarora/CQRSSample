﻿namespace YK.IMS.Service.Sizes
{
    public interface ISizeDxos
    {
        CreateSizeResponse MapCreateSizeResponse(DataLayer.EfClasses.Size size);
    }
}
