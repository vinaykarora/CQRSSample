﻿using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Sizes
{
    public class ListSizeFilterBy : FilterByBase
    {

    }

    public static class ListSizeFilter
    {
        public static IQueryable<Size> FilterSizesBy(this IQueryable<Size> sizes, ListSizeFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return sizes;
            }

            if (filterBy.Id > 0) { sizes = sizes.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { sizes = sizes.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                sizes = sizes.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { sizes = sizes.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { sizes = sizes.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            sizes = sizes.Where(x => x.IsActive == filterBy.IsActive);
            sizes = sizes.Where(x => x.IsDelete == filterBy.IsDelete);
            return sizes;
        }

    }
}