﻿namespace YK.IMS.Service.Sizes
{
    public class SizeDropdownResponse
    {
        public SizeDropdownResponse(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public int Id { get; }

        public string Name { get; }

        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Name)}: {Name}";
        }
    }
}