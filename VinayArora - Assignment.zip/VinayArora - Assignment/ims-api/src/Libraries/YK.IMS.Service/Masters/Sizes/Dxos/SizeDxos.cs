﻿using AutoMapper;

namespace YK.IMS.Service.Sizes
{
    public class SizeDxos : ISizeDxos
    {
        private readonly IMapper _mapper;

        public SizeDxos()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<DataLayer.EfClasses.Size, CreateSizeResponse>()
                    .ForMember(dst => dst.Id, opt => opt.MapFrom(src => src.Id))
                    .ForMember(dst => dst.Name, opt => opt.MapFrom(src => src.Name));
            });

            _mapper = config.CreateMapper();
        }

        public CreateSizeResponse MapCreateSizeResponse(DataLayer.EfClasses.Size size)
        {
            if (size == null)
                return null;

            return _mapper.Map<DataLayer.EfClasses.Size, CreateSizeResponse>(size);
        }
    }
}
