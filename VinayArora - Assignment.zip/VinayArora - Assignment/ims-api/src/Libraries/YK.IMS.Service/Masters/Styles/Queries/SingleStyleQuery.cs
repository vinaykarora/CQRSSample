﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Styles
{
    public class SingleStyleQuery : QueryBase<StyleListResponse>
    {
        public SingleStyleQuery(ListStyleFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListStyleFilterBy FilterBy { get; }
    }
}