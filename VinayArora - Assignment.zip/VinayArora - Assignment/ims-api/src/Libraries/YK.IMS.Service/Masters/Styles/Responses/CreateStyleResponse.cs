﻿namespace YK.IMS.Service.Styles
{
    public class CreateStyleResponse 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
