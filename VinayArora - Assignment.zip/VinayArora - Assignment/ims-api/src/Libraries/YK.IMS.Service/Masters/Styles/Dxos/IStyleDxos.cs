﻿namespace YK.IMS.Service.Styles
{
    public interface IStyleDxos
    {
        CreateStyleResponse MapCreateStyleResponse(DataLayer.EfClasses.Style style);
    }
}
