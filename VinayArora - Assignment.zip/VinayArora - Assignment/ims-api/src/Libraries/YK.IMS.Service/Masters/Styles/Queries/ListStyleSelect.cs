﻿using System.Linq;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Styles
{
    public static class ListStyleSelect
    {
        public static IQueryable<StyleListResponse> MapStyleToResponse(this IQueryable<Style> styles)
        {
            return styles.Select(p =>
                    new StyleListResponse
                    (
                        p.Id,
                        p.CompanyId,
                        p.Name,
                        p.Code,
                        p.Description,
                        p.IsActive,
                        p.IsDelete,
                        p.CreatedAt,
                        p.CreatedBy,
                        string.Empty,
                        p.LastUpdatedAt,
                        p.LastUpdatedBy,
                        string.Empty
                    )
                );
        }

        public static IQueryable<StyleDropdownResponse> MapStyleToDropdown(this IQueryable<Style> styles)
        {
            return styles.Select(p => new StyleDropdownResponse(p.Id, p.Name));
        }
    }
}