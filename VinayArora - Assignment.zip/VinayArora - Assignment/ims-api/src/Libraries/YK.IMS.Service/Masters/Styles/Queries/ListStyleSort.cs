﻿using System;
using System.Linq;
using YK.IMS.Core.Helpers;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Styles
{
    public static class ListStyleSort
    {
        public static IQueryable<Style> OrderStylesBy(this IQueryable<Style> styles, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.Id); }
                    else { return styles.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.Name); }
                    else { return styles.OrderBy(x => x.Name); }
                case Constants.Strings.OrderByOptions.CREATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.CreatedAt); }
                    else { return styles.OrderBy(x => x.CreatedAt); }
                case Constants.Strings.OrderByOptions.CODE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.Code); }
                    else { return styles.OrderBy(x => x.Code); }
                case Constants.Strings.OrderByOptions.DESCRIPTION:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.Description); }
                    else { return styles.OrderBy(x => x.Description); }
                case Constants.Strings.OrderByOptions.CREATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.CreatedBy); }
                    else { return styles.OrderBy(x => x.CreatedBy); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.LastUpdatedAt); }
                    else { return styles.OrderBy(x => x.LastUpdatedAt); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.LastUpdatedBy); }
                    else { return styles.OrderBy(x => x.LastUpdatedBy); }
                case Constants.Strings.OrderByOptions.ACTIVE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.IsActive); }
                    else { return styles.OrderBy(x => x.IsActive); }
                case Constants.Strings.OrderByOptions.DELETED:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.IsDelete); }
                    else { return styles.OrderBy(x => x.IsDelete); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }

        public static IQueryable<Style> OrderStylesDropdownBy(this IQueryable<Style> styles, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.Id); }
                    else { return styles.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return styles.OrderByDescending(x => x.Name); }
                    else { return styles.OrderBy(x => x.Name); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }
    }
}