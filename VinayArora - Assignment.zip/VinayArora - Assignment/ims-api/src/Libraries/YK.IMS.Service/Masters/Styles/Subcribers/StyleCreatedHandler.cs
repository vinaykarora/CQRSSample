﻿using MediatR;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DbAccess.Styles;

namespace YK.IMS.Service.Styles
{
    public class StyleCreatedHandler : INotificationHandler<StyleCreatedEvent>
    {
        private readonly IStyleDbAccess _dbAccess;
        private readonly ILogger _logger;

        public StyleCreatedHandler(ILogger logger, IStyleDbAccess dbAccess)
        {
            _logger = logger.ForContext<StyleCreatedHandler>();
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task Handle(StyleCreatedEvent notification, CancellationToken cancellationToken)
        {
            var style = await _dbAccess.FindById(notification.StyleId);

            if (style == null)
            {
                //TODO: Handle next business logic if customer is not found
                _logger.Warning("Style is not found by customer id from publisher");
            }
            else
            {
                _logger.Information($"Style has found by style id: {notification.StyleId} from publisher");
            }
        }
    }
}
