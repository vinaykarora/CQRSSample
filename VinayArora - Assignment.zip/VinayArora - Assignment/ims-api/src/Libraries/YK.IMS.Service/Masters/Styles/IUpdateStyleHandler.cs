﻿using MediatR;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;

namespace YK.IMS.Service.Styles
{
    public interface IUpdateStyleHandler : IStatusGeneric, IRequestHandler<UpdateStyleCommand, ServiceResponseWrapper<UpdateStyleResponse>> { }
}
