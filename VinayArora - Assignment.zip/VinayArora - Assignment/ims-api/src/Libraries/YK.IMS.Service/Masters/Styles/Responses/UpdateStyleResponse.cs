﻿namespace YK.IMS.Service.Styles
{
    public class UpdateStyleResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
