﻿using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Styles
{
    public class ListStyleFilterBy : FilterByBase
    {

    }

    public static class ListStyleFilter
    {
        public static IQueryable<Style> FilterStylesBy(this IQueryable<Style> styles, ListStyleFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return styles;
            }

            if (filterBy.Id > 0) { styles = styles.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { styles = styles.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                styles = styles.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { styles = styles.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { styles = styles.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            styles = styles.Where(x => x.IsActive == filterBy.IsActive);
            styles = styles.Where(x => x.IsDelete == filterBy.IsDelete);
            return styles;
        }

    }
}