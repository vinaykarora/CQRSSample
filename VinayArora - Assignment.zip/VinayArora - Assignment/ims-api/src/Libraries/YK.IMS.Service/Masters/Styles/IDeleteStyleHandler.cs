﻿using MediatR;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Styles
{
    public interface IDeleteStyleHandler :  IRequestHandler<DeleteStyleCommand, ServiceResponseWrapper> { }
}
