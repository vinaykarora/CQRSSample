﻿using System.Collections.Generic;
using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Styles
{
    public class DropdownStyleQuery : QueryBase<IEnumerable<StyleDropdownResponse>>
    {
        public ListStyleFilterBy FilterBy { get; set; }
    }
}