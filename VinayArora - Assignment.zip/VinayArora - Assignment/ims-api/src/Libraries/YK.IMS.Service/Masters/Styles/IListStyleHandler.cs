﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.Styles
{
    public interface IListStyleHandler : IRequestHandler<ListStyleQuery, IEnumerable<StyleListResponse>>, 
        IRequestHandler<DropdownStyleQuery, IEnumerable<StyleDropdownResponse>>,
        IRequestHandler<SingleStyleQuery, StyleListResponse>
    {
    }
}
