﻿namespace YK.IMS.Service.Styles
{
    public class StyleDropdownResponse
    {
        public StyleDropdownResponse(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public int Id { get; }

        public string Name { get; }

        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Name)}: {Name}";
        }
    }
}