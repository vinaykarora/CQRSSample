﻿namespace YK.IMS.Service.Styless
{
    public class StylesListResponse
    {
    }
}