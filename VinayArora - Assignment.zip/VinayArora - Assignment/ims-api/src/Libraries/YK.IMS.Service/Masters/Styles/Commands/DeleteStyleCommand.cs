﻿using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Styles
{
    public class DeleteStyleCommand : CommandBase<ServiceResponseWrapper>
    {
        public DeleteStyleCommand(int id)
        {
            Id = id;
        }

        public int Id { get;  }
    }
}
