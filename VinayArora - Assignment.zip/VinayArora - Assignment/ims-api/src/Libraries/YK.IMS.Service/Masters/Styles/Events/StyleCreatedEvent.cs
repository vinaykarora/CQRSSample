﻿using MediatR;

namespace YK.IMS.Service.Styles
{
    public class StyleCreatedEvent : INotification
    {
        public int StyleId { get; }

        public StyleCreatedEvent(int styleId)
        {
            StyleId = styleId;
        }
    }
}
