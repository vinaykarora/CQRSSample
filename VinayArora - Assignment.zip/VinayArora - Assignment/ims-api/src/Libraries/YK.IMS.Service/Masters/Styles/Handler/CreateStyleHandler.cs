﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Styles;

namespace YK.IMS.Service.Styles
{
    public class CreateStyleHandler : StatusGenericHandler, ICreateStyleHandler
    {
        private readonly ILogger _logger;
        private readonly IMediator _mediator;
        private readonly IStyleDxos _styleDxos;
        private readonly DbContext _context;
        private readonly IStyleDbAccess _dbAccess;

        public CreateStyleHandler(DbContext context, ILogger logger, IMediator mediator, IStyleDxos styleDxos, IStyleDbAccess dbAccess)
        {
            _logger = logger.ForContext<CreateStyleHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _styleDxos = styleDxos ?? throw new ArgumentNullException(nameof(styleDxos));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper<CreateStyleResponse>> Handle(CreateStyleCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");
            if (request == null)
            {
                _logger.Error($"'Null or invalid object '{nameof(request)}' found.");
                throw new ArgumentNullException(nameof(request));
            }

            _logger.Debug($"Creating new '{request.Name}' style.");

            if (string.IsNullOrEmpty(request.Name))
            {
                _logger.Error($"Null or empty {nameof(request.Name)} '{request.Name}' is invalid.");
                AddError("Name Is Required", nameof(request.Name));
            }

            if (string.IsNullOrEmpty(request.Description))
            {
                //_logger.Error($"Null or empty {nameof(request.Description)} '{request.Description}' is invalid.");
                // AddError("Description Is Required", nameof(request.Description));
            }

            if (string.IsNullOrEmpty(request.Code))
            {
                _logger.Error($"Null or empty {nameof(request.Code)} '{request.Code}' is invalid.");
                AddError("Code Is Required", nameof(request.Code));
            }

            if (HasErrors)
            {
                return new ServiceResponseWrapper<CreateStyleResponse>(null, this);
            }


            if (await _dbAccess.IsDuplicate(0, request.Name, request.Code))
            {
                _logger.Error($"Duplicate entry found for name '{request.Name}' and code '{request.Code}'.");
                AddError("Duplicate entry found.", nameof(request.Name));
                AddError("Duplicate entry found.", nameof(request.Code));
                return new ServiceResponseWrapper<CreateStyleResponse>(null, this);
            }

            _logger.Information($"Create '{nameof(Style)}' entity object.");
            IStatusGeneric<Style> status = Style.CreateStyleFactory(request.CompanyId, request.Name, request.Code, request.Description, request.CreatedBy);
            CombineErrors(status);

            if (!HasErrors)
            {
                _logger.Information($"Add '{nameof(Style)}' entity object.");
                await _dbAccess.Create(status.Result);
                await _context.SaveChangesAsync();
                Message = $"Successfully saved the Style '{request.Name}'.";
                _logger.Information(Message);

                await _mediator.Publish(new StyleCreatedEvent(status.Result.Id), cancellationToken);
            }
            else
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                _logger.Information($"Validation failed for '{nameof(Style)}' entity object.");
            }

            return new ServiceResponseWrapper<CreateStyleResponse>(_styleDxos.MapCreateStyleResponse(status.Result), this);
        }
    }
}
