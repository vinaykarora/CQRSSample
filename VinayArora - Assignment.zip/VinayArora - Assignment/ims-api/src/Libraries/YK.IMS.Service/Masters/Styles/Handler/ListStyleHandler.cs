﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;


namespace YK.IMS.Service.Styles
{
    public class ListStyleHandler : IListStyleHandler
    {
        private readonly IMSContext _context;
        private readonly ILogger _logger;
        public ListStyleHandler(IMSContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<StyleDropdownResponse>> Handle(DropdownStyleQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get style(s) dropdown.");
            return await _context.Style
                  .AsNoTracking()
                  .FilterStylesBy(request.FilterBy)
                  .OrderStylesDropdownBy(request.OrderByOptions, request.SortOrder)
                  .MapStyleToDropdown()
                  .ToListAsync();
        }

        public async Task<IEnumerable<StyleListResponse>> Handle(ListStyleQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get style(s) list.");

            IQueryable<StyleListResponse> stylesQuery = _context.Style
                .AsNoTracking()
                .FilterStylesBy(request.FilterBy)
                .OrderStylesBy(request.OrderByOptions, request.SortOrder)
                .MapStyleToResponse();

            await request.SetupRestOfDto(stylesQuery);

            return stylesQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<StyleListResponse> Handle(SingleStyleQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get Style.");

            return await _context.Style
                .AsNoTracking()
                .FilterStylesBy(request.FilterBy)
                .MapStyleToResponse()
                .FirstOrDefaultAsync();
        }
    }
}