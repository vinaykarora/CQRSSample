﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.PackSizes
{
    public class SinglePackSizeQuery : QueryBase<PackSizeListResponse>
    {
        public SinglePackSizeQuery(ListPackSizeFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListPackSizeFilterBy FilterBy { get; }
    }
}