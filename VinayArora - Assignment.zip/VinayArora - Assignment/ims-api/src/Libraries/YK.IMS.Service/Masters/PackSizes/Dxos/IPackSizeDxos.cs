﻿namespace YK.IMS.Service.PackSizes
{
    public interface IPackSizeDxos
    {
        CreatePackSizeResponse MapCreatePackSizeResponse(DataLayer.EfClasses.PackSize packSize);
    }
}
