﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;


namespace YK.IMS.Service.PackSizes
{
    public class ListPackSizeHandler : IListPackSizeHandler
    {
        private readonly IMSContext _context;
        private readonly ILogger _logger;
        public ListPackSizeHandler(IMSContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<PackSizeDropdownResponse>> Handle(DropdownPackSizeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get packSize(s) dropdown.");
            return await _context.PackSize
                  .AsNoTracking()
                  .FilterPackSizesBy(request.FilterBy)
                  .OrderPackSizesDropdownBy(request.OrderByOptions, request.SortOrder)
                  .MapPackSizeToDropdown()
                  .ToListAsync();
        }

        public async Task<IEnumerable<PackSizeListResponse>> Handle(ListPackSizeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get packSize(s) list.");

            IQueryable<PackSizeListResponse> packSizesQuery = _context.PackSize
                .AsNoTracking()
                .FilterPackSizesBy(request.FilterBy)
                .OrderPackSizesBy(request.OrderByOptions, request.SortOrder)
                .MapPackSizeToResponse();

            await request.SetupRestOfDto(packSizesQuery);

            return packSizesQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<PackSizeListResponse> Handle(SinglePackSizeQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get PackSize.");

            return await _context.PackSize
                .AsNoTracking()
                .FilterPackSizesBy(request.FilterBy)
                .MapPackSizeToResponse()
                .FirstOrDefaultAsync();
        }
    }
}