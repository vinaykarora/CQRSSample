﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.PackSizes
{
    public interface IListPackSizeHandler : IRequestHandler<ListPackSizeQuery, IEnumerable<PackSizeListResponse>>, 
        IRequestHandler<DropdownPackSizeQuery, IEnumerable<PackSizeDropdownResponse>>,
        IRequestHandler<SinglePackSizeQuery, PackSizeListResponse>
    {
    }
}
