﻿using MediatR;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DbAccess.PackSizes;

namespace YK.IMS.Service.PackSizes
{
    public class PackSizeCreatedHandler : INotificationHandler<PackSizeCreatedEvent>
    {
        private readonly IPackSizeDbAccess _dbAccess;
        private readonly ILogger _logger;

        public PackSizeCreatedHandler(ILogger logger, IPackSizeDbAccess dbAccess)
        {
            _logger = logger.ForContext<PackSizeCreatedHandler>();
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task Handle(PackSizeCreatedEvent notification, CancellationToken cancellationToken)
        {
            var packSize = await _dbAccess.FindById(notification.PackSizeId);

            if (packSize == null)
            {
                //TODO: Handle next business logic if customer is not found
                _logger.Warning("PackSize is not found by customer id from publisher");
            }
            else
            {
                _logger.Information($"PackSize has found by packSize id: {notification.PackSizeId} from publisher");
            }
        }
    }
}
