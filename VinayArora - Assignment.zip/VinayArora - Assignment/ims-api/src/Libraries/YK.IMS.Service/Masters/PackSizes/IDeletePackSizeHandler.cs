﻿using MediatR;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.PackSizes
{
    public interface IDeletePackSizeHandler :  IRequestHandler<DeletePackSizeCommand, ServiceResponseWrapper> { }
}
