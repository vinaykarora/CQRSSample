﻿using System;
using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.PackSizes
{
    public class ListPackSizeFilterBy : FilterByBase
    {

    }

    public static class ListPackSizeFilter
    {
        public static IQueryable<PackSize> FilterPackSizesBy(this IQueryable<PackSize> packSizes, ListPackSizeFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return packSizes;
            }

            if (filterBy.Id > 0) { packSizes = packSizes.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { packSizes = packSizes.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                packSizes = packSizes.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { packSizes = packSizes.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { packSizes = packSizes.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            packSizes = packSizes.Where(x => x.IsActive == filterBy.IsActive);
            packSizes = packSizes.Where(x => x.IsDelete == filterBy.IsDelete);
            return packSizes;
        }

    }
}