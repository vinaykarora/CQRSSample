﻿using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.PackSizes
{
    public class DeletePackSizeCommand : CommandBase<ServiceResponseWrapper>
    {
        public DeletePackSizeCommand(int id)
        {
            Id = id;
        }

        public int Id { get;  }
    }
}
