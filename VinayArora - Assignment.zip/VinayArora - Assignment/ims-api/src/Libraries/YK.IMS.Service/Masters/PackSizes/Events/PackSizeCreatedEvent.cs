﻿using MediatR;

namespace YK.IMS.Service.PackSizes
{
    public class PackSizeCreatedEvent : INotification
    {
        public int PackSizeId { get; }

        public PackSizeCreatedEvent(int packSizeId)
        {
            PackSizeId = packSizeId;
        }
    }
}
