﻿using System;
using System.Linq;
using YK.IMS.Core.Helpers;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.PackSizes
{
    public static class ListPackSizeSort
    {
        public static IQueryable<PackSize> OrderPackSizesBy(this IQueryable<PackSize> packSizes, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.Id); }
                    else { return packSizes.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.Name); }
                    else { return packSizes.OrderBy(x => x.Name); }
                case Constants.Strings.OrderByOptions.CREATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.CreatedAt); }
                    else { return packSizes.OrderBy(x => x.CreatedAt); }
                case Constants.Strings.OrderByOptions.CODE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.Code); }
                    else { return packSizes.OrderBy(x => x.Code); }
                case Constants.Strings.OrderByOptions.DESCRIPTION:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.Description); }
                    else { return packSizes.OrderBy(x => x.Description); }
                case Constants.Strings.OrderByOptions.CREATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.CreatedBy); }
                    else { return packSizes.OrderBy(x => x.CreatedBy); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.LastUpdatedAt); }
                    else { return packSizes.OrderBy(x => x.LastUpdatedAt); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.LastUpdatedBy); }
                    else { return packSizes.OrderBy(x => x.LastUpdatedBy); }
                case Constants.Strings.OrderByOptions.ACTIVE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.IsActive); }
                    else { return packSizes.OrderBy(x => x.IsActive); }
                case Constants.Strings.OrderByOptions.DELETED:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.IsDelete); }
                    else { return packSizes.OrderBy(x => x.IsDelete); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }

        public static IQueryable<PackSize> OrderPackSizesDropdownBy(this IQueryable<PackSize> packSizes, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.Id); }
                    else { return packSizes.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return packSizes.OrderByDescending(x => x.Name); }
                    else { return packSizes.OrderBy(x => x.Name); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }
    }
}