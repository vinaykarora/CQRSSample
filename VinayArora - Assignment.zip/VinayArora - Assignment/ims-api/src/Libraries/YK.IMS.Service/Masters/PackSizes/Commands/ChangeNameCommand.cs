﻿using System.ComponentModel.DataAnnotations;
using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.PackSizes
{
    public class ChangeNameCommand : CommandBase<ServiceResponseWrapper>
    {
        public int Id { get; set; }

        [Required(AllowEmptyStrings = false)]
        public string Name { get; set; }
    }
}