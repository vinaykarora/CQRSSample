﻿using MediatR;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;

namespace YK.IMS.Service.PackSizes
{
    public interface ICreatePackSizeHandler : IStatusGeneric, IRequestHandler<CreatePackSizeCommand, ServiceResponseWrapper<CreatePackSizeResponse>> { }
}
