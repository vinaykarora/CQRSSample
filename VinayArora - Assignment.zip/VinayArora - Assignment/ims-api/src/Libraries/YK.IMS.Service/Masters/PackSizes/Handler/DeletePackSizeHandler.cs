﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.PackSizes;

namespace YK.IMS.Service.PackSizes
{
    public class DeletePackSizeHandler : StatusGenericHandler, IDeletePackSizeHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly IPackSizeDbAccess _dbAccess;

        public DeletePackSizeHandler(DbContext context, ILogger logger, IPackSizeDbAccess dbAccess)
        {
            _logger = logger.ForContext<DeletePackSizeHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper> Handle(DeletePackSizeCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid packSize id '{request.Id}'.");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            _logger.Debug($"Deleting existing packSize '{request.Id}'.");

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                return new ServiceResponseWrapper(this);
            }

            _logger.Debug($"Find packSize '{request.Id}'.");

            PackSize packSizeToDelete = await _dbAccess.FindById(request.Id);
            if (packSizeToDelete == null)
            {
                _logger.Error($"Sorry, I could not find the packSize '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the packSize you were looking for.");
            }

            if (!HasErrors)
            {
                _logger.Information($"Delete packSize entity.");
                packSizeToDelete.Delete();
                _dbAccess.Update(packSizeToDelete);
                await _context.SaveChangesAsync();
                Message = $"Successfully delete the PackSize '{packSizeToDelete.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(PackSize)}' entity object.");
            }

            return new ServiceResponseWrapper(this);
        }
    }
}
