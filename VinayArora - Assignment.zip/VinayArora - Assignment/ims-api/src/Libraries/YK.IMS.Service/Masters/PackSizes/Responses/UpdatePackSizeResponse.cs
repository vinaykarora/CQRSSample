﻿namespace YK.IMS.Service.PackSizes
{
    public class UpdatePackSizeResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
