﻿using AutoMapper;

namespace YK.IMS.Service.Units
{
    public class UnitDxos : IUnitDxos
    {
        private readonly IMapper _mapper;

        public UnitDxos()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<DataLayer.EfClasses.Unit, CreateUnitResponse>()
                    .ForMember(dst => dst.Id, opt => opt.MapFrom(src => src.Id))
                    .ForMember(dst => dst.Name, opt => opt.MapFrom(src => src.Name));
            });

            _mapper = config.CreateMapper();
        }

        public CreateUnitResponse MapCreateUnitResponse(DataLayer.EfClasses.Unit unit)
        {
            if (unit == null)
                return null;

            return _mapper.Map<DataLayer.EfClasses.Unit, CreateUnitResponse>(unit);
        }
    }
}
