﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Units;

namespace YK.IMS.Service.Units
{
    public class DeleteUnitHandler : StatusGenericHandler, IDeleteUnitHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly IUnitDbAccess _dbAccess;

        public DeleteUnitHandler(DbContext context, ILogger logger, IUnitDbAccess dbAccess)
        {
            _logger = logger.ForContext<DeleteUnitHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper> Handle(DeleteUnitCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid unit id '{request.Id}'.");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            _logger.Debug($"Deleting existing unit '{request.Id}'.");

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                return new ServiceResponseWrapper(this);
            }

            _logger.Debug($"Find unit '{request.Id}'.");

            Unit unitToDelete = await _dbAccess.FindById(request.Id);
            if (unitToDelete == null)
            {
                _logger.Error($"Sorry, I could not find the unit '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the unit you were looking for.");
            }

            if (!HasErrors)
            {
                _logger.Information($"Delete unit entity.");
                unitToDelete.Delete();
                _dbAccess.Update(unitToDelete);
                await _context.SaveChangesAsync();
                Message = $"Successfully delete the Unit '{unitToDelete.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(Unit)}' entity object.");
            }

            return new ServiceResponseWrapper(this);
        }
    }
}
