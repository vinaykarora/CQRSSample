﻿namespace YK.IMS.Service.Units
{
    public class CreateUnitResponse 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
