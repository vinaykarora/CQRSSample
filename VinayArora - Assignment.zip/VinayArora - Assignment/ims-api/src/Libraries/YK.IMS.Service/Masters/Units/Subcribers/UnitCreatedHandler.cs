﻿using MediatR;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DbAccess.Units;

namespace YK.IMS.Service.Units
{
    public class UnitCreatedHandler : INotificationHandler<UnitCreatedEvent>
    {
        private readonly IUnitDbAccess _dbAccess;
        private readonly ILogger _logger;

        public UnitCreatedHandler(ILogger logger, IUnitDbAccess dbAccess)
        {
            _logger = logger.ForContext<UnitCreatedHandler>();
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task Handle(UnitCreatedEvent notification, CancellationToken cancellationToken)
        {
            var unit = await _dbAccess.FindById(notification.UnitId);

            if (unit == null)
            {
                //TODO: Handle next business logic if customer is not found
                _logger.Warning("Unit is not found by customer id from publisher");
            }
            else
            {
                _logger.Information($"Unit has found by unit id: {notification.UnitId} from publisher");
            }
        }
    }
}
