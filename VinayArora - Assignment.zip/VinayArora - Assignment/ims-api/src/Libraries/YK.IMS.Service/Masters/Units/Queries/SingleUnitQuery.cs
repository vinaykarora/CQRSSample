﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Units
{
    public class SingleUnitQuery : QueryBase<UnitListResponse>
    {
        public SingleUnitQuery(ListUnitFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListUnitFilterBy FilterBy { get; }
    }
}