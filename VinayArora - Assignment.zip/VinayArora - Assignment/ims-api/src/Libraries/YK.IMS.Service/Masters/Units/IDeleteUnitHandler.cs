﻿using MediatR;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Units
{
    public interface IDeleteUnitHandler :  IRequestHandler<DeleteUnitCommand, ServiceResponseWrapper> { }
}
