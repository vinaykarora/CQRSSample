﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;


namespace YK.IMS.Service.Units
{
    public class ListUnitHandler : IListUnitHandler
    {
        private readonly IMSContext _context;
        private readonly ILogger _logger;
        public ListUnitHandler(IMSContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<UnitDropdownResponse>> Handle(DropdownUnitQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get unit(s) dropdown.");
            return await _context.Unit
                  .AsNoTracking()
                  .FilterUnitsBy(request.FilterBy)
                  .OrderUnitsDropdownBy(request.OrderByOptions, request.SortOrder)
                  .MapUnitToDropdown()
                  .ToListAsync();
        }

        public async Task<IEnumerable<UnitListResponse>> Handle(ListUnitQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get unit(s) list.");

            IQueryable<UnitListResponse> unitsQuery = _context.Unit
                .AsNoTracking()
                .FilterUnitsBy(request.FilterBy)
                .OrderUnitsBy(request.OrderByOptions, request.SortOrder)
                .MapUnitToResponse();

            await request.SetupRestOfDto(unitsQuery);

            return unitsQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<UnitListResponse> Handle(SingleUnitQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get Unit.");

            return await _context.Unit
                .AsNoTracking()
                .FilterUnitsBy(request.FilterBy)
                .MapUnitToResponse()
                .FirstOrDefaultAsync();
        }
    }
}