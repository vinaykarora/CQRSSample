﻿using MediatR;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;

namespace YK.IMS.Service.Units
{
    public interface IChangeDescriptionHandler : IStatusGeneric, IRequestHandler<ChangeDescriptionCommand, ServiceResponseWrapper> { }
}
