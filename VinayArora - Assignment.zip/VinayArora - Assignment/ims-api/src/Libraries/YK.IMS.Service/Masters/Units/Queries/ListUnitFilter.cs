﻿using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Units
{
    public class ListUnitFilterBy : FilterByBase
    {

    }

    public static class ListUnitFilter
    {
        public static IQueryable<Unit> FilterUnitsBy(this IQueryable<Unit> units, ListUnitFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return units;
            }

            if (filterBy.Id > 0) { units = units.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { units = units.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                units = units.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { units = units.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { units = units.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            units = units.Where(x => x.IsActive == filterBy.IsActive);
            units = units.Where(x => x.IsDelete == filterBy.IsDelete);
            return units;
        }

    }
}