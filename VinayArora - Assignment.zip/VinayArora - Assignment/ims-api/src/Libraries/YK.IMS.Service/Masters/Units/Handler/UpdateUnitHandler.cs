﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Units;

namespace YK.IMS.Service.Units
{
    public class UpdateUnitHandler : StatusGenericHandler, IUpdateUnitHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly IUnitDbAccess _dbAccess;

        public UpdateUnitHandler(DbContext context, ILogger logger, IUnitDbAccess dbAccess)
        {
            _logger = logger.ForContext<UpdateUnitHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper<UpdateUnitResponse>> Handle(UpdateUnitCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");
            if (request == null)
            {
                _logger.Error($"'Null or invalid object '{nameof(request)}' found.");
                throw new ArgumentNullException(nameof(request));
            }

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid unit {nameof(request.Id)} '{request.Id}'");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            if (string.IsNullOrEmpty(request.Name))
            {
                _logger.Error($"Null or empty {nameof(request.Name)} '{request.Name}' is invalid.");
                AddError("Name Is Required", nameof(request.Name));
            }

            if (string.IsNullOrEmpty(request.Description))
            {
                //_logger.Error($"Null or empty {nameof(request.Description)} '{request.Description}' is invalid.");
                // AddError("Description Is Required", nameof(request.Description));
            }

            if (string.IsNullOrEmpty(request.Code))
            {
                _logger.Error($"Null or empty {nameof(request.Code)} '{request.Code}' is invalid.");
                AddError("Code Is Required", nameof(request.Code));
            }

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                _logger.Information($"Validation failed for '{nameof(Unit)}' entity object.");
                return new ServiceResponseWrapper<UpdateUnitResponse>(null, this);
            }

            _logger.Debug($"Find unit '{request.Id}'.");
            Unit unitToUpdate = await _dbAccess.FindById(request.Id);
            if (unitToUpdate == null)
            {
                _logger.Error($"Sorry, I could not find the unit '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the unit you were looking for.");
                return new ServiceResponseWrapper<UpdateUnitResponse>(null, this);
            }

            if (await _dbAccess.IsDuplicate(unitToUpdate.Id, request.Name, unitToUpdate.Code))
            {
                _logger.Error($"Duplicate entry found for '{request.Name}'.");
                AddError("Duplicate entry found.", nameof(request.Name));
                AddError("Duplicate entry found.", nameof(request.Code));
                return new ServiceResponseWrapper<UpdateUnitResponse>(null, this);
            }

            CombineErrors(unitToUpdate.ChangeCode(request.Code));
            CombineErrors(unitToUpdate.ChangeName(request.Name));
            CombineErrors(unitToUpdate.ChangeDescription(request.Description));
            CombineErrors(unitToUpdate.ChangeUpdatedBy(request.LastUpdatedBy));

            if (!HasErrors)
            {
                _logger.Information($"Update unit entity.");
                _dbAccess.Update(unitToUpdate);
                await _context.SaveChangesAsync();
                Message = $"Successfully update the Unit '{request.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(Unit)}' entity object.");
            }

            return new ServiceResponseWrapper<UpdateUnitResponse>(null, this);
        }
    }
}
