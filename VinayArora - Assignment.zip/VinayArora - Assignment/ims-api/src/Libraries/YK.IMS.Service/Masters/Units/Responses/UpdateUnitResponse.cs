﻿namespace YK.IMS.Service.Units
{
    public class UpdateUnitResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
