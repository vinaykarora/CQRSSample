﻿using System.Linq;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Units
{
    public static class ListUnitSelect
    {
        public static IQueryable<UnitListResponse> MapUnitToResponse(this IQueryable<Unit> units)
        {
            return units.Select(p =>
                    new UnitListResponse
                    (
                        p.Id,
                        p.CompanyId,
                        p.Name,
                        p.Code,
                        p.Description,
                        p.IsActive,
                        p.IsDelete,
                        p.CreatedAt,
                        p.CreatedBy,
                        string.Empty,
                        p.LastUpdatedAt,
                        p.LastUpdatedBy,
                        string.Empty
                    )
                );
        }

        public static IQueryable<UnitDropdownResponse> MapUnitToDropdown(this IQueryable<Unit> units)
        {
            return units.Select(p => new UnitDropdownResponse(p.Id, p.Name));
        }
    }
}