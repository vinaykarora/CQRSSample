﻿using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Units
{
    public class DeleteUnitCommand : CommandBase<ServiceResponseWrapper>
    {
        public DeleteUnitCommand(int id)
        {
            Id = id;
        }

        public int Id { get;  }
    }
}
