﻿using MediatR;

namespace YK.IMS.Service.Units
{
    public class UnitCreatedEvent : INotification
    {
        public int UnitId { get; }

        public UnitCreatedEvent(int unitId)
        {
            UnitId = unitId;
        }
    }
}
