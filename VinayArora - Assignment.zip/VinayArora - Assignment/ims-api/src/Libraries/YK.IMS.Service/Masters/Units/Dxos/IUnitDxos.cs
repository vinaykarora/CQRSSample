﻿namespace YK.IMS.Service.Units
{
    public interface IUnitDxos
    {
        CreateUnitResponse MapCreateUnitResponse(DataLayer.EfClasses.Unit unit);
    }
}
