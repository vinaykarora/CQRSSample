﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.Units
{
    public interface IListUnitHandler : IRequestHandler<ListUnitQuery, IEnumerable<UnitListResponse>>, 
        IRequestHandler<DropdownUnitQuery, IEnumerable<UnitDropdownResponse>>,
        IRequestHandler<SingleUnitQuery, UnitListResponse>
    {
    }
}
