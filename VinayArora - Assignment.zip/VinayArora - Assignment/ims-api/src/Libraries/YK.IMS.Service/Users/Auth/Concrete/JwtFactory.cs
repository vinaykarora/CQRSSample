﻿using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using YK.IMS.Core.Helpers;

namespace YK.IMS.Service.Users.Auth
{
    public sealed class JwtFactory : IJwtFactory
    {
        private readonly IJwtTokenHandler _jwtTokenHandler;
        private readonly ILogger _logger;
        private readonly JwtIssuerOptions _jwtOptions;

        public JwtFactory(IJwtTokenHandler jwtTokenHandler,
            IOptions<JwtIssuerOptions> jwtOptions,
            ILogger logger)
        {
            _logger = logger.ForContext<JwtFactory>();
            if (jwtOptions == null)
            {
                throw new ArgumentNullException(nameof(jwtOptions));
            }

            _jwtTokenHandler = jwtTokenHandler ?? throw new ArgumentNullException(nameof(jwtTokenHandler));
            _jwtOptions = jwtOptions.Value;
            ThrowIfInvalidOptions(_jwtOptions);
        }

        public async Task<AccessTokenResponse> GenerateEncodedToken(JwtIdentityClaims jwtIdentityClaims)
        {
            _logger.Information($"{nameof(GenerateEncodedToken)} started.");
            var identity = GenerateClaimsIdentity(jwtIdentityClaims);

            _logger.Information($"Specified claims.");
            var claims = new List<Claim>(identity.Claims)
            {
                 new Claim(JwtRegisteredClaimNames.Sub, jwtIdentityClaims.UserName),
                 new Claim(JwtRegisteredClaimNames.Jti, await _jwtOptions.JtiGenerator()),
                 new Claim(JwtRegisteredClaimNames.Iat, ToUnixEpochDate(_jwtOptions.IssuedAt).ToString(), ClaimValueTypes.Integer64),
            };

            claims.AddRange(jwtIdentityClaims.Claims);

            _logger.Information($"Create the JWT security token and encode it.");
            var jwt = new JwtSecurityToken(
                _jwtOptions.Issuer,
                _jwtOptions.Audience,
                claims,
                _jwtOptions.NotBefore,
                _jwtOptions.Expiration,
                _jwtOptions.SigningCredentials);

            _logger.Information($"{nameof(GenerateEncodedToken)} completed.");
            return new AccessTokenResponse(_jwtTokenHandler.WriteToken(jwt), (int)_jwtOptions.ValidFor.TotalSeconds);
        }

        private static ClaimsIdentity GenerateClaimsIdentity(JwtIdentityClaims jwtIdentityClaims)
        {
            return new ClaimsIdentity(new GenericIdentity(jwtIdentityClaims.UserName, "Token"), new[]
            {
                new Claim(Constants.Strings.JwtClaimIdentifiers.Id, jwtIdentityClaims.UserId),
                new Claim(Constants.Strings.JwtClaimIdentifiers.CompanyId, jwtIdentityClaims.CompanyId.ToString()),
                new Claim(Constants.Strings.JwtClaimIdentifiers.Rol, Constants.Strings.JwtClaims.ApiAccess),
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="date"></param>
        /// <returns>Date converted to seconds since Unix epoch (Jan 1, 1970, midnight UTC).</returns>
        private static long ToUnixEpochDate(DateTime date)
          => (long)Math.Round((date.ToUniversalTime() -
                               new DateTimeOffset(1970, 1, 1, 0, 0, 0, TimeSpan.Zero))
                              .TotalSeconds);

        private void ThrowIfInvalidOptions(JwtIssuerOptions options)
        {
            if (options == null) throw new ArgumentNullException(nameof(options));

            if (options.ValidFor <= TimeSpan.Zero)
            {
                throw new ArgumentException("Must be a non-zero TimeSpan.", nameof(JwtIssuerOptions.ValidFor));
            }

            if (options.SigningCredentials == null)
            {
                throw new ArgumentNullException(nameof(JwtIssuerOptions.SigningCredentials));
            }

            if (options.JtiGenerator == null)
            {
                throw new ArgumentNullException(nameof(JwtIssuerOptions.JtiGenerator));
            }
        }
    }
}
