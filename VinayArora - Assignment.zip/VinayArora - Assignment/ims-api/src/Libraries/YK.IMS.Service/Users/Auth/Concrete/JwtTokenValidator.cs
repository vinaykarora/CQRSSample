﻿using Microsoft.IdentityModel.Tokens;
using Serilog;
using System;
using System.Security.Claims;
using System.Text;

namespace YK.IMS.Service.Users.Auth
{
    public sealed class JwtTokenValidator : IJwtTokenValidator
    {
        private readonly IJwtTokenHandler _jwtTokenHandler;
        private readonly ILogger _logger;

        public JwtTokenValidator(IJwtTokenHandler jwtTokenHandler,
            ILogger logger)
        {
            _logger = logger.ForContext<JwtTokenValidator>();
            _jwtTokenHandler = jwtTokenHandler ?? throw new ArgumentNullException(nameof(jwtTokenHandler));
        }

        public ClaimsPrincipal GetPrincipalFromToken(string token, string signingKey)
        {
            _logger.Information($"Get principal from token.");
            return _jwtTokenHandler.ValidateToken(token, new TokenValidationParameters
            {
                ValidateAudience = false,
                ValidateIssuer = false,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey)),
                ValidateLifetime = false // we check expired tokens here
            });
        }
    }
}
