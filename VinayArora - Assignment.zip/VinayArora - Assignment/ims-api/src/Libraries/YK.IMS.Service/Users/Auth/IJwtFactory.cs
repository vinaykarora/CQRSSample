﻿using System.Threading.Tasks;
using YK.IMS.Service.Users.Auth;

namespace YK.IMS.Service.Users.Auth
{
    public interface IJwtFactory
    {
        Task<AccessTokenResponse> GenerateEncodedToken(JwtIdentityClaims jwtIdentityClaims);
    }
}
