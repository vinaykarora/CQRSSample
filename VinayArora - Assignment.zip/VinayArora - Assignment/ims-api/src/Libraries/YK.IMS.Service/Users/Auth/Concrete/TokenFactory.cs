﻿using Serilog;
using System;
using System.Security.Cryptography;


namespace YK.IMS.Service.Users.Auth
{
    public sealed class TokenFactory : ITokenFactory
    {
        private readonly ILogger _logger;

        public TokenFactory(ILogger logger)
        {
            _logger = logger.ForContext<TokenFactory>();
        }
        public string GenerateToken(int size = 32)
        {
            _logger.Information($"Generate Token.");
            var randomNumber = new byte[size];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }
    }
}
