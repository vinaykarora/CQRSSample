﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;
using YK.IMS.Core.Enums;

namespace YK.IMS.Service.Users.Auth
{
    public class JwtIdentityClaims
    {
        public JwtIdentityClaims(string userId, string userName, int companyId, IEnumerable<Claim> claims)
        {
            UserId = userId ?? throw new ArgumentNullException(nameof(userId));
            UserName = userName ?? throw new ArgumentNullException(nameof(userName));
            CompanyId = companyId;
            Claims = claims;
        }

        public string UserId { get;  }
        public string UserName { get; }
        public int CompanyId { get; }
        public IEnumerable<Claim> Claims { get; }
    }
}
