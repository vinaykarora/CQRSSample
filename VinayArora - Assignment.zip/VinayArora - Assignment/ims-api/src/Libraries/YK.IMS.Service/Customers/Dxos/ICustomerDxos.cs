﻿namespace YK.IMS.Service.Customers
{
    public interface ICustomerDxos
    {
        CreateCustomerResponse MapCreateCustomerResponse(DataLayer.EfClasses.BusinessAccount customer);
    }
}
