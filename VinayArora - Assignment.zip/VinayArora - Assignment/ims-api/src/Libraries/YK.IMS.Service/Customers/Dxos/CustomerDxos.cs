﻿using AutoMapper;

namespace YK.IMS.Service.Customers
{
    public class CustomerDxos : ICustomerDxos
    {
        private readonly IMapper _mapper;

        public CustomerDxos()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<DataLayer.EfClasses.BusinessAccount, CreateCustomerResponse>()
                    .ForMember(dst => dst.Id, opt => opt.MapFrom(src => src.Id))
                    .ForMember(dst => dst.Name, opt => opt.MapFrom(src => src.Name));
            });

            _mapper = config.CreateMapper();
        }

        public CreateCustomerResponse MapCreateCustomerResponse(DataLayer.EfClasses.BusinessAccount customer)
        {
            if (customer == null)
                return null;

            return _mapper.Map<DataLayer.EfClasses.BusinessAccount, CreateCustomerResponse>(customer);
        }
    }
}
