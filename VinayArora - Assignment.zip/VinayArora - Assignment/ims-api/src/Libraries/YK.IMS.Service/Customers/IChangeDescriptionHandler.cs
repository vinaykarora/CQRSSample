﻿using MediatR;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;

namespace YK.IMS.Service.Customers
{
    public interface IChangeDescriptionHandler : IStatusGeneric, IRequestHandler<ChangeDescriptionCommand, ServiceResponseWrapper> { }
}
