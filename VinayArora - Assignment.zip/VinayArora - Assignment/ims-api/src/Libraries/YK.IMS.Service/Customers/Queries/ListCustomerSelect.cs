﻿using System.Collections.Generic;
using System.Linq;
using YK.IMS.Core.Helpers;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Customers
{
    public static class ListCustomerSelect
    {
        public static IQueryable<CustomerListResponse> MapCustomerToResponse(this IQueryable<BusinessAccount> customers)
        {
            return customers.Select(p =>
                    new CustomerListResponse
                    (
                        p.Id,
                        p.CompanyId,
                        p.Name,
                        p.Code,
                        p.Description,
                        p.TaxNumber,
                        p.IsActive,
                        p.IsDelete,
                         p.CreatedAt.GetIndianFormatedDateTimeString(),
                        p.CreatedBy,
                        string.Empty,
                        p.LastUpdatedAt.HasValue ? p.LastUpdatedAt.Value.GetIndianFormatedDateTimeString() : string.Empty,
                        p.LastUpdatedBy,
                        string.Empty,
                        ConvertToResponse(p.BusinessAccountAddresses.FirstOrDefault()),
                        Core.Enums.BusinessType.Customer
                    )
                );
        }

        public static IQueryable<CustomerDropdownResponse> MapCustomerToDropdown(this IQueryable<BusinessAccount> customers)
        {
            return customers.Select(p => new CustomerDropdownResponse(p.Id, p.Name));
        }

        private static CustomerAddressResponse ConvertToResponse(this BusinessAccountAddress accountAddress)
        {
            return new CustomerAddressResponse(accountAddress.CompanyId, accountAddress.AddressType, accountAddress.BusinessAccountId, accountAddress.CountryId, accountAddress.StateId, accountAddress.CityId, accountAddress.Address1, accountAddress.Address2, accountAddress.Address3, accountAddress.Pincode, accountAddress.Phone, accountAddress.Mobile, accountAddress.Email, accountAddress.CreatedBy);
        }
    }
}