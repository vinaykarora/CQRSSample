﻿using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Customers
{
    public class SingleCustomerQuery : QueryBase<CustomerListResponse>
    {
        public SingleCustomerQuery(ListCustomerFilterBy filterBy)
        {
            FilterBy = filterBy;
        }

        public ListCustomerFilterBy FilterBy { get; }
    }
}