﻿using System.Collections.Generic;
using YK.IMS.Core.Queries;

namespace YK.IMS.Service.Customers
{
    public class DropdownCustomerQuery : QueryBase<IEnumerable<CustomerDropdownResponse>>
    {
        public ListCustomerFilterBy FilterBy { get; set; }
    }
}