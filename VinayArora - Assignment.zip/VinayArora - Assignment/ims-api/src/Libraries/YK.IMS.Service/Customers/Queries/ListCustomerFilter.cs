﻿using System.Linq;
using YK.IMS.Core.Queries;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Customers
{
    public class ListCustomerFilterBy : FilterByBase
    {

    }

    public static class ListCustomerFilter
    {
        public static IQueryable<BusinessAccount> FilterCustomersBy(this IQueryable<BusinessAccount> customers, ListCustomerFilterBy filterBy)
        {
            if (filterBy == null)
            {
                return customers;
            }

            if (filterBy.Id > 0) { customers = customers.Where(x => x.Id == filterBy.Id); }
            if (filterBy.CompanyId > 0) { customers = customers.Where(x => x.CompanyId == filterBy.CompanyId); }
            if (!string.IsNullOrWhiteSpace(filterBy.Name)
                || !string.IsNullOrWhiteSpace(filterBy.Code)
                || !string.IsNullOrWhiteSpace(filterBy.Description))
            {
                customers = customers.Where(x => x.Name.Contains(filterBy.Name)
                                           || x.Code.Contains(filterBy.Code)
                                           || x.Description.Contains(filterBy.Description));
            }

            if (!string.IsNullOrWhiteSpace(filterBy.CreatedBy)) { customers = customers.Where(x => x.CreatedBy == filterBy.CreatedBy); }
            if (!string.IsNullOrWhiteSpace(filterBy.LastUpdatedBy)) { customers = customers.Where(x => x.LastUpdatedBy == filterBy.LastUpdatedBy); }

            customers = customers.Where(x => x.IsActive == filterBy.IsActive);
            customers = customers.Where(x => x.IsDelete == filterBy.IsDelete);
            return customers;
        }

    }
}