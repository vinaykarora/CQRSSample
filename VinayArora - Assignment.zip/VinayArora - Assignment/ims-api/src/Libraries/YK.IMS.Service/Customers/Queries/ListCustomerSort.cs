﻿using System;
using System.Linq;
using YK.IMS.Core.Helpers;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.Customers
{
    public static class ListCustomerSort
    {
        public static IQueryable<BusinessAccount> OrderCustomersBy(this IQueryable<BusinessAccount> customers, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.Id); }
                    else { return customers.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.Name); }
                    else { return customers.OrderBy(x => x.Name); }
                case Constants.Strings.OrderByOptions.CREATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.CreatedAt); }
                    else { return customers.OrderBy(x => x.CreatedAt); }
                case Constants.Strings.OrderByOptions.CODE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.Code); }
                    else { return customers.OrderBy(x => x.Code); }
                case Constants.Strings.OrderByOptions.DESCRIPTION:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.Description); }
                    else { return customers.OrderBy(x => x.Description); }
                case Constants.Strings.OrderByOptions.CREATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.CreatedBy); }
                    else { return customers.OrderBy(x => x.CreatedBy); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDAT:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.LastUpdatedAt); }
                    else { return customers.OrderBy(x => x.LastUpdatedAt); }
                case Constants.Strings.OrderByOptions.LASTUPDATEDBY:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.LastUpdatedBy); }
                    else { return customers.OrderBy(x => x.LastUpdatedBy); }
                case Constants.Strings.OrderByOptions.ACTIVE:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.IsActive); }
                    else { return customers.OrderBy(x => x.IsActive); }
                case Constants.Strings.OrderByOptions.DELETED:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.IsDelete); }
                    else { return customers.OrderBy(x => x.IsDelete); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }

        public static IQueryable<BusinessAccount> OrderCustomersDropdownBy(this IQueryable<BusinessAccount> customers, string orderByOptions, string sortOrder)
        {
            switch (orderByOptions)
            {
                case Constants.Strings.OrderByOptions.ID:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.Id); }
                    else { return customers.OrderBy(x => x.Id); }
                case Constants.Strings.OrderByOptions.NAME:
                    if (sortOrder == Constants.Strings.SortOrder.DESC) { return customers.OrderByDescending(x => x.Name); }
                    else { return customers.OrderBy(x => x.Name); }
                default:
                    throw new ArgumentOutOfRangeException(nameof(orderByOptions), orderByOptions, null);
            }
        }
    }
}