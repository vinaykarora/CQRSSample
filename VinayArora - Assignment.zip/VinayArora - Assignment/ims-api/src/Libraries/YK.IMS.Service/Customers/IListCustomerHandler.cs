﻿using MediatR;
using System.Collections.Generic;

namespace YK.IMS.Service.Customers
{
    public interface IListCustomerHandler : IRequestHandler<ListCustomerQuery, IEnumerable<CustomerListResponse>>, 
        IRequestHandler<DropdownCustomerQuery, IEnumerable<CustomerDropdownResponse>>,
        IRequestHandler<SingleCustomerQuery, CustomerListResponse>
    {
    }
}
