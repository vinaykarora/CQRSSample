﻿using YK.IMS.Core.Enums;

namespace YK.IMS.Service.Customers
{
    public class CustomerAddressResponse
    {
        public CustomerAddressResponse(int companyId, AddressType addressType, int businessAccountId, int countryId, int stateId, int cityId, string address1, string address2, string address3, string pincode, string phone, string mobile, string email, string createdBy)
        {
            CreatedBy = createdBy;
            CompanyId = companyId;
            AddressType = addressType;
            BusinessAccountId = businessAccountId;
            CountryId = countryId;
            StateId = stateId;
            CityId = cityId;
            Address1 = address1;
            Address2 = address2;
            Address3 = address3;
            Pincode = pincode;
            Phone = phone;
            Mobile = mobile;
            Email = email;
        }

        public AddressType AddressType { get; }
        public int BusinessAccountId { get; }
        public int CountryId { get; }
        public int StateId { get; }
        public int CityId { get; }
        public string Address1 { get; }
        public string Address2 { get; }
        public string Address3 { get; }
        public string Pincode { get; }
        public string Phone { get; }
        public string Mobile { get; }
        public string Email { get; }
        public string CreatedBy { get; }
        public int CompanyId { get; }
    }
}
