﻿namespace YK.IMS.Service.Customers
{
    public class UpdateCustomerResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
