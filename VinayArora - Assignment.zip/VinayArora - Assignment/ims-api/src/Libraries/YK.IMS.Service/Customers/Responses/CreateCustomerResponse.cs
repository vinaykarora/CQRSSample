﻿namespace YK.IMS.Service.Customers
{
    public class CreateCustomerResponse 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
