﻿using System;
using YK.IMS.Core.Enums;

namespace YK.IMS.Service.Customers
{
    public class CustomerListResponse
    {
        public CustomerListResponse(int id, int companyId, string name, string code, string description, string taxNumber, bool isActive, bool isDelete, string createdAt,
            string createdBy, string createdByName, string lastUpdatedAt, string lastUpdatedBy, string lastUpdatedByName, CustomerAddressResponse address, BusinessType businessType = BusinessType.Customer)
        {
            Id = id;
            CompanyId = companyId;
            Name = name;
            Code = code;
            Description = description;
            TaxNumber = taxNumber;
            BusinessType = businessType;
            IsActive = isActive;
            IsDelete = isDelete;
            CreatedAt = createdAt;
            CreatedBy = createdBy;
            CreatedByName = createdByName;
            LastUpdatedAt = lastUpdatedAt;
            LastUpdatedBy = lastUpdatedBy;
            LastUpdatedByName = lastUpdatedByName;
            Address = address;
        }

        public int Id { get; }
        public int CompanyId { get; }
        public string Name { get; }
        public string Code { get; }
        public string Description { get; }
        public string TaxNumber { get; }
        public bool IsActive { get; }
        public bool IsDelete { get; }
        public string CreatedAt { get; }
        public string CreatedBy { get; }
        public string CreatedByName { get; }
        public string LastUpdatedAt { get; }
        public string LastUpdatedBy { get; }
        public string LastUpdatedByName { get; }
        public BusinessType BusinessType { get; }
        public CustomerAddressResponse Address { get; }
    }
}
