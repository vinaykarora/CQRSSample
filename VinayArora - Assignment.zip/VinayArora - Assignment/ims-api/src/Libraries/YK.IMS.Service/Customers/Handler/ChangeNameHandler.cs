﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Customers;

namespace YK.IMS.Service.Customers
{
    public class ChangeNameHandler : StatusGenericHandler, IChangeNameHandler
    {
        private readonly ILogger _logger;
        private readonly DbContext _context;
        private readonly ICustomerDbAccess _dbAccess;

        public ChangeNameHandler(DbContext dbContext, ILogger logger, ICustomerDbAccess dbAccess)
        {
            _logger = logger.ForContext<ChangeNameHandler>();
            _context = dbContext ?? throw new ArgumentNullException(nameof(dbContext)); ;
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper> Handle(ChangeNameCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");
            if (request == null)
            {
                _logger.Error($"'Null or invalid object '{nameof(request)}' found.");
                throw new ArgumentNullException(nameof(request));
            }

            if (request.Id <= 0)
            {
                _logger.Error($"Null or invalid customer {nameof(request.Id)} '{request.Id}'");
                AddError($"Null or invalid {nameof(request.Id)}", nameof(request.Id));
            }

            if (string.IsNullOrEmpty(request.Name))
            {
                _logger.Error($"Null or empty {nameof(request.Name)} '{request.Name}' is invalid.");
                AddError("Name Is Required", nameof(request.Name));
            }

            if (HasErrors)
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                _logger.Information($"Validation failed for '{nameof(BusinessAccount)}' entity object.");
                return new ServiceResponseWrapper(this);
            }

            _logger.Debug($"Find customer '{request.Id}'.");
            BusinessAccount customerToUpdate = await _dbAccess.FindById(request.Id);
            if (customerToUpdate == null)
            {
                _logger.Error($"Sorry, I could not find the customer '{request.Id}' you were looking for.");
                AddError("Sorry, I could not find the customer you were looking for.");
                return new ServiceResponseWrapper(this);
            }

            CombineErrors(customerToUpdate.ChangeName(request.Name));

            if (!HasErrors)
            {
                _logger.Information($"Update customer entity.");
                _dbAccess.Update(customerToUpdate);
                await _context.SaveChangesAsync();
                Message = $"Successfully update the Customer '{request.Name}'.";
                _logger.Information(Message);
            }
            else
            {
                _logger.Information($"Validation failed for '{nameof(BusinessAccount)}' entity object.");
            }

            return new ServiceResponseWrapper(this);
        }
    }
}
