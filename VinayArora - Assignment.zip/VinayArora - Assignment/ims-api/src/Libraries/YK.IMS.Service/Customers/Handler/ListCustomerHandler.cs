﻿using Microsoft.EntityFrameworkCore;
using Serilog;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.DataLayer.EfCode;
using YK.IMS.DataLayer.QueryObjects;


namespace YK.IMS.Service.Customers
{
    public class ListCustomerHandler : IListCustomerHandler
    {
        private readonly IMSContext _context;
        private readonly ILogger _logger;
        public ListCustomerHandler(IMSContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<CustomerDropdownResponse>> Handle(DropdownCustomerQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get Customer(s) dropdown.");
            return await _context.BusinessAccount
                  .AsNoTracking()
                  .FilterCustomersBy(request.FilterBy)
                  .OrderCustomersDropdownBy(request.OrderByOptions, request.SortOrder)
                  .MapCustomerToDropdown()
                  .ToListAsync();
        }

        public async Task<IEnumerable<CustomerListResponse>> Handle(ListCustomerQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get Customer(s) list.");

            IQueryable<CustomerListResponse> CustomersQuery = _context.BusinessAccount
                .AsNoTracking()
                .FilterCustomersBy(request.FilterBy)
                .OrderCustomersBy(request.OrderByOptions, request.SortOrder)
                .MapCustomerToResponse();

            await request.SetupRestOfDto(CustomersQuery);

            return CustomersQuery.Page(request.PageNum - 1, request.PageSize);
        }

        public async Task<CustomerListResponse> Handle(SingleCustomerQuery request, CancellationToken cancellationToken)
        {
            _logger.Information($"Got a request get Customer.");

            return await _context.BusinessAccount
                .AsNoTracking()
                .FilterCustomersBy(request.FilterBy)
                .MapCustomerToResponse()
                .FirstOrDefaultAsync();
        }
    }
}