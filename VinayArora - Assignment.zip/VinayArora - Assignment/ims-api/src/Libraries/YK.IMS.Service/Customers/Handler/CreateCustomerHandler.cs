﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Responses;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.Customers;

namespace YK.IMS.Service.Customers
{
    public class CreateCustomerHandler : StatusGenericHandler, ICreateCustomerHandler
    {
        private readonly ILogger _logger;
        private readonly IMediator _mediator;
        private readonly ICustomerDxos _customerDxos;
        private readonly DbContext _context;
        private readonly ICustomerDbAccess _dbAccess;

        public CreateCustomerHandler(DbContext context, ILogger logger, IMediator mediator, ICustomerDxos customerDxos, ICustomerDbAccess dbAccess)
        {
            _logger = logger.ForContext<CreateCustomerHandler>();
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _customerDxos = customerDxos ?? throw new ArgumentNullException(nameof(customerDxos));
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
        }

        public async Task<ServiceResponseWrapper<CreateCustomerResponse>> Handle(CreateCustomerCommand request, CancellationToken cancellationToken)
        {
            _logger.Information($"'{nameof(Handle)}' is started.");
            if (request == null)
            {
                _logger.Error($"'Null or invalid object '{nameof(request)}' found.");
                throw new ArgumentNullException(nameof(request));
            }

            _logger.Debug($"Creating new '{request.Name}' customer.");

            if (string.IsNullOrEmpty(request.Name))
            {
                _logger.Error($"Null or empty {nameof(request.Name)} '{request.Name}' is invalid.");
                AddError("Name Is Required", nameof(request.Name));
            }

            if (string.IsNullOrEmpty(request.Description))
            {
                //_logger.Error($"Null or empty {nameof(request.Description)} '{request.Description}' is invalid.");
                // AddError("Description Is Required", nameof(request.Description));
            }

            if (string.IsNullOrEmpty(request.Code))
            {
                _logger.Error($"Null or empty {nameof(request.Code)} '{request.Code}' is invalid.");
                AddError("Code Is Required", nameof(request.Code));
            }

            if (HasErrors)
            {
                return new ServiceResponseWrapper<CreateCustomerResponse>(null, this);
            }


            if (await _dbAccess.IsDuplicate(0, request.Customer.User.Email))
            {
                _logger.Error($"Duplicate entry found for name '{request.Name}' and code '{request.Code}'.");
                AddError("Duplicate entry found.", nameof(request.Name));AddError("Duplicate entry found.", nameof(request.Code));
                return new ServiceResponseWrapper<CreateCustomerResponse>(null, this);
            }

            _logger.Information($"Create '{nameof(BusinessAccount)}' entity object.");
            IStatusGeneric<BusinessAccount> status = BusinessAccount.CreateBusinessAccountFactory(BuildDbRequest(request), request.CreatedBy);
            CombineErrors(status);

            if (!HasErrors)
            {
                _logger.Information($"Add '{nameof(BusinessAccount)}' entity object.");
                await _dbAccess.Create(status.Result);
                await _context.SaveChangesAsync();
                Message = $"Successfully saved the Customer '{request.Name}'.";
                _logger.Information(Message);

                await _mediator.Publish(new Users.CustomerCreatedEvent(status.Result.Id, request.Customer.User.Email, request.Customer.User.Password), cancellationToken);
            }
            else
            {
                _logger.Debug($"Validation failed. Total '{Errors.Count}' errors found.");
                _logger.Information($"Validation failed for '{nameof(BusinessAccount)}' entity object.");
            }

            return new ServiceResponseWrapper<CreateCustomerResponse>(_customerDxos.MapCreateCustomerResponse(status.Result), this);
        }

        private DataLayer.Requests.Customers.CreateCustomerRequest BuildDbRequest(CreateCustomerCommand request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request), $"You must provide {nameof(CreateCustomerCommand)}.");
            }

            return new DataLayer.Requests.Customers.CreateCustomerRequest(request.CompanyId, request.Name, request.Code, request.Description, request.CreatedBy, request.Customer.BusinessType,
                request.Customer.TaxNumber, request.Customer.AssignedTo, request.Customer.DefaultStockLocation, request.Customer.DefaultDiscountPercentage, request.Customer.DefaultPaymentTerm, request.Customer.DefaultPaymentMethod,
                new DataLayer.Requests.Customers.AddAddressRequest(request.CompanyId,
                    request.Customer.Address.AddressType,
                    request.Customer.Address.BusinessAccountId,
                    request.Customer.Address.CountryId,
                    request.Customer.Address.StateId,
                    request.Customer.Address.CityId,
                    request.Customer.Address.Address1,
                    request.Customer.Address.Address2,
                    request.Customer.Address.Address3,
                    request.Customer.Address.Pincode,
                    request.Customer.Address.Phone,
                    request.Customer.Address.Mobile,
                    request.Customer.Address.Email,
                    request.CreatedBy));
        }
    }
}
