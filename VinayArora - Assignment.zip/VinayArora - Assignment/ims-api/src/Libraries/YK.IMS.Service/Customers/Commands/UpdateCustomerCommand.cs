﻿using System;
using YK.IMS.Core.Commands;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Customers
{
    public class UpdateCustomerCommand : CommandBase<ServiceResponseWrapper<UpdateCustomerResponse>>
    {
        public UpdateCustomerCommand(
            int id,
            int companyId,
            string name,
            string code,
            string description,
            string taxNumber,
            string lastUpdatedBy,
            AddAddressCommand address,
            bool isActive = true,
            bool isDelete = false)
        {
            Id = id;
            CompanyId = companyId;
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Code = code ?? throw new ArgumentNullException(nameof(code));
            Description = description;
            TaxNumber = taxNumber ?? throw new ArgumentNullException(nameof(taxNumber));
            IsActive = isActive;
            IsDelete = isDelete;
            LastUpdatedAt = DateTime.UtcNow;
            LastUpdatedBy = lastUpdatedBy ?? throw new ArgumentNullException(nameof(lastUpdatedBy));
            Address = address ?? throw new ArgumentNullException(nameof(address));
        }

        public int Id { get; }
        public int CompanyId { get; }
        public string Name { get; }
        public string Code { get; }
        public string Description { get; }
        public string TaxNumber { get; }
        public bool IsActive { get; }
        public bool IsDelete { get; }
        public DateTime LastUpdatedAt { get; }
        public string LastUpdatedBy { get; }
        public AddAddressCommand Address { get; }
    }
}
