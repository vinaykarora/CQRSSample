﻿using System;
using YK.IMS.Service.Users;
using YK.IMS.Core.Commands;
using YK.IMS.Core.Enums;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Customers
{
    public class CreateCustomerCommand : CommandBase<ServiceResponseWrapper<CreateCustomerResponse>>
    {
        public CreateCustomerCommand(AddCustomerCommand customer, int companyId, string name, string code, string description, string createdBy)
        {
            Customer = customer ?? throw new ArgumentNullException(nameof(customer));
            CompanyId = companyId;
            Name = name ?? throw new ArgumentNullException(nameof(name));
            Code = code ?? throw new ArgumentNullException(nameof(code));
            Description = description;
            CreatedBy = createdBy ?? throw new ArgumentNullException(nameof(createdBy));
        }

        public AddCustomerCommand Customer { get; }
        public int CompanyId { get; }
        public string Name { get; }
        public string Code { get; }
        public string Description { get; }
        public string CreatedBy { get; }
    }

    public class AddCustomerCommand
    {
        public AddCustomerCommand(BusinessType businessType, string taxNumber, int? assignedTo, int? defaultStockLocation, decimal defaultDiscountPercentage, int? defaultPaymentTerm, int? defaultPaymentMethod, AddAddressCommand address, RegisterUserCommand user)
        {
            BusinessType = businessType;
            TaxNumber = taxNumber ?? throw new ArgumentNullException(nameof(taxNumber));
            AssignedTo = assignedTo;
            DefaultStockLocation = defaultStockLocation;
            DefaultDiscountPercentage = defaultDiscountPercentage;
            DefaultPaymentTerm = defaultPaymentTerm;
            DefaultPaymentMethod = defaultPaymentMethod;
            Address = address ?? throw new ArgumentNullException(nameof(address));
            User = user ?? throw new ArgumentNullException(nameof(user));
        }

        public BusinessType BusinessType { get; }
        public string TaxNumber { get; }
        public int? AssignedTo { get; }
        public int? DefaultStockLocation { get; }
        public decimal DefaultDiscountPercentage { get; }
        public int? DefaultPaymentTerm { get; }
        public int? DefaultPaymentMethod { get; }
        public AddAddressCommand Address { get; }
        public RegisterUserCommand User { get; }
    }
}
