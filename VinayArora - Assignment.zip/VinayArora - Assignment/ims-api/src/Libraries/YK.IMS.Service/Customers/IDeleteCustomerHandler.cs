﻿using MediatR;
using YK.IMS.Core.Responses;

namespace YK.IMS.Service.Customers
{
    public interface IDeleteCustomerHandler :  IRequestHandler<DeleteCustomerCommand, ServiceResponseWrapper> { }
}
