﻿using System;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Status;
using YK.IMS.DbAccess.SaleOrders;

namespace YK.IMS.Service.SaleOrders
{
    public class ChangeDeliveryAction : StatusGenericHandler, IChangeDeliveryAction
    {
        private readonly IChangeDeliveryDbAccess _dbAccess;

        public ChangeDeliveryAction(IChangeDeliveryDbAccess dbAccess)
        {
            _dbAccess = dbAccess;
        }

        public void BizAction(ChangeDeliveryDateRequest request)
        {

        }

        public async Task<string> Handle(ChangeDeliveryDateRequest request, CancellationToken cancellationToken)
        {
            DataLayer.EfClasses.SaleOrder saleOrder = _dbAccess.GetSaleOrder(request.Id);
            if (saleOrder == null)
            {
                throw new NullReferenceException("Could not find the order. Someone entering illegal ids?");
            }

            IStatusGeneric status = saleOrder.ChangeDeliveryDate(request.CustomerId, request.NewDeliveryDate);
            CombineErrors(status);

            Message = $"Your new delivery date is {request.NewDeliveryDate.ToShortDateString()}.";

            return await Task.FromResult(Message);
        }
    }
}
