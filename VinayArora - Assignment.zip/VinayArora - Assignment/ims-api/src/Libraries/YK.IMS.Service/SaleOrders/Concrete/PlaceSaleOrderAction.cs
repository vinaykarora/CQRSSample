﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DbAccess.SaleOrders;

namespace YK.IMS.Service.SaleOrders
{
    public class PlaceSaleOrderAction : StatusGenericHandler, IPlaceSaleOrderAction
    {
        private readonly IPlaceSaleOrderDbAccess _dbAccess;

        public PlaceSaleOrderAction(IPlaceSaleOrderDbAccess dbAccess)
        {
            _dbAccess = dbAccess;
        }

        /// <summary>
        /// This validates the input and if OK creates 
        /// an order and calls the _dbAccess to add to orders
        /// </summary>
        /// <param name="request"></param>
        /// <returns>returns an Order. Will be null if there are errors</returns>
        public async Task<MediatR.Unit> Handle(PlaceSaleOrderRequest request, CancellationToken cancellationToken)
        {
            if (!request.AcceptTAndCs)
            {
                AddError("You must accept the T&Cs to place an order.");
                return new MediatR.Unit();
            }

            System.Collections.Generic.IEnumerable<DataLayer.Dtos.OrderProductsDto> productOrders = request.CheckoutLineItems.Select(x => _dbAccess.BuildProductsDto(x.ProductId, x.NumProducts));
            IStatusGeneric<SaleOrder> orderStatus = SaleOrder.CreateSaleOrderFactory(request.CustomerId, DateTime.Today.AddDays(5), productOrders);
            CombineErrors(orderStatus);

            if (!HasErrors)
            {
                _dbAccess.Add(orderStatus.Result);
            }

            return await Task.FromResult(new MediatR.Unit());
        }
    }
}
