﻿using MediatR;
using YK.IMS.Core.Status;
using YK.IMS.DataLayer.EfClasses;

namespace YK.IMS.Service.SaleOrders
{
    public interface IPlaceSaleOrderAction : IStatusGeneric, IRequestHandler<PlaceSaleOrderRequest> { }
}
