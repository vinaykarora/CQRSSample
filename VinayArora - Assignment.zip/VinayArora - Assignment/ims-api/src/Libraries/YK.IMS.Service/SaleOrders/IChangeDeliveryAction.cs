﻿using MediatR;
using YK.IMS.Core.Status;
namespace YK.IMS.Service.SaleOrders
{
    public interface IChangeDeliveryAction : IStatusGeneric, IRequestHandler<ChangeDeliveryDateRequest, string> { }
}
