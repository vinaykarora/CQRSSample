﻿using System;
using YK.IMS.Core.Commands;

namespace YK.IMS.Service.SaleOrders
{
    public class ChangeDeliveryDateRequest: CommandBase<string>
    {
        public int Id { get; set; }

        public int CustomerId { get; set; }

        public DateTime NewDeliveryDate { get; set; }
    }
}