﻿namespace YK.IMS.Service.SaleOrders
{
    public class SaleOrderLineItem
    {
        public int ProductId { get; set; }

        public byte NumProducts { get; set; }
    }
}
