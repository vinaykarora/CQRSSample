﻿using System.Collections.Generic;
using YK.IMS.Core.Commands;

namespace YK.IMS.Service.SaleOrders
{
    public class PlaceSaleOrderRequest : CommandBase
    {
        public bool AcceptTAndCs { get; set; }

        public int CustomerId { get; set; }

        public List<SaleOrderLineItem> CheckoutLineItems { get; set; }
    }
}
