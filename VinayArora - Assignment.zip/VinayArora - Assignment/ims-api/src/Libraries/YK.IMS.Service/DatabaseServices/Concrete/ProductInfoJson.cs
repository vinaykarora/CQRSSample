﻿using System;
using System.Collections.Generic;

namespace YK.IMS.Service.DatabaseServices
{
    public class ProductInfoJson
    {
        public int companyId { get; set; }
        public string name { get; set; }
        public string code { get; set; }
        public string description { get; set; }
        public string barcode { get; set; }
        public string serialNo { get; set; }
        public int materialTypeId { get; set; }
        public int productGroupId { get; set; }
        public int unitId { get; set; }
        public int retailUnitId { get; set; }
        public int sizeId { get; set; }
        public int makeId { get; set; }
        public int colorId { get; set; }
        public int styleId { get; set; }
        public int chapterHeadingId { get; set; }
        public int packSizeId { get; set; }
        public int modelId { get; set; }
        public decimal salePrice { get; set; }
        public decimal retailSalePrice { get; set; }
        public decimal maximumRetailPrice { get; set; }
        public decimal defaultPurchasePrice { get; set; }
        public decimal defaultDiscountPercentage { get; set; }
        public decimal defaultDiscountPrice { get; set; }
        public decimal taxPercentage { get; set; }
        public bool isActive { get; set; }
        public bool isDelete { get; set; }
        public DateTime createdAt { get; set; }
        public string createdBy { get; set; }
        public int productId { get; set; }
    }
}