﻿using YK.IMS.Core.Status;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using YK.IMS.DataLayer.EfClasses;

[assembly: InternalsVisibleTo("test")]

namespace YK.IMS.Service.DatabaseServices
{
    public static class ProductJsonLoader
    {
        private const decimal DefaultProductPrice = 40;    //Any Product without a price is set to this value

        public static IEnumerable<Product> LoadProducts(string fileDir, string fileSearchString)
        {
            string filePath = GetJsonFilePath(fileDir, fileSearchString);
            ICollection<ProductInfoJson> jsonDecoded = JsonConvert.DeserializeObject<ICollection<ProductInfoJson>>(File.ReadAllText(filePath));

            //var authorDict = new Dictionary<string,Author>();
            //foreach (var ProductInfoJson in jsonDecoded)
            //{
            //    foreach (var author in ProductInfoJson.authors)
            //    {
            //        if (!authorDict.ContainsKey(author))
            //            authorDict[author] = new Author(author);
            //    }
            //}

            return jsonDecoded.Select(x => CreateProductWithRefs(x));
        }


        private static Product CreateProductWithRefs(ProductInfoJson productInfoJson)
        {
            IStatusGeneric<Product> status = Product.CreateProductFactory(productInfoJson.companyId, productInfoJson.name, productInfoJson.code, productInfoJson.description, productInfoJson.barcode, productInfoJson.materialTypeId, productInfoJson.productGroupId,
            productInfoJson.unitId, productInfoJson.retailUnitId, productInfoJson.sizeId, productInfoJson.makeId, productInfoJson.colorId, productInfoJson.styleId, productInfoJson.chapterHeadingId, productInfoJson.packSizeId, productInfoJson.modelId,
            productInfoJson.salePrice, productInfoJson.retailSalePrice, productInfoJson.defaultPurchasePrice, productInfoJson.defaultDiscountPercentage,
            productInfoJson.defaultDiscountPrice, productInfoJson.taxPercentage, productInfoJson.isActive, productInfoJson.isDelete, productInfoJson.createdBy, "R12");

            return status.Result;
        }

        /// <summary>
        /// This create the right number of NumStars that add up to the average rating
        /// </summary>
        /// <param name="averageRating"></param>
        /// <param name="ratingsCount"></param>
        /// <returns></returns>
        private static List<int> CalculateReviewsToMatch(double averageRating, int ratingsCount)
        {
            List<int> numStars = new List<int>();
            double currentAve = averageRating;
            for (int i = 0; i < ratingsCount; i++)
            {
                numStars.Add((int)(currentAve > averageRating ? Math.Truncate(averageRating) : Math.Ceiling(averageRating)));
                currentAve = numStars.Average();
            }
            return numStars;
        }

        private static DateTime DecodePubishDate(string publishedDate)
        {
            string[] split = publishedDate.Split('-');
            switch (split.Length)
            {
                case 1:
                    return new DateTime(int.Parse(split[0]), 1, 1);
                case 2:
                    return new DateTime(int.Parse(split[0]), int.Parse(split[1]), 1);
                case 3:
                    return new DateTime(int.Parse(split[0]), int.Parse(split[1]), int.Parse(split[2]));
            }

            throw new InvalidOperationException($"The json publishedDate failed to decode: string was {publishedDate}");
        }

        private static string GetJsonFilePath(string fileDir, string searchPattern)
        {
            string[] fileList = Directory.GetFiles(fileDir, searchPattern);

            if (fileList.Length == 0)
            {
                throw new FileNotFoundException($"Could not find a file with the search name of {searchPattern} in directory {fileDir}");
            }

            //If there are many then we take the most recent
            return fileList.ToList().OrderBy(x => x).Last();
        }
    }
}