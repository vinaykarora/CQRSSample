﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using System.Threading.Tasks;
using YK.IMS.Core.Enums;
using YK.IMS.Core.Helpers;
using YK.IMS.DataLayer.EfClasses;
using YK.IMS.DataLayer.EfCode;

namespace YK.IMS.Service.DatabaseServices
{
    public enum DbStartupModes { UseExisting, EnsureCreated, EnsureDeletedCreated, UseMigrations }

    public static class DbSetupHelpers
    {

        public const string SeedDataSearchName = "Apress Products*.json";
        public const string SeedFileSubDirectory = "seedData";

        public static void DevelopmentEnsureDeleted(this IMSContext db)
        {
            db.Database.EnsureDeleted();
        }

        public static void DevelopmentEnsureCreated(this IMSContext db)
        {
            db.Database.EnsureCreated();
        }

        public static async Task SeedDatabase(this IMSContext context, string directory, string createdBy)
        {
            if (!(context.GetService<IDatabaseCreator>() as RelationalDatabaseCreator).Exists())
            {
                throw new InvalidOperationException("The database does not exist. If you are using Migrations then run PMC command update-database to create it");
            }

            if (string.IsNullOrWhiteSpace(createdBy))
            {
                throw new InvalidOperationException($"The default user id '{createdBy}' does not exist.");
            }

            if (!context.CompanyType.Any())
            {
                await context.CompanyType.AddRangeAsync(
                    new CompanyType(name: "Parent Company", code: "C001", description: "Parent Company Description", createdBy: createdBy),
                    new CompanyType(name: "Subsidiary Company", code: "C002", description: "Subsidiary Company Description", createdBy: createdBy)
                    );

                await context.SaveChangesAsync();
            }

            int companyTypeId = context.CompanyType.First().Id;

            if (!context.Company.Any())
            {
                await context.Company.AddRangeAsync(
                    new Company(name: "YK Solutions & Services", description: "A software development and consulting company", parentCompanyId: null, companyTypeId: companyTypeId,
                    startingDate: DateTime.UtcNow, endingDate: DateTime.UtcNow.AddYears(1), taxNumber: "1234567890", createdBy: createdBy)
                    );

                await context.SaveChangesAsync();
            }

            int companyId = context.Company.First().Id;

            if (!context.Country.Any())
            {
                await context.Country.AddRangeAsync(
                    new Country(name: "Default", code: "D001", description: "Default Country Description", createdBy: createdBy)
                    );

                await context.SaveChangesAsync();
            }

            int countryId = context.Country.First().Id;

            if (!context.State.Any())
            {
                await context.State.AddRangeAsync(
                    new State(name: "Default", code: "D001", description: "Default State Description", countryId: countryId, createdBy: createdBy)
                    );

                await context.SaveChangesAsync();
            }

            int stateId = context.State.First().Id;

            if (!context.City.Any())
            {
                await context.City.AddRangeAsync(
                    new City(name: "Default", code: "D001", description: "Default City Description", stateId: stateId, createdBy: createdBy)
                    );

                await context.SaveChangesAsync();
            }

            int cityId = context.City.First().Id;

            if (!context.Branch.Any())
            {
                await context.Branch.AddRangeAsync(
                    new Branch(name: "Default", description: "Default Branch Description", companyId: companyId, countryId: companyId, stateId: stateId,
                     cityId: cityId, address1: "Address 1", address2: "Address 2", address3: "Address 3", pincode: "122001", phone: "124-44999999", mobile: "98123456789",
                     fax: "124-23445456", email: "default@gmail.com", isDefaultBranch: true, createdBy: createdBy)
                    );

                await context.SaveChangesAsync();
            }

            int branchId = context.Branch.First().Id;


            if (!context.Warehouse.Any())
            {
                await context.Warehouse.AddRangeAsync(
                    new Warehouse(name: "Default", description: "Default Warehouse Description", branchId: branchId, countryId: companyId, stateId: stateId,
                     cityId: cityId, address1: "Address 1", address2: "Address 2", address3: "Address 3", pincode: "122001", phone: "124-44999999", mobile: "98123456789",
                     fax: "124-23445456", email: "default@gmail.com", createdBy: createdBy)
                    );

                await context.SaveChangesAsync();
            }

            //int warehouseId = context.Warehouse.First().Id;

            if (!context.Color.Any())
            {
                await context.Color.AddRangeAsync(
                    Color.CreateColorFactory(companyId: companyId, name: "Default", code: "D001", description: "Default Color Description", createdBy: createdBy).Result
                    );
            }

            if (!context.Make.Any())
            {
                await context.Make.AddRangeAsync(
                    Make.CreateMakeFactory(companyId: companyId, name: "Default", code: "D001", description: "Default Make Description", createdBy: createdBy).Result
                    );
            }

            if (!context.Models.Any())
            {
                await context.Models.AddRangeAsync(
                    Model.CreateModelFactory(companyId: companyId, name: "Default", code: "D001", description: "Default Model Description", createdBy: createdBy).Result
                    );
            }

            if (!context.PackSize.Any())
            {
                await context.PackSize.AddRangeAsync(
                    PackSize.CreatePackSizeFactory(companyId: companyId, name: "Default", code: "D001", description: "Default Pack Size Description", createdBy: createdBy).Result
                    );
            }

            if (!context.ProductGroup.Any())
            {
                await context.ProductGroup.AddRangeAsync(
                    ProductGroup.CreateProductGroupFactory(companyId: companyId, name: "Default", code: "D001", description: "Default Product Group Description", createdBy: createdBy).Result
                    );
            }

            if (!context.Style.Any())
            {
                await context.Style.AddRangeAsync(
                    Style.CreateStyleFactory(companyId: companyId, name: "Default", code: "D001", description: "Default Style Description", createdBy: createdBy).Result
                    );
            }

            if (!context.Size.Any())
            {
                await context.Size.AddRangeAsync(
                    Size.CreateSizeFactory(companyId: companyId, name: "Default", code: "D001", description: "Default Size Description", createdBy: createdBy).Result
                    );
            }

            if (!context.Unit.Any())
            {
                await context.Unit.AddRangeAsync(
                    Unit.CreateUnitFactory(companyId: companyId, name: "Default", code: "D001", description: "Default Unit Description", createdBy: createdBy).Result
                    );
            }

            if (!context.BusinessType.Any())
            {
                await context.BusinessType.AddRangeAsync(
                    DataLayer.EfClasses.BusinessType.CreateBusinessTypeFactory(id: Core.Enums.BusinessType.Customer, companyId: companyId, name: Core.Enums.BusinessType.Customer.GetDescription(), code: "B001", description: "Customer Description", createdBy: createdBy).Result,
                    DataLayer.EfClasses.BusinessType.CreateBusinessTypeFactory(id: Core.Enums.BusinessType.Vendor, companyId: companyId, name: Core.Enums.BusinessType.Vendor.GetDescription(), code: "B002", description: "Vendor Description", createdBy: createdBy).Result,
                    DataLayer.EfClasses.BusinessType.CreateBusinessTypeFactory(id: Core.Enums.BusinessType.Both, companyId: companyId, name: Core.Enums.BusinessType.Both.GetDescription(), code: "B003", description: "Customer Vendor Description", createdBy: createdBy).Result
                    );
            }

            if (!context.MaterialType.Any())
            {
                await context.MaterialType.AddRangeAsync(
                    MaterialType.CreateMaterialTypeFactory(companyId: companyId, name: "Default", code: "D001", description: "Default Default Description", createdBy: createdBy).Result,
                    MaterialType.CreateMaterialTypeFactory(companyId: companyId, name: "Raw Material", code: "RM", description: "Raw Material Description", createdBy: createdBy).Result,
                    MaterialType.CreateMaterialTypeFactory(companyId: companyId, name: "Finish Good", code: "FG", description: "Finish Good Description", createdBy: createdBy).Result,
                    MaterialType.CreateMaterialTypeFactory(companyId: companyId, name: "Consumable General", code: "CG", description: "Consumable General Description", createdBy: createdBy).Result,
                    MaterialType.CreateMaterialTypeFactory(companyId: companyId, name: "Semi Finished", code: "CF", description: "Semi Finished Description", createdBy: createdBy).Result,
                    MaterialType.CreateMaterialTypeFactory(companyId: companyId, name: "Child Item", code: "CI", description: "Child Item Description", createdBy: createdBy).Result,
                    MaterialType.CreateMaterialTypeFactory(companyId: companyId, name: "Scrap", code: "Scrap", description: "Scrap Description", createdBy: createdBy).Result
                    );
            }

            if (!context.ChapterHeading.Any())
            {
                await context.ChapterHeading.AddRangeAsync(
                   new ChapterHeading(companyId: companyId, name: "Default", code: "D001", description: "Default Unit Description", createdBy: createdBy)
                    );
            }

            await context.SaveChangesAsync();
            //the database is emply so we fill it from a json file
            //if (!context.Product.Any())
            //{
            //    List<Product> products = ProductJsonLoader.LoadProducts(Path.Combine(dataDirectory, SeedFileSubDirectory), SeedDataSearchName).ToList();
            //    await context.Product.AddRangeAsync(products);
            //    await context.SaveChangesAsync();
            //    int numProducts = products.Count + 1;
            //}
        }

        public static async Task<string> SeedDatabase(this ApplicationDbContext context, UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            // Our default user
            ApplicationUser user = new ApplicationUser(1, "Super User", "VA", "Super User", Guid.Empty.ToString())
            {
                Email = "Super.User@gmail.com",
                UserName = "Super.User@gmail.com",
                LockoutEnabled = false,
            };

            ApplicationUser defaultUser = await userManager.FindByEmailAsync(user.Email);

            if (defaultUser != null)
            {
                return defaultUser.Id;
            }

            // Get the list of the roles in the enum
            UserRole[] roles = (UserRole[])Enum.GetValues(typeof(UserRole));
            foreach (UserRole r in roles)
            {
                // Create an identity role object out of the enum value
                IdentityRole identityRole = new IdentityRole
                {
                    Id = r.GetDescription(),
                    Name = r.GetDescription()
                };

                // Create the role if it doesn't already exist
                if (!await roleManager.RoleExistsAsync(roleName: identityRole.Name))
                {
                    IdentityResult result = await roleManager.CreateAsync(identityRole);
                    if (!result.Succeeded)
                    {
                        // FIXME: Do not throw an Exception object
                        throw new Exception("Creating role failed");
                    }
                }
            }


            // Add the user to the database if it doesn't already exist
            if (defaultUser == null)
            {
                // WARNING: Do NOT check in credentials of any kind into source control
                IdentityResult result = await userManager.CreateAsync(user, password: "Test@123");

                if (!result.Succeeded)
                {
                    // FIXME: Do not throw an Exception object
                    throw new ApplicationException("Creating user failed");
                }

                // Assign all roles to the default user
                result = await userManager.AddToRolesAsync(user, roles.Select(r => r.GetDescription()));

                if (!result.Succeeded)
                {
                    // FIXME: Do not throw an Exception object
                    throw new ApplicationException("Adding user to role failed");
                }

                result = await userManager.AddClaimAsync(user, new System.Security.Claims.Claim(Constants.Strings.JwtClaimIdentifiers.Rol, Convert.ToString((int)UserRole.SuperAdmin)));
                if (!result.Succeeded)
                {
                    // FIXME: Do not throw an Exception object
                    throw new ApplicationException("Adding user to claim failed");
                }

                return user.Id;
            }

            return defaultUser.Id;
        }
    }
}