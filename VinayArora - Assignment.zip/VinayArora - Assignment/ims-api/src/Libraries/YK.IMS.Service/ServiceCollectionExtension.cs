﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using YK.IMS.Service.Colors;
using YK.IMS.Service.Customers;
using YK.IMS.Service.Makes;
using YK.IMS.Service.MaterialTypes;
using YK.IMS.Service.Models;
using YK.IMS.Service.PackSizes;
using YK.IMS.Service.ProductGroups;
using YK.IMS.Service.Products;
using YK.IMS.Service.Sizes;
using YK.IMS.Service.Styles;
using YK.IMS.Service.Units;
using YK.IMS.Service.Users.Auth;

namespace YK.IMS.Service
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection ConfigureActionServices(this IServiceCollection services, ILogger logger)
        {
            logger.Information("Action services registration started.");
            services.AddSingleton<IJwtFactory, JwtFactory>();
            services.AddSingleton<IJwtTokenHandler, JwtTokenHandler>();
            services.AddSingleton<ITokenFactory, TokenFactory>();
            services.AddSingleton<IJwtTokenValidator, JwtTokenValidator>();

            services.AddSingleton<IColorDxos, ColorDxos>();
            services.AddSingleton<IMakeDxos, MakeDxos>();
            services.AddSingleton<IMaterialTypeDxos, MaterialTypeDxos>();
            services.AddSingleton<IModelDxos, ModelDxos>();
            services.AddSingleton<IPackSizeDxos, PackSizeDxos>();
            services.AddSingleton<IProductGroupDxos, ProductGroupDxos>();
            services.AddSingleton<IProductDxos, ProductDxos>();
            services.AddSingleton<ISizeDxos, SizeDxos>();
            services.AddSingleton<IStyleDxos, StyleDxos>();
            services.AddSingleton<IUnitDxos, UnitDxos>();
            services.AddSingleton<ICustomerDxos, CustomerDxos>();

            return services;
        }

        public static IServiceCollection ConfigureGenericServices(this IServiceCollection services, ILogger logger)
        {
            logger.Information("Add generic services to the service collection.");
            //services.GenericServicesSimpleSetup<IMSContext>(
            //    new GenericServicesConfig
            //    {
            //        DtoAccessValidateOnSave = true,  //This causes validation to happen on create/update via DTOs
            //        DirectAccessValidateOnSave = true, //This causes validation to happen on direct create/update and delete
            //        NoErrorOnReadSingleNull = true //When working with WebAPI you should set this flag. Responce then sends 404 on null result
            //    },
            //    Assembly.GetAssembly(typeof(BaseCreateDto)) // Service
            // );

            //services.RegisterBizRunnerWithDtoScans<IMSContext>(Assembly.GetAssembly(typeof(ICreateUnitAction)));
            return services;
        }
    }
}
