﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace YK.IMS.Core.Queries
{
    public abstract class QueryBase<TResult> : IRequest<TResult> where TResult : class
    {
        public const int DefaultPageSize = 10;   //default page size is 10

        private int _pageSize = DefaultPageSize;
        //-----------------------------------------
        //Paging parts, which require the use of the method

        private int _pageNum = 1;
        public int PageNum
        {
            get => _pageNum;
            set => _pageNum = value;
        }

        public int PageSize
        {
            get => _pageSize;
            set => _pageSize = value;
        }

        private int _totalCount = 1;
        public int TotalCount
        {
            get => _totalCount;
            set => _totalCount = value;
        }
        /// <summary>
        /// This holds the possible page sizes
        /// </summary>
        public int[] PageSizes => new[] { 1, 5, DefaultPageSize, 20, 50, 100, 500, 1000 };

        /// <summary>
        /// This is set to the number of pages available based on the number of entries in the query
        /// </summary>
        public int NumPages { get; private set; }

        /// <summary>
        /// This holds the state of the key parts of the SortFilterPage parts 
        /// </summary>
        public string PrevCheckState { get; set; }

        /// <summary>
        /// This is set to the order of items e.g. asc | desc
        /// </summary>
        public string SortOrder { get; set; }
        public string OrderByOptions { get; set; }

        public virtual async Task SetupRestOfDto<T>(IQueryable<T> query)
        {
            TotalCount = await query.CountAsync();
            NumPages = (int)Math.Ceiling((double)_totalCount / PageSize);
            PageNum = Math.Min(Math.Max(1, PageNum + 1), NumPages);
        }
    }
}
