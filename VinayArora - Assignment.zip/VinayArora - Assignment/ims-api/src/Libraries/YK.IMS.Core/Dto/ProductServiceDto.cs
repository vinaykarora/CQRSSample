﻿using System;

namespace YK.IMS.Core
{
    public class ProductServiceDto
    {
    }
}
