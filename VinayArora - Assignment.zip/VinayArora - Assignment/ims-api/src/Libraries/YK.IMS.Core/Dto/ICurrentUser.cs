﻿using System.Collections.Generic;
using System.Security.Claims;
using System.Text;
using YK.IMS.Core.Enums;

namespace YK.IMS.Core.Dto
{
    public interface ICurrentUser
    {
        string UserId { get; }
        int CompanyId { get; }
        IEnumerable<Claim> Claims { get; }
        UserRole UserRole { get; }
    }
}
