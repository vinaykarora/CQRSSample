﻿namespace YK.IMS.Core.Status
{
    /// <summary>
    /// This is used to return a message in the response
    /// </summary>
    public class WebApiMessageAndResult<T>
    {
        /// <summary>
        /// This is used to create a Message-plus-results  response from GenericBizRunner
        /// </summary>
        /// <param name="status"></param>
        public WebApiMessageAndResult(IStatusGeneric status, T results)
        {
            Message = status.Message;
            Results = results;
        }

        /// <summary>
        /// Contains the message taken from the status
        /// </summary>
        public string Message { get; }

        /// <summary>
        /// The data sent by the Web API
        /// </summary>
        public T Results { get; }
    }
}