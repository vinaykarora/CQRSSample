﻿using System;
using YK.IMS.Core.Status;

namespace YK.IMS.Core.Responses
{
    public class ServiceResponseWrapper
    {
        public ServiceResponseWrapper(IStatusGeneric status)
        {

            Status = status ?? throw new ArgumentNullException(nameof(status));
        }

        public IStatusGeneric Status { get; }
    }

    public class ServiceResponseWrapper<TResult> : ServiceResponseWrapper where TResult : class
    {
        public ServiceResponseWrapper(TResult result, IStatusGeneric status)
            : base(status)
        {
            Result = result;
        }

        public TResult Result { get; }
    }
}
