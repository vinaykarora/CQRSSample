using System;

namespace YK.IMS.Core
{
    /// <summary>
    /// Base class for entities
    /// </summary>
    public abstract partial class BaseEntity<T> where T : IComparable
    {
        protected BaseEntity(T id, Guid companyId, string createdBy)
        {
            Id = id;
            CompanyId = companyId;
            Status = 0;
            IsDeleted = false;
            CreatedAt = DateTime.UtcNow;
            CreatedBy = createdBy ?? throw new ArgumentNullException(nameof(createdBy));
        }


        /// <summary>
        /// Gets or sets the entity identifier
        /// </summary>
        public T Id { get; private set; }
        public Guid CompanyId { get; private set; }
        public short Status { get; private set; }
        public bool IsDeleted { get; private set; }
        public DateTime CreatedAt { get; private set; }
        public string CreatedBy { get; private set; }
        public DateTime? LastUpdatedAt { get; private set; }
        public string LastUpdatedBy { get; private set; }
    }
}
