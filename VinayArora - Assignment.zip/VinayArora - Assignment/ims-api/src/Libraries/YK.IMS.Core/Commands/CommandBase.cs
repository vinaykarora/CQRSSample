﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace YK.IMS.Core.Commands
{
    public class CommandBase : IRequest
    {

    }

    public class CommandBase<T> : IRequest<T> where T : class
    {

    }
}
