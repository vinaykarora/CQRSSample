﻿namespace YK.IMS.Core.Helpers
{
    public static class Constants
    {
        public static class Strings
        {
            public static class JwtClaimIdentifiers
            {
                public const string Rol = "rol", Id = "id", CompanyId = "companyId";
            }

            public static class JwtClaims
            {
                public const string ApiAccess = "api_access";
            }

            public static class SortOrder
            {
                public const string ASC = "asc", DESC = "desc";
            }

            public static class OrderByOptions
            {
                public const string ID = "id", NAME = "name", CODE = "code", DESCRIPTION = "description", CREATEDAT = "createdAt",
                CREATEDBY = "createdBy", LASTUPDATEDAT = "lastUpdatedAt", LASTUPDATEDBY = "lastUpdatedBy",
                ACTIVE = "isActive", DELETED = "isDelete";
            }
        }
    }
}
