﻿using System.ComponentModel;

namespace YK.IMS.Core.Enums
{
    public enum BloodGroups
    {
        [Description("Default")]
        Default = 0,
        [Description("O-")]
        ONegative = 1,
        [Description("O+")]
        OPositive = 2,
        [Description("A-")]
        ANegative = 3,
        [Description("A+")]
        APositive = 4,
        [Description("B-")]
        BNegative = 5,
        [Description("B+")]
        BPositive = 6,
        [Description("AB-")]
        ABNegative = 7,
    }

    public enum GenderTypes
    {
        [Description("Default")]
        Default = 0,
        [Description("Male")]
        Male = 1,
        [Description("Female")]
        Female = 2,
        [Description("Others")]
        Others = 3,
    }

    public enum MaritalStatuses
    {
        [Description("Default")]
        Default = 0,
        [Description("Married")]
        Married = 1,
        [Description("Widowed")]
        Widowed = 2,
        [Description("Separated")]
        Separated = 3,
        [Description("Divorced")]
        Divorced = 4,
        [Description("Single")]
        Single = 5,
    }

    public enum MaterialTypes
    {
        [Description("Default")]
        Default = 0,
        [Description("Raw Material")]
        RawMaterial = 1,
        [Description("Finish Good")]
        FinishGood = 2,
        [Description("Consumable General")]
        ConsumableGeneral = 3,
        [Description("Semi Finished")]
        SemiFinished = 4,
        [Description("Child Item")]
        ChildItem = 5,
        [Description("Scrap")]
        Scrap = 6,
        [Description("Capital Item")]
        CapitalItem = 7,
    }

    public enum UserRole
    {
        [Description("Super Admin")]
        SuperAdmin = 1,
        [Description("Admin")]
        Admin = 2,
        [Description("Manager")]
        Manager = 3,
        [Description("User")]
        User = 4,
        [Description("Customer")]
        Customer = 5
    }

    public enum BusinessType
    {
        [Description("Customer")]
        Customer = 1,
        [Description("Vendor")]
        Vendor = 2,
        [Description("Both")]
        Both = 3,
    }

    public enum AddressType
    {
        [Description("Permanent")]
        Permanent = 1,
        [Description("Correspondance")]
        Correspondance = 2,
        [Description("Communication")]
        Communication = 3,
    }
}
