﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YK.IMS.Core.Enums
{
    public enum ClaimEnums
    {
        SuperAdmin = 0
    }
}
